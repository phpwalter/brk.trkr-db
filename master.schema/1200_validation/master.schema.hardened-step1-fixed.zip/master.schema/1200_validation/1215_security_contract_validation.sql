/*
===============================================================================
 File:           1200_validation/1215_security_contract_validation.sql
 Project:        LEGO Collection Platform
 Schema Version: 1.1.0
 PostgreSQL:     16+
 Purpose:        Enforce the runtime access-control contract mechanically.
                 Runtime roles are EXECUTE-only, may not own/bypass protected
                 objects, and SECURITY DEFINER routines must be hardened.
 Depends On:     1100_security/1107_grants.sql
                 Complete 1000_function domain
 Creates:        Validation assertions only
===============================================================================
*/
\set ON_ERROR_STOP on
SELECT pg_temp.bt_preflight('1200_validation/1215_security_contract_validation.sql', ARRAY['1100_security/1107_grants.sql', 'Complete 1000_function domain']::text[]);

\echo '[VALIDATE] 1215_security_contract_validation.sql'

/* -------------------------------------------------------------------------
 * Contract constants
 * -------------------------------------------------------------------------
 * lego_api is the preferred runtime role.
 * lego_app is retained only as an execute-only compatibility runtime role.
 * Neither role may directly access application tables or sequences.
 * ------------------------------------------------------------------------- */

/* Required runtime roles exist and are structurally incapable of escalation. */
DO $$
DECLARE
    v_role text;
BEGIN
    FOREACH v_role IN ARRAY ARRAY['lego_api', 'lego_app']
    LOOP
        PERFORM app.assert_true(
            EXISTS (SELECT 1 FROM pg_roles WHERE rolname = v_role),
            format('Runtime role "%s" is missing', v_role)
        );

        PERFORM app.assert_true(
            EXISTS (
                SELECT 1
                FROM pg_roles
                WHERE rolname = v_role
                  AND NOT rolcanlogin
                  AND NOT rolsuper
                  AND NOT rolcreaterole
                  AND NOT rolcreatedb
                  AND NOT rolreplication
                  AND NOT rolbypassrls
            ),
            format(
                'Runtime role "%s" must be NOLOGIN, NOSUPERUSER, NOCREATEROLE, '
                'NOCREATEDB, NOREPLICATION, NOBYPASSRLS',
                v_role
            )
        );
    END LOOP;
END;
$$;


/* Runtime roles must never own application relations, routines, schemas, or types. */
DO $$
DECLARE
    v_role text;
    v_owned bigint;
BEGIN
    FOREACH v_role IN ARRAY ARRAY['lego_api', 'lego_app']
    LOOP
        SELECT count(*)
          INTO v_owned
          FROM pg_class c
          JOIN pg_namespace n ON n.oid = c.relnamespace
          JOIN pg_roles r ON r.oid = c.relowner
         WHERE r.rolname = v_role
           AND n.nspname IN (
               'app','identity','reference','catalog','definition','collection',
               'wanted','moc','import','audit','api','admin','marketplace',
               'finance','operations','reporting'
           )
           AND c.relkind IN ('r','p','v','m','S','f');

        PERFORM app.assert_true(
            v_owned = 0,
            format('Runtime role "%s" owns %s application relation(s)', v_role, v_owned)
        );

        SELECT count(*)
          INTO v_owned
          FROM pg_proc p
          JOIN pg_namespace n ON n.oid = p.pronamespace
          JOIN pg_roles r ON r.oid = p.proowner
         WHERE r.rolname = v_role
           AND n.nspname IN (
               'app','identity','reference','catalog','definition','collection',
               'wanted','moc','import','audit','api','admin','marketplace',
               'finance','operations','reporting'
           );

        PERFORM app.assert_true(
            v_owned = 0,
            format('Runtime role "%s" owns %s application routine(s)', v_role, v_owned)
        );

        SELECT count(*)
          INTO v_owned
          FROM pg_namespace n
          JOIN pg_roles r ON r.oid = n.nspowner
         WHERE r.rolname = v_role
           AND n.nspname IN (
               'app','identity','reference','catalog','definition','collection',
               'wanted','moc','import','audit','api','admin','marketplace',
               'finance','operations','reporting'
           );

        PERFORM app.assert_true(
            v_owned = 0,
            format('Runtime role "%s" owns %s application schema(s)', v_role, v_owned)
        );
    END LOOP;
END;
$$;


/* Runtime roles must have ZERO effective direct table privileges. */
DO $$
DECLARE
    v_role text;
    v_relation record;
    v_violations text[] := ARRAY[]::text[];
BEGIN
    FOREACH v_role IN ARRAY ARRAY['lego_api', 'lego_app']
    LOOP
        FOR v_relation IN
            SELECT c.oid, n.nspname, c.relname
              FROM pg_class c
              JOIN pg_namespace n ON n.oid = c.relnamespace
             WHERE c.relkind IN ('r','p','v','m','f')
               AND n.nspname IN (
                   'app','identity','reference','catalog','definition','collection',
                   'wanted','moc','import','audit','marketplace','finance',
                   'operations','reporting'
               )
        LOOP
            IF has_table_privilege(
                v_role,
                v_relation.oid,
                'SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER'
            ) THEN
                v_violations := array_append(
                    v_violations,
                    format('%s:%I.%I', v_role, v_relation.nspname, v_relation.relname)
                );
            END IF;
        END LOOP;
    END LOOP;

    PERFORM app.assert_true(
        cardinality(v_violations) = 0,
        format(
            'Runtime roles must be stored-routine-only; direct relation privileges found: %s',
            array_to_string(v_violations, ', ')
        )
    );
END;
$$;


/* Runtime roles must have ZERO effective sequence privileges. */
DO $$
DECLARE
    v_role text;
    v_sequence record;
    v_violations text[] := ARRAY[]::text[];
BEGIN
    FOREACH v_role IN ARRAY ARRAY['lego_api', 'lego_app']
    LOOP
        FOR v_sequence IN
            SELECT c.oid, n.nspname, c.relname
              FROM pg_class c
              JOIN pg_namespace n ON n.oid = c.relnamespace
             WHERE c.relkind = 'S'
               AND n.nspname IN (
                   'app','identity','reference','catalog','definition','collection',
                   'wanted','moc','import','audit','marketplace','finance',
                   'operations','reporting'
               )
        LOOP
            IF has_sequence_privilege(v_role, v_sequence.oid, 'USAGE,SELECT,UPDATE') THEN
                v_violations := array_append(
                    v_violations,
                    format('%s:%I.%I', v_role, v_sequence.nspname, v_sequence.relname)
                );
            END IF;
        END LOOP;
    END LOOP;

    PERFORM app.assert_true(
        cardinality(v_violations) = 0,
        format(
            'Runtime roles must not access sequences directly: %s',
            array_to_string(v_violations, ', ')
        )
    );
END;
$$;


/* Runtime roles may not CREATE in any application schema. */
DO $$
DECLARE
    v_role text;
    v_schema record;
    v_violations text[] := ARRAY[]::text[];
BEGIN
    FOREACH v_role IN ARRAY ARRAY['lego_api', 'lego_app']
    LOOP
        FOR v_schema IN
            SELECT oid, nspname
              FROM pg_namespace
             WHERE nspname IN (
                 'app','identity','reference','catalog','definition','collection',
                 'wanted','moc','import','audit','api','admin','marketplace',
                 'finance','operations','reporting'
             )
        LOOP
            IF has_schema_privilege(v_role, v_schema.oid, 'CREATE') THEN
                v_violations := array_append(
                    v_violations,
                    format('%s:%I', v_role, v_schema.nspname)
                );
            END IF;
        END LOOP;
    END LOOP;

    PERFORM app.assert_true(
        cardinality(v_violations) = 0,
        format(
            'Runtime roles unexpectedly have schema CREATE: %s',
            array_to_string(v_violations, ', ')
        )
    );
END;
$$;


/* Runtime callable surface is explicit and reviewable.
 *
 * Any new api.* routine intentionally added later MUST be added to this
 * allowlist in the same reviewed change. This creates deliberate CI friction
 * around security-surface expansion.
 */
DO $$
DECLARE
    v_allowed text[] := ARRAY[
        'api.get_moc_by_id(uuid)',
        'api.get_moc_revisions(uuid)',
        'api.get_moc_assets(uuid,uuid)',
        'api.get_moc_licenses(uuid,uuid)',
        'api.get_moc_subassemblies(uuid,uuid)',
        'api.search_catalog(text,integer)',
        'api.mark_notification_read(uuid)',
        'api.transfer_collection_quantity(uuid,uuid,app.quantity,text)'
    ];
    v_allowed_oids oid[];
    v_signature text;
    v_proc record;
BEGIN
    FOREACH v_signature IN ARRAY v_allowed
    LOOP
        PERFORM app.assert_true(
            to_regprocedure(v_signature) IS NOT NULL,
            format('Approved runtime API routine is missing: %s', v_signature)
        );
    END LOOP;

    SELECT array_agg(to_regprocedure(sig)::oid)
      INTO v_allowed_oids
      FROM unnest(v_allowed) sig;

    FOR v_proc IN
        SELECT p.oid,
               p.oid::regprocedure::text AS signature
          FROM pg_proc p
          JOIN pg_namespace n ON n.oid = p.pronamespace
         WHERE n.nspname = 'api'
           AND (
               has_function_privilege('lego_api', p.oid, 'EXECUTE')
               OR has_function_privilege('lego_app', p.oid, 'EXECUTE')
           )
    LOOP
        PERFORM app.assert_true(
            v_proc.oid = ANY(v_allowed_oids),
            format(
                'Unapproved runtime API routine exposed: %s. '
                'Add it to the reviewed allowlist only if intentional.',
                v_proc.signature
            )
        );
    END LOOP;

    FOREACH v_signature IN ARRAY v_allowed
    LOOP
        PERFORM app.assert_true(
            has_function_privilege('lego_api', to_regprocedure(v_signature), 'EXECUTE')
            AND has_function_privilege('lego_app', to_regprocedure(v_signature), 'EXECUTE'),
            format('Approved runtime API routine is not executable by both runtime roles: %s', v_signature)
        );
    END LOOP;
END;
$$;


/* Every runtime API routine must be SECURITY DEFINER with a pinned search_path. */
SELECT app.assert_true(
    NOT EXISTS (
        SELECT 1
          FROM pg_proc p
          JOIN pg_namespace n ON n.oid = p.pronamespace
         WHERE n.nspname = 'api'
           AND (
               has_function_privilege('lego_api', p.oid, 'EXECUTE')
               OR has_function_privilege('lego_app', p.oid, 'EXECUTE')
           )
           AND (
               NOT p.prosecdef
               OR NOT EXISTS (
                   SELECT 1
                     FROM unnest(coalesce(p.proconfig, ARRAY[]::text[])) cfg
                    WHERE split_part(cfg, '=', 1) = 'search_path'
                      AND (
                          split_part(cfg, '=', 2) = 'pg_catalog'
                          OR split_part(cfg, '=', 2) LIKE 'pg_catalog,%'
                      )
               )
           )
    ),
    'Every runtime api.* routine must be SECURITY DEFINER with search_path beginning pg_catalog'
);


/* No SECURITY DEFINER routine in application schemas may be executable by PUBLIC. */
SELECT app.assert_true(
    NOT EXISTS (
        SELECT 1
          FROM pg_proc p
          JOIN pg_namespace n ON n.oid = p.pronamespace
          CROSS JOIN LATERAL aclexplode(
              coalesce(p.proacl, acldefault('f', p.proowner))
          ) acl
         WHERE p.prosecdef
           AND n.nspname IN (
               'app','identity','reference','catalog','definition','collection',
               'wanted','moc','import','audit','api','admin','marketplace',
               'finance','operations','reporting'
           )
           AND acl.grantee = 0
           AND acl.privilege_type = 'EXECUTE'
    ),
    'A SECURITY DEFINER routine is executable by PUBLIC'
);


/* Every SECURITY DEFINER routine must pin search_path with pg_catalog first. */
SELECT app.assert_true(
    NOT EXISTS (
        SELECT 1
          FROM pg_proc p
          JOIN pg_namespace n ON n.oid = p.pronamespace
         WHERE p.prosecdef
           AND n.nspname IN (
               'app','identity','reference','catalog','definition','collection',
               'wanted','moc','import','audit','api','admin','marketplace',
               'finance','operations','reporting'
           )
           AND NOT EXISTS (
               SELECT 1
                 FROM unnest(coalesce(p.proconfig, ARRAY[]::text[])) cfg
                WHERE split_part(cfg, '=', 1) = 'search_path'
                  AND (
                      split_part(cfg, '=', 2) = 'pg_catalog'
                      OR split_part(cfg, '=', 2) LIKE 'pg_catalog,%'
                  )
           )
    ),
    'A SECURITY DEFINER routine lacks a pinned search_path beginning with pg_catalog'
);


/* Runtime roles must not inherit elevated administrator/importer/reporting roles. */
SELECT app.assert_true(
    NOT EXISTS (
        SELECT 1
          FROM pg_auth_members m
          JOIN pg_roles child_role ON child_role.oid = m.member
          JOIN pg_roles parent_role ON parent_role.oid = m.roleid
         WHERE child_role.rolname IN ('lego_api','lego_app')
           AND parent_role.rolname IN ('lego_admin','lego_importer','lego_reporting')
    ),
    'Runtime role inherits an elevated admin/importer/reporting role'
);


/* Admin remains separate from the normal runtime role. */
SELECT app.assert_true(
    EXISTS (
        SELECT 1
          FROM pg_roles
         WHERE rolname = 'lego_admin'
           AND NOT rolcanlogin
           AND rolbypassrls
    ),
    'lego_admin must remain a separate NOLOGIN BYPASSRLS group role'
);

\echo '[VALIDATE PASS] 1215_security_contract_validation.sql'
SELECT pg_temp.bt_mark_completed('1200_validation/1215_security_contract_validation.sql');
