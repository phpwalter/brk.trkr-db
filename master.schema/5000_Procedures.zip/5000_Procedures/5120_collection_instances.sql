/* BrickTrackr 5120 - owned collection instances and adjustments */
\set ON_ERROR_STOP on
CREATE OR REPLACE FUNCTION api.add_owned_instance(
    p_catalog_item_id uuid,
    p_inventory_version_id uuid DEFAULT NULL,
    p_notes text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,collection,definition,catalog,identity,app
AS $$
DECLARE
    v_user uuid:=app.require_active_user();
    v_owner uuid:=identity.ensure_owner_for_user(v_user);
    v_entry uuid;
    v_instance uuid;
BEGIN
    IF NOT EXISTS(SELECT 1 FROM catalog.items WHERE catalog_item_id=p_catalog_item_id AND deleted_at IS NULL) THEN
        RAISE EXCEPTION 'Catalog Item not found' USING ERRCODE='P0002';
    END IF;
    IF p_inventory_version_id IS NOT NULL AND NOT EXISTS(
        SELECT 1
        FROM definition.inventory_versions iv
        JOIN definition.inventory_definitions d USING(inventory_definition_id)
        WHERE iv.inventory_version_id=p_inventory_version_id
          AND d.catalog_item_id=p_catalog_item_id
    ) THEN
        RAISE EXCEPTION 'Inventory/composition version does not belong to Catalog Item' USING ERRCODE='22023';
    END IF;

    SELECT collection_entry_id INTO v_entry
    FROM collection.entries
    WHERE owner_id=v_owner AND catalog_item_id=p_catalog_item_id AND status='ACTIVE'
    ORDER BY created_at LIMIT 1 FOR UPDATE;

    IF v_entry IS NULL THEN
        INSERT INTO collection.entries(owner_id,catalog_item_id,quantity)
        VALUES(v_owner,p_catalog_item_id,1)
        RETURNING collection_entry_id INTO v_entry;
    ELSE
        UPDATE collection.entries SET quantity=quantity+1 WHERE collection_entry_id=v_entry;
    END IF;

    INSERT INTO collection.instances(collection_entry_id,inventory_version_id,notes)
    VALUES(v_entry,p_inventory_version_id,p_notes)
    RETURNING collection_instance_id INTO v_instance;
    RETURN v_instance;
END;
$$;

CREATE OR REPLACE FUNCTION api.update_owned_instance(p_collection_instance_id uuid,p_item_condition collection.item_condition DEFAULT NULL,p_package_condition collection.package_condition DEFAULT NULL,p_assembly_state collection.assembly_state DEFAULT NULL,p_completeness_state collection.completeness_state DEFAULT NULL,p_notes text DEFAULT NULL) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,collection,identity,app AS $$ DECLARE v_owner uuid; BEGIN SELECT e.owner_id INTO v_owner FROM collection.instances i JOIN collection.entries e USING(collection_entry_id) WHERE i.collection_instance_id=p_collection_instance_id FOR UPDATE OF i; PERFORM app.require_resource_owner(v_owner,'COLLECTION'); UPDATE collection.instances SET item_condition=coalesce(p_item_condition,item_condition),package_condition=coalesce(p_package_condition,package_condition),assembly_state=coalesce(p_assembly_state,assembly_state),completeness_state=coalesce(p_completeness_state,completeness_state),notes=coalesce(p_notes,notes) WHERE collection_instance_id=p_collection_instance_id; END $$;
CREATE OR REPLACE FUNCTION api.record_instance_adjustment(p_collection_instance_id uuid,p_type collection.adjustment_type,p_catalog_item_id uuid,p_part_variant_id uuid,p_quantity app.quantity,p_expected_requirement_group_id bigint DEFAULT NULL,p_replacement_catalog_item_id uuid DEFAULT NULL,p_replacement_part_variant_id uuid DEFAULT NULL,p_notes text DEFAULT NULL) RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,collection,app AS $$ DECLARE v_owner uuid; v_id bigint; BEGIN SELECT e.owner_id INTO v_owner FROM collection.instances i JOIN collection.entries e USING(collection_entry_id) WHERE i.collection_instance_id=p_collection_instance_id; PERFORM app.require_resource_owner(v_owner,'COLLECTION'); INSERT INTO collection.instance_adjustments(collection_instance_id,adjustment_type,expected_requirement_group_id,catalog_item_id,part_variant_id,quantity,replacement_catalog_item_id,replacement_part_variant_id,notes) VALUES(p_collection_instance_id,p_type,p_expected_requirement_group_id,p_catalog_item_id,p_part_variant_id,p_quantity,p_replacement_catalog_item_id,p_replacement_part_variant_id,p_notes) RETURNING instance_adjustment_id INTO v_id; RETURN v_id; END $$;
CREATE OR REPLACE FUNCTION api.clear_instance_adjustment(p_instance_adjustment_id bigint) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,collection,app AS $$ DECLARE v_owner uuid; BEGIN SELECT e.owner_id INTO v_owner FROM collection.instance_adjustments a JOIN collection.instances i ON i.collection_instance_id=a.collection_instance_id JOIN collection.entries e USING(collection_entry_id) WHERE a.instance_adjustment_id=p_instance_adjustment_id; PERFORM app.require_resource_owner(v_owner,'COLLECTION'); UPDATE collection.instance_adjustments SET cleared_at=now() WHERE instance_adjustment_id=p_instance_adjustment_id AND cleared_at IS NULL; END $$;

CREATE OR REPLACE FUNCTION api.get_instance_completeness(p_collection_instance_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path=pg_catalog,collection,definition,app
AS $$
DECLARE
    v_owner uuid;
    v_version uuid;
    v_missing numeric;
BEGIN
    SELECT e.owner_id,i.inventory_version_id
    INTO v_owner,v_version
    FROM collection.instances i
    JOIN collection.entries e USING(collection_entry_id)
    WHERE i.collection_instance_id=p_collection_instance_id;
    PERFORM app.require_resource_owner(v_owner,'COLLECTION');

    SELECT COALESCE(sum(quantity),0)
    INTO v_missing
    FROM collection.instance_adjustments
    WHERE collection_instance_id=p_collection_instance_id
      AND adjustment_type='MISSING'
      AND cleared_at IS NULL;

    RETURN jsonb_build_object(
        'instance_id',p_collection_instance_id,
        'inventory_version_id',v_version,
        'missing_quantity',v_missing,
        'complete',v_missing=0
    );
END;
$$;
