/*
===============================================================================
 File:           5000_Procedures/5140_grants_rls.sql
 Project:        BrickTrackr
 PostgreSQL:     16+
 Purpose:        Expose only the reviewed lifecycle procedure surface and keep
                 internal definition/authority helpers behind SECURITY DEFINER
                 boundaries.
===============================================================================
*/
\set ON_ERROR_STOP on

-- Runtime roles receive only the reviewed api.* surface.
REVOKE EXECUTE ON ALL ROUTINES IN SCHEMA api FROM PUBLIC,lego_api,lego_app;
GRANT USAGE ON SCHEMA api TO lego_api,lego_app;
REVOKE CREATE ON SCHEMA api FROM PUBLIC,lego_api,lego_app;

DO $grant_runtime$
DECLARE
    sig text;
    r regprocedure;
BEGIN
    FOREACH sig IN ARRAY ARRAY[
        'api.create_catalog_item(text,text,integer,integer,text)',
        'api.get_catalog_item(text,boolean)',
        'api.update_catalog_item(uuid,jsonb)',
        'api.create_moc_manifest(uuid,jsonb,text)',
        'api.get_catalog_manifest(uuid,integer)',
        'api.replace_moc_manifest(uuid,bigint,jsonb)',
        'api.edit_moc_manifest(uuid,bigint,jsonb)',
        'api.create_moc_manifest_version(uuid,bigint,text)',
        'api.list_moc_manifest_versions(uuid)',
        'api.fork_moc(uuid,text,uuid)',
        'api.create_custom_minifig_composition(uuid,jsonb,jsonb,text)',
        'api.get_minifig_composition(uuid,integer)',
        'api.replace_custom_minifig_composition(uuid,bigint,jsonb,jsonb)',
        'api.edit_custom_minifig_composition(uuid,bigint,jsonb)',
        'api.create_custom_minifig_composition_version(uuid,bigint,text)',
        'api.list_minifig_composition_versions(uuid)',
        'api.set_catalog_item_image(uuid,text,text,app.sha256_digest)',
        'api.remove_catalog_item_image(uuid)',
        'api.set_catalog_item_instructions(uuid,text,text,text,bigint,integer)',
        'api.remove_catalog_item_instructions(uuid)',
        'api.delete_moc(uuid,text)',
        'api.restore_moc(uuid)',
        'api.delete_custom_minifig(uuid)',
        'api.restore_custom_minifig(uuid)',
        'api.add_owned_instance(uuid,uuid,text)',
        'api.update_owned_instance(uuid,collection.item_condition,collection.package_condition,collection.assembly_state,collection.completeness_state,text)',
        'api.record_instance_adjustment(uuid,collection.adjustment_type,uuid,uuid,app.quantity,bigint,uuid,uuid,text)',
        'api.clear_instance_adjustment(bigint)',
        'api.get_instance_completeness(uuid)',
        'api.part_out_instance(uuid)',
        'api.assemble_minifig_instance(uuid)'
    ] LOOP
        r:=to_regprocedure(sig);
        IF r IS NULL THEN
            RAISE EXCEPTION 'Required lifecycle API routine missing: %',sig;
        END IF;
        EXECUTE format('GRANT EXECUTE ON ROUTINE %s TO lego_api,lego_app',r);
    END LOOP;
END
$grant_runtime$;

-- Import/system mutation surface. These are never normal-user APIs.
GRANT USAGE ON SCHEMA import TO lego_importer;
DO $grant_import$
DECLARE sig text; r regprocedure;
BEGIN
    FOREACH sig IN ARRAY ARRAY[
        'import.apply_source_field(uuid,smallint,text,jsonb)',
        'import.upsert_catalog_item(catalog.item_kind,text,text,smallint,text,text,integer,integer,integer)',
        'import.mark_source_mapping_missing(smallint,text,text,integer)',
        'import.sync_set_manifest(uuid,smallint,text,integer,jsonb,text)',
        'import.sync_minifig_composition(uuid,smallint,text,jsonb,jsonb,text)'
    ] LOOP
        r:=to_regprocedure(sig);
        IF r IS NULL THEN RAISE EXCEPTION 'Required importer routine missing: %',sig; END IF;
        EXECUTE format('REVOKE EXECUTE ON ROUTINE %s FROM PUBLIC',r);
        EXECUTE format('GRANT EXECUTE ON ROUTINE %s TO lego_importer',r);
    END LOOP;
END
$grant_import$;

-- Administrator-only correction/repair surface.
GRANT USAGE ON SCHEMA admin TO lego_admin;
DO $grant_admin$
DECLARE sig text; r regprocedure;
BEGIN
    FOREACH sig IN ARRAY ARRAY[
        'admin.set_catalog_item_override(uuid,text,jsonb,text)',
        'admin.clear_catalog_item_override(uuid,text)',
        'admin.remap_external_identifier(uuid,uuid,text)',
        'admin.create_definition_correction(uuid,text)',
        'admin.replace_set_manifest_correction(uuid,jsonb)',
        'admin.replace_minifig_composition_correction(uuid,jsonb,jsonb)',
        'admin.finalize_definition_correction(uuid)',
        'admin.activate_definition_correction(uuid,uuid)',
        'admin.clear_definition_correction(uuid)'
    ] LOOP
        r:=to_regprocedure(sig);
        IF r IS NULL THEN RAISE EXCEPTION 'Required administrator routine missing: %',sig; END IF;
        EXECUTE format('REVOKE EXECUTE ON ROUTINE %s FROM PUBLIC',r);
        EXECUTE format('GRANT EXECUTE ON ROUTINE %s TO lego_admin',r);
    END LOOP;
END
$grant_admin$;

-- Internal helpers are not runtime entry points.
DO $lock_helpers$
DECLARE sig text; r regprocedure;
BEGIN
    FOREACH sig IN ARRAY ARRAY[
        'app.require_active_user()',
        'app.require_actor_class(text[])',
        'app.require_resource_owner(uuid,text)',
        'app.generate_item_num(catalog.item_kind,uuid)',
        'app.build_catalog_item_json(uuid)',
        'app.build_catalog_manifest_json(uuid)',
        'app.build_minifig_composition_json(uuid)',
        'catalog.refresh_effective_catalog_field(uuid,text)',
        'definition.ensure_inventory_definition(uuid,definition.definition_kind)',
        'definition.lock_current_version(uuid)',
        'definition.assert_edit_revision(uuid,bigint)',
        'definition.next_semantic_version(uuid)',
        'definition.create_initial_version(uuid,text,uuid)',
        'definition.bump_edit_revision(uuid)',
        'definition.compute_inventory_version_hash(uuid)',
        'definition.clone_version_graph(uuid,uuid)',
        'definition.create_semantic_version(uuid,bigint,text)',
        'definition.load_moc_manifest_payload(uuid,jsonb,boolean)',
        'definition.load_minifig_composition_payload(uuid,jsonb,jsonb,boolean)',
        'collection.add_loose_part(uuid,uuid,numeric)',
        'collection.consume_loose_part(uuid,uuid,numeric)'
    ] LOOP
        r:=to_regprocedure(sig);
        IF r IS NOT NULL THEN
            EXECUTE format('REVOKE EXECUTE ON ROUTINE %s FROM PUBLIC,lego_api,lego_app',r);
        END IF;
    END LOOP;
END
$lock_helpers$;

-- Direct runtime-table mutation remains prohibited.
REVOKE ALL ON catalog.custom_minifigures,catalog.item_documents
FROM PUBLIC,lego_api,lego_app;
REVOKE ALL ON definition.minifig_compositions,definition.minifig_structural_components,
              definition.minifig_accessories
FROM PUBLIC,lego_api,lego_app;

-- Synchronize the existing runtime API allowlist when present.
DO $allowlist$
BEGIN
    IF to_regclass('app.runtime_api_allowlist') IS NOT NULL THEN
        INSERT INTO app.runtime_api_allowlist(routine_signature,purpose,anonymous_safe)
        VALUES
          ('api.get_catalog_item(text,boolean)','Canonical Catalog Item read.',true),
          ('api.create_catalog_item(text,text,integer,integer,text)','Create owner-controlled MOC/custom Minifig.',false),
          ('api.update_catalog_item(uuid,jsonb)','Update owner-writable Catalog Item metadata.',false),
          ('api.get_catalog_manifest(uuid,integer)','Read MOC current/historical Manifest.',true),
          ('api.get_minifig_composition(uuid,integer)','Read official/custom Minifig Composition.',true),
          ('api.part_out_instance(uuid)','Part out an owned physical instance.',false),
          ('api.assemble_minifig_instance(uuid)','Assemble a Minifig instance from loose inventory.',false)
        ON CONFLICT(routine_signature)
        DO UPDATE SET purpose=EXCLUDED.purpose,anonymous_safe=EXCLUDED.anonymous_safe;
    END IF;
END
$allowlist$;
