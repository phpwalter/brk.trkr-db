/* BrickTrackr 5020 - canonical Catalog Item representation */
\set ON_ERROR_STOP on
CREATE OR REPLACE FUNCTION app.build_catalog_item_json(p_catalog_item_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path=pg_catalog,catalog,moc,definition,app
AS $$
DECLARE v jsonb;
BEGIN
 SELECT jsonb_strip_nulls(jsonb_build_object(
   'item_num',i.item_num,'item_type',CASE i.item_kind WHEN 'MINIFIGURE' THEN 'minifig' WHEN 'CUSTOM_MINIFIGURE' THEN 'custom_minifig' WHEN 'MOC' THEN 'moc' WHEN 'SET' THEN 'set' ELSE lower(i.item_kind::text) END,'name',i.canonical_name,
   'visibility',lower(i.visibility::text),'year_released',coalesce(i.year_released,s.release_year),'theme_id',coalesce(i.theme_id,s.theme_id,mf.theme_id),'deleted_at',i.deleted_at,
   'created_at',i.created_at,'updated_at',i.updated_at,
   'image',jsonb_build_object('available',EXISTS(SELECT 1 FROM catalog.item_images im WHERE im.catalog_item_id=i.catalog_item_id AND im.is_primary)),
   'instructions',jsonb_build_object('available',EXISTS(SELECT 1 FROM catalog.item_documents d WHERE d.catalog_item_id=i.catalog_item_id AND d.document_type='INSTRUCTIONS' AND d.active)),
   '_links',jsonb_build_object('self',CASE i.item_kind WHEN 'MOC' THEN '/moc/'||i.item_num WHEN 'MINIFIGURE' THEN '/minifig/'||i.item_num WHEN 'CUSTOM_MINIFIGURE' THEN '/minifig/'||i.item_num ELSE '/catalog/items/'||i.item_num END)
 )) INTO v FROM catalog.items i LEFT JOIN catalog.sets s ON s.catalog_item_id=i.catalog_item_id LEFT JOIN catalog.minifigures mf ON mf.catalog_item_id=i.catalog_item_id WHERE i.catalog_item_id=p_catalog_item_id;
 IF v IS NULL THEN RAISE EXCEPTION 'Catalog item not found' USING ERRCODE='P0002'; END IF;
 RETURN v;
END $$;
