/* BrickTrackr 5010 - lifecycle support and authority helpers */
\set ON_ERROR_STOP on

-- Lifecycle support columns/types required by ITEM/MOC/MINIFIG contracts.
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type t JOIN pg_namespace n ON n.oid=t.typnamespace WHERE n.nspname='catalog' AND t.typname='catalog_visibility') THEN
        CREATE TYPE catalog.catalog_visibility AS ENUM ('PRIVATE_DRAFT','FAMILY','UNLISTED','PUBLIC');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_enum e JOIN pg_type t ON t.oid=e.enumtypid JOIN pg_namespace n ON n.oid=t.typnamespace WHERE n.nspname='catalog' AND t.typname='item_kind' AND e.enumlabel='CUSTOM_MINIFIGURE') THEN
        ALTER TYPE catalog.item_kind ADD VALUE 'CUSTOM_MINIFIGURE';
    END IF;
END $$;

ALTER TABLE catalog.items ADD COLUMN IF NOT EXISTS item_num text;
ALTER TABLE catalog.items ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES identity.owners(owner_id);
ALTER TABLE catalog.items ADD COLUMN IF NOT EXISTS year_released smallint CHECK (year_released IS NULL OR year_released BETWEEN 1930 AND 2200);
ALTER TABLE catalog.items ADD COLUMN IF NOT EXISTS theme_id integer REFERENCES reference.themes(theme_id);
ALTER TABLE catalog.items ADD COLUMN IF NOT EXISTS creator_user_id uuid REFERENCES identity.users(user_id);
ALTER TABLE catalog.items ADD COLUMN IF NOT EXISTS visibility catalog.catalog_visibility NOT NULL DEFAULT 'PUBLIC';
ALTER TABLE catalog.items ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE catalog.items ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX IF NOT EXISTS uq_catalog_items_item_num ON catalog.items(item_num) WHERE item_num IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_catalog_items_owner ON catalog.items(owner_id) WHERE owner_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_catalog_items_deleted ON catalog.items(deleted_at) WHERE deleted_at IS NOT NULL;

CREATE TABLE IF NOT EXISTS catalog.custom_minifigures (
    catalog_item_id uuid PRIMARY KEY REFERENCES catalog.items(catalog_item_id),
    theme_id integer REFERENCES reference.themes(theme_id),
    release_year smallint CHECK (release_year IS NULL OR release_year BETWEEN 1930 AND 2200)
);

-- Extend the controlled Minifig role vocabulary required by the lifecycle.
-- Existing baseline role codes remain valid; these additions add semantic
-- precision without reinterpreting historical compositions.
INSERT INTO reference.minifig_roles(role_code,display_name,is_structural,is_accessory,allows_multiple)
VALUES
    ('HIPS','Hips',true,false,true),
    ('EAR','Ear',true,false,true),
    ('OTHER_STRUCTURAL','Other Structural',true,false,true),
    ('HEADWEAR','Headwear',false,true,true),
    ('NECKWEAR','Neckwear',false,true,true),
    ('BACK_ACCESSORY','Back Accessory',false,true,true),
    ('HANDHELD_ACCESSORY','Handheld Accessory',false,true,true),
    ('WEAPON','Weapon',false,true,true),
    ('TOOL','Tool',false,true,true),
    ('OTHER_ACCESSORY','Other Accessory',false,true,true)
ON CONFLICT(role_code) DO NOTHING;


ALTER TABLE definition.requirement_groups ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE definition.requirement_groups ADD COLUMN IF NOT EXISTS is_alternate boolean NOT NULL DEFAULT false;
ALTER TABLE definition.requirement_options ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE definition.minifig_structural_components ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE definition.minifig_accessories ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE collection.instance_adjustments ADD COLUMN IF NOT EXISTS cleared_at timestamptz;

ALTER TABLE definition.requirement_options ADD COLUMN IF NOT EXISTS decorated_variant_id uuid;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='fk_requirement_options_decoration') THEN
        ALTER TABLE definition.requirement_options
        ADD CONSTRAINT fk_requirement_options_decoration
        FOREIGN KEY (decorated_variant_id, part_variant_id)
        REFERENCES catalog.decorated_variants(decorated_variant_id, part_variant_id)
        ON DELETE RESTRICT;
    END IF;
END $$;

ALTER TABLE definition.minifig_accessories ADD COLUMN IF NOT EXISTS accessory_role text;
ALTER TABLE definition.minifig_accessories ADD COLUMN IF NOT EXISTS decorated_variant_id uuid;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='fk_minifig_accessory_decoration') THEN
        ALTER TABLE definition.minifig_accessories
        ADD CONSTRAINT fk_minifig_accessory_decoration
        FOREIGN KEY (decorated_variant_id, part_variant_id)
        REFERENCES catalog.decorated_variants(decorated_variant_id, part_variant_id)
        ON DELETE RESTRICT;
    END IF;
END $$;


CREATE TABLE IF NOT EXISTS catalog.item_documents(
    item_document_id uuid PRIMARY KEY DEFAULT app.uuid_v7(),
    catalog_item_id uuid NOT NULL REFERENCES catalog.items(catalog_item_id),
    document_type text NOT NULL,
    storage_key text NOT NULL UNIQUE,
    file_name text,
    mime_type text,
    size_bytes bigint CHECK(size_bytes IS NULL OR size_bytes>=0),
    page_count integer CHECK(page_count IS NULL OR page_count>0),
    active boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    retired_at timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_item_documents_active_type
ON catalog.item_documents(catalog_item_id,document_type) WHERE active;


DROP INDEX IF EXISTS definition.uq_requirement_groups_version_key;
CREATE UNIQUE INDEX uq_requirement_groups_version_key
ON definition.requirement_groups(inventory_version_id,requirement_key)
WHERE requirement_key IS NOT NULL AND deleted_at IS NULL;
DROP INDEX IF EXISTS definition.uq_minifig_structural_identity;
CREATE UNIQUE INDEX uq_minifig_structural_identity
ON definition.minifig_structural_components(minifig_composition_id,semantic_role,side,position_index,part_variant_id,decorated_variant_id) NULLS NOT DISTINCT
WHERE deleted_at IS NULL;
DROP INDEX IF EXISTS definition.uq_minifig_accessory_identity;
CREATE UNIQUE INDEX uq_minifig_accessory_identity
ON definition.minifig_accessories(minifig_composition_id,accessory_role,position_index,part_variant_id,decorated_variant_id) NULLS NOT DISTINCT
WHERE deleted_at IS NULL;

ALTER TABLE definition.inventory_versions ADD COLUMN IF NOT EXISTS edit_revision bigint NOT NULL DEFAULT 1 CHECK (edit_revision >= 1);
ALTER TABLE definition.inventory_versions ADD COLUMN IF NOT EXISTS is_default boolean NOT NULL DEFAULT false;
ALTER TABLE definition.inventory_versions ADD COLUMN IF NOT EXISTS description text;
CREATE UNIQUE INDEX IF NOT EXISTS uq_inventory_versions_one_default
ON definition.inventory_versions(inventory_definition_id) WHERE is_default;


DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_catalog_custom_minifigures_kind') THEN
        CREATE TRIGGER trg_catalog_custom_minifigures_kind
        BEFORE INSERT OR UPDATE ON catalog.custom_minifigures
        FOR EACH ROW EXECUTE FUNCTION catalog.validate_subtype_kind('CUSTOM_MINIFIGURE');
    END IF;
END $$;

-- Best-effort public identity backfill from active external mappings for canonical items.
WITH ranked AS (
    SELECT ei.catalog_item_id,
           CASE WHEN ei.external_version IS NULL THEN ei.external_id ELSE ei.external_id||'-'||ei.external_version::text END AS public_num,
           row_number() OVER (PARTITION BY ei.catalog_item_id ORDER BY ei.last_seen_at DESC, ei.external_identifier_id) AS rn
    FROM catalog.external_identifiers ei
    WHERE ei.catalog_item_id IS NOT NULL AND ei.source_present
)
UPDATE catalog.items i
SET item_num=r.public_num
FROM ranked r
WHERE r.catalog_item_id=i.catalog_item_id AND r.rn=1 AND i.item_num IS NULL
  AND i.item_kind IN ('SET','MINIFIGURE');

CREATE OR REPLACE FUNCTION app.require_active_user()
RETURNS uuid
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path=pg_catalog,identity
AS $$
DECLARE v_user uuid;
BEGIN
  v_user := identity.current_user_id();
  IF NOT EXISTS (SELECT 1 FROM identity.users WHERE user_id=v_user AND account_status='ACTIVE') THEN
    RAISE EXCEPTION 'Active authenticated user required' USING ERRCODE='28000';
  END IF;
  RETURN v_user;
END $$;

CREATE OR REPLACE FUNCTION app.require_actor_class(p_allowed text[])
RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path=pg_catalog,app
AS $$
DECLARE v_actor text := app.current_actor_class();
BEGIN
  IF NOT (v_actor = ANY(p_allowed)) THEN
    RAISE EXCEPTION 'Actor class % is not authorized', v_actor USING ERRCODE='42501';
  END IF;
  RETURN v_actor;
END $$;

CREATE OR REPLACE FUNCTION app.require_resource_owner(p_owner_id uuid, p_capability text DEFAULT 'COLLECTION')
RETURNS uuid
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path=pg_catalog,identity,app
AS $$
DECLARE v_user uuid := app.require_active_user();
BEGIN
  IF p_owner_id IS NULL OR NOT identity.can_manage_owner(v_user,p_owner_id,p_capability) THEN
    RAISE EXCEPTION 'Resource owner authority required' USING ERRCODE='42501';
  END IF;
  RETURN v_user;
END $$;

CREATE OR REPLACE FUNCTION app.generate_item_num(p_kind catalog.item_kind, p_id uuid)
RETURNS text LANGUAGE sql IMMUTABLE SET search_path=pg_catalog AS $$
SELECT CASE p_kind
 WHEN 'MOC'::catalog.item_kind THEN 'MOC-'||upper(substr(replace(p_id::text,'-',''),1,12))
 WHEN 'CUSTOM_MINIFIGURE'::catalog.item_kind THEN 'CMF-'||upper(substr(replace(p_id::text,'-',''),1,12))
 ELSE upper(substr(replace(p_id::text,'-',''),1,16)) END $$;

-- Backfill current native MOC authority into the generic Catalog Item layer.
UPDATE catalog.items i SET owner_id=m.owner_id, creator_user_id=m.created_by_user_id,
 visibility=CASE m.visibility WHEN 'PRIVATE' THEN 'PRIVATE_DRAFT'::catalog.catalog_visibility WHEN 'FAMILY' THEN 'FAMILY'::catalog.catalog_visibility WHEN 'UNLISTED' THEN 'UNLISTED'::catalog.catalog_visibility ELSE 'PUBLIC'::catalog.catalog_visibility END,
 deleted_at=m.archived_at, updated_at=greatest(i.created_at,m.created_at)
FROM moc.mocs m WHERE m.catalog_item_id=i.catalog_item_id AND i.item_kind='MOC';
UPDATE catalog.items SET item_num=app.generate_item_num(item_kind,catalog_item_id)
WHERE item_num IS NULL AND item_kind IN ('MOC','CUSTOM_MINIFIGURE');
