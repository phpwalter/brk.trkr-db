/* BrickTrackr 5030 - generic Catalog Item create/get/update */
\set ON_ERROR_STOP on
CREATE OR REPLACE FUNCTION api.create_catalog_item(p_item_type text,p_name text,p_year_released integer DEFAULT NULL,p_theme_id integer DEFAULT NULL,p_visibility text DEFAULT 'private_draft')
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,catalog,identity,moc,app
AS $$
DECLARE v_user uuid; v_owner uuid; v_id uuid:=app.uuid_v7(); v_kind catalog.item_kind; v_vis catalog.catalog_visibility; v_num text;
BEGIN
 v_user:=app.require_active_user(); v_owner:=identity.ensure_owner_for_user(v_user);
 v_kind:=CASE lower(p_item_type) WHEN 'moc' THEN 'MOC'::catalog.item_kind WHEN 'custom_minifig' THEN 'CUSTOM_MINIFIGURE'::catalog.item_kind ELSE NULL END;
 IF v_kind IS NULL THEN RAISE EXCEPTION 'Catalog item type % is not user-creatable',p_item_type USING ERRCODE='42501'; END IF;
 v_vis:=CASE lower(p_visibility) WHEN 'private_draft' THEN 'PRIVATE_DRAFT' WHEN 'unlisted' THEN 'UNLISTED' WHEN 'public' THEN 'PUBLIC' ELSE NULL END;
 IF v_vis IS NULL THEN RAISE EXCEPTION 'Invalid visibility' USING ERRCODE='22023'; END IF;
 IF btrim(coalesce(p_name,''))='' THEN RAISE EXCEPTION 'Name is required' USING ERRCODE='22023'; END IF;
 v_num:=app.generate_item_num(v_kind,v_id);
 INSERT INTO catalog.items(catalog_item_id,item_kind,canonical_name,status,item_num,owner_id,creator_user_id,visibility,year_released,theme_id)
 VALUES(v_id,v_kind,p_name,'ACTIVE',v_num,v_owner,v_user,v_vis,p_year_released,p_theme_id);
 IF v_kind='MOC' THEN
   INSERT INTO catalog.mocs(catalog_item_id) VALUES(v_id);
   INSERT INTO moc.mocs(catalog_item_id,owner_id,title,visibility,created_by_user_id)
   VALUES(v_id,v_owner,p_name,CASE v_vis WHEN 'PRIVATE_DRAFT' THEN 'PRIVATE'::moc.visibility WHEN 'FAMILY' THEN 'FAMILY'::moc.visibility WHEN 'UNLISTED' THEN 'UNLISTED'::moc.visibility ELSE 'PUBLIC'::moc.visibility END,v_user);
 ELSE
   INSERT INTO catalog.custom_minifigures(catalog_item_id,theme_id,release_year) VALUES(v_id,p_theme_id,p_year_released);
 END IF;
 RETURN app.build_catalog_item_json(v_id);
END $$;

CREATE OR REPLACE FUNCTION api.get_catalog_item(p_item_num text,p_include_deleted boolean DEFAULT false)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path=pg_catalog,catalog,identity,app
AS $$
DECLARE v_id uuid; v_owner uuid; v_vis catalog.catalog_visibility; v_deleted timestamptz; v_kind catalog.item_kind; v_user uuid:=identity.current_user_id_optional();
BEGIN
 SELECT catalog_item_id,owner_id,visibility,deleted_at,item_kind INTO v_id,v_owner,v_vis,v_deleted,v_kind FROM catalog.items WHERE item_num=p_item_num;
 IF NOT FOUND THEN RAISE EXCEPTION 'Catalog item not found' USING ERRCODE='P0002'; END IF;
 IF v_deleted IS NOT NULL AND NOT (p_include_deleted AND v_user IS NOT NULL AND v_owner IS NOT NULL AND identity.can_manage_owner(v_user,v_owner,CASE WHEN v_kind='MOC' THEN 'MOCS' ELSE 'COLLECTION' END)) THEN RAISE EXCEPTION 'Catalog item not found' USING ERRCODE='P0002'; END IF;
 IF v_vis IN ('PRIVATE_DRAFT','FAMILY') AND (v_user IS NULL OR v_owner IS NULL OR NOT identity.can_view_owner(v_user,v_owner,CASE WHEN v_kind='MOC' THEN 'MOCS' ELSE 'COLLECTION' END)) THEN RAISE EXCEPTION 'Catalog item not found' USING ERRCODE='P0002'; END IF;
 RETURN app.build_catalog_item_json(v_id);
END $$;

CREATE OR REPLACE FUNCTION api.update_catalog_item(p_catalog_item_id uuid,p_changes jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,catalog,moc,identity,app
AS $$
DECLARE i catalog.items%ROWTYPE; v_user uuid; v_name text; v_vis catalog.catalog_visibility;
BEGIN
 SELECT * INTO i FROM catalog.items WHERE catalog_item_id=p_catalog_item_id FOR UPDATE;
 IF NOT FOUND OR i.deleted_at IS NOT NULL THEN RAISE EXCEPTION 'Catalog item not found' USING ERRCODE='P0002'; END IF;
 IF i.item_kind NOT IN ('MOC','CUSTOM_MINIFIGURE') THEN RAISE EXCEPTION 'Canonical source-controlled item is read-only' USING ERRCODE='42501'; END IF;
 v_user:=app.require_resource_owner(i.owner_id,CASE WHEN i.item_kind='MOC' THEN 'MOCS' ELSE 'COLLECTION' END);
 IF EXISTS (SELECT 1 FROM jsonb_object_keys(p_changes) k WHERE k NOT IN ('name','year_released','theme_id','visibility')) THEN RAISE EXCEPTION 'Payload contains non-writable Catalog Item fields' USING ERRCODE='22023'; END IF;
 IF p_changes ? 'name' THEN v_name:=p_changes->>'name'; IF btrim(coalesce(v_name,''))='' THEN RAISE EXCEPTION 'name cannot be blank' USING ERRCODE='22023'; END IF; UPDATE catalog.items SET canonical_name=v_name,updated_at=now() WHERE catalog_item_id=p_catalog_item_id; UPDATE moc.mocs SET title=v_name WHERE catalog_item_id=p_catalog_item_id AND i.item_kind='MOC'; END IF;
 IF p_changes ? 'visibility' THEN v_vis:=CASE lower(p_changes->>'visibility') WHEN 'private_draft' THEN 'PRIVATE_DRAFT' WHEN 'unlisted' THEN 'UNLISTED' WHEN 'public' THEN 'PUBLIC' ELSE NULL END; IF v_vis IS NULL THEN RAISE EXCEPTION 'Invalid visibility' USING ERRCODE='22023'; END IF; UPDATE catalog.items SET visibility=v_vis,updated_at=now() WHERE catalog_item_id=p_catalog_item_id; UPDATE moc.mocs SET visibility=CASE v_vis WHEN 'PRIVATE_DRAFT' THEN 'PRIVATE'::moc.visibility WHEN 'FAMILY' THEN 'FAMILY'::moc.visibility WHEN 'UNLISTED' THEN 'UNLISTED'::moc.visibility ELSE 'PUBLIC'::moc.visibility END WHERE catalog_item_id=p_catalog_item_id AND i.item_kind='MOC'; END IF;
 IF p_changes ? 'year_released' THEN UPDATE catalog.items SET year_released=(p_changes->>'year_released')::smallint,updated_at=now() WHERE catalog_item_id=p_catalog_item_id; END IF;
 IF p_changes ? 'theme_id' THEN UPDATE catalog.items SET theme_id=(p_changes->>'theme_id')::integer,updated_at=now() WHERE catalog_item_id=p_catalog_item_id; END IF;
 IF i.item_kind='CUSTOM_MINIFIGURE' THEN UPDATE catalog.custom_minifigures SET release_year=CASE WHEN p_changes?'year_released' THEN (p_changes->>'year_released')::smallint ELSE release_year END, theme_id=CASE WHEN p_changes?'theme_id' THEN (p_changes->>'theme_id')::integer ELSE theme_id END WHERE catalog_item_id=p_catalog_item_id; END IF;
 RETURN app.build_catalog_item_json(p_catalog_item_id);
END $$;
