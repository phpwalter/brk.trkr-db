/*
===============================================================================
 File:           5000_Procedures/5130_part_out_assembly.sql
 Project:        BrickTrackr
 PostgreSQL:     16+
 Purpose:        Transactional physical inventory transfer for part-out and
                 Minifig assembly. Canonical definitions are never mutated.
===============================================================================
*/
\set ON_ERROR_STOP on

CREATE OR REPLACE FUNCTION collection.add_loose_part(
    p_owner_id uuid,
    p_part_variant_id uuid,
    p_quantity numeric
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,collection
AS $$
DECLARE
    v_entry uuid;
BEGIN
    IF p_quantity<=0 THEN
        RAISE EXCEPTION 'Quantity must be positive' USING ERRCODE='22023';
    END IF;

    SELECT collection_entry_id INTO v_entry
    FROM collection.entries
    WHERE owner_id=p_owner_id
      AND part_variant_id=p_part_variant_id
      AND status='ACTIVE'
    ORDER BY created_at
    LIMIT 1
    FOR UPDATE;

    IF v_entry IS NULL THEN
        INSERT INTO collection.entries(owner_id,part_variant_id,quantity)
        VALUES(p_owner_id,p_part_variant_id,p_quantity)
        RETURNING collection_entry_id INTO v_entry;
    ELSE
        UPDATE collection.entries
        SET quantity=quantity+p_quantity
        WHERE collection_entry_id=v_entry;
    END IF;
    RETURN v_entry;
END;
$$;

CREATE OR REPLACE FUNCTION collection.consume_loose_part(
    p_owner_id uuid,
    p_part_variant_id uuid,
    p_quantity numeric
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,collection
AS $$
DECLARE
    r record;
    v_remaining numeric:=p_quantity;
    v_take numeric;
BEGIN
    IF p_quantity<=0 THEN
        RAISE EXCEPTION 'Quantity must be positive' USING ERRCODE='22023';
    END IF;

    IF COALESCE((SELECT sum(quantity) FROM collection.entries
                 WHERE owner_id=p_owner_id AND part_variant_id=p_part_variant_id AND status='ACTIVE'),0) < p_quantity THEN
        RAISE EXCEPTION 'Insufficient loose inventory for part variant %',p_part_variant_id
            USING ERRCODE='55000';
    END IF;

    FOR r IN
        SELECT collection_entry_id,quantity
        FROM collection.entries
        WHERE owner_id=p_owner_id
          AND part_variant_id=p_part_variant_id
          AND status='ACTIVE'
        ORDER BY created_at,collection_entry_id
        FOR UPDATE
    LOOP
        EXIT WHEN v_remaining<=0;
        v_take:=least(r.quantity,v_remaining);
        IF r.quantity=v_take THEN
            UPDATE collection.entries
            SET status='ARCHIVED',archived_at=now()
            WHERE collection_entry_id=r.collection_entry_id;
        ELSE
            UPDATE collection.entries
            SET quantity=quantity-v_take
            WHERE collection_entry_id=r.collection_entry_id;
        END IF;
        v_remaining:=v_remaining-v_take;
    END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION api.part_out_instance(p_collection_instance_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,collection,definition,app
AS $$
DECLARE
    v_owner uuid;
    v_version uuid;
    v_state collection.assembly_state;
    v_kind definition.definition_kind;
    r record;
    v_missing numeric;
    v_added numeric:=0;
BEGIN
    SELECT e.owner_id,i.inventory_version_id,i.assembly_state
    INTO v_owner,v_version,v_state
    FROM collection.instances i
    JOIN collection.entries e USING(collection_entry_id)
    WHERE i.collection_instance_id=p_collection_instance_id
    FOR UPDATE OF i;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'Owned instance not found' USING ERRCODE='P0002';
    END IF;
    PERFORM app.require_resource_owner(v_owner,'COLLECTION');
    IF v_state='PARTED_OUT' THEN
        RAISE EXCEPTION 'Instance is already parted out' USING ERRCODE='55000';
    END IF;
    IF v_version IS NULL THEN
        RAISE EXCEPTION 'Expected inventory/composition version is required for part-out' USING ERRCODE='55000';
    END IF;

    SELECT d.definition_kind INTO v_kind
    FROM definition.inventory_versions iv
    JOIN definition.inventory_definitions d USING(inventory_definition_id)
    WHERE iv.inventory_version_id=v_version;

    IF v_kind='MINIFIG_COMPOSITION' THEN
        FOR r IN
            SELECT part_variant_id,sum(qty)::numeric AS qty
            FROM (
                SELECT c.part_variant_id,c.quantity::numeric qty
                FROM definition.minifig_compositions mc
                JOIN definition.minifig_structural_components c USING(minifig_composition_id)
                WHERE mc.inventory_version_id=v_version AND c.deleted_at IS NULL
                UNION ALL
                SELECT a.part_variant_id,a.quantity::numeric
                FROM definition.minifig_compositions mc
                JOIN definition.minifig_accessories a USING(minifig_composition_id)
                WHERE mc.inventory_version_id=v_version AND a.deleted_at IS NULL
            ) q
            GROUP BY part_variant_id
        LOOP
            SELECT COALESCE(sum(a.quantity),0)
            INTO v_missing
            FROM collection.instance_adjustments a
            WHERE a.collection_instance_id=p_collection_instance_id
              AND a.adjustment_type IN ('MISSING','SUBSTITUTED')
              AND a.cleared_at IS NULL
              AND a.part_variant_id=r.part_variant_id;

            IF r.qty-v_missing>0 THEN
                PERFORM collection.add_loose_part(v_owner,r.part_variant_id,r.qty-v_missing);
                v_added:=v_added+(r.qty-v_missing);
            END IF;
        END LOOP;
    ELSE
        FOR r IN
            SELECT o.part_variant_id,
                   sum(g.required_quantity*o.option_quantity)::numeric qty,
                   g.requirement_group_id
            FROM definition.requirement_groups g
            JOIN definition.requirement_options o USING(requirement_group_id)
            WHERE g.inventory_version_id=v_version
              AND g.deleted_at IS NULL
              AND o.deleted_at IS NULL
              AND g.is_required
              AND NOT g.is_spare
              AND NOT g.is_alternate
              AND o.part_variant_id IS NOT NULL
              AND o.is_primary
            GROUP BY o.part_variant_id,g.requirement_group_id
        LOOP
            SELECT COALESCE(sum(a.quantity),0)
            INTO v_missing
            FROM collection.instance_adjustments a
            WHERE a.collection_instance_id=p_collection_instance_id
              AND a.adjustment_type IN ('MISSING','SUBSTITUTED')
              AND a.cleared_at IS NULL
              AND (
                    a.expected_requirement_group_id=r.requirement_group_id
                    OR (a.expected_requirement_group_id IS NULL AND a.part_variant_id=r.part_variant_id)
                  );
            IF r.qty-v_missing>0 THEN
                PERFORM collection.add_loose_part(v_owner,r.part_variant_id,r.qty-v_missing);
                v_added:=v_added+(r.qty-v_missing);
            END IF;
        END LOOP;
    END IF;

    -- Add actual extra physical parts and substitution replacements. Expected
    -- substituted components were already deducted above, so only the real
    -- replacement part is transferred here. Catalog-item substitutions are
    -- intentionally not converted into loose part inventory.
    FOR r IN
        SELECT part_variant_id,sum(quantity)::numeric AS qty
        FROM (
            SELECT a.part_variant_id,a.quantity
            FROM collection.instance_adjustments a
            WHERE a.collection_instance_id=p_collection_instance_id
              AND a.adjustment_type='EXTRA'
              AND a.cleared_at IS NULL
              AND a.part_variant_id IS NOT NULL
            UNION ALL
            SELECT a.replacement_part_variant_id,a.quantity
            FROM collection.instance_adjustments a
            WHERE a.collection_instance_id=p_collection_instance_id
              AND a.adjustment_type='SUBSTITUTED'
              AND a.cleared_at IS NULL
              AND a.replacement_part_variant_id IS NOT NULL
        ) x
        GROUP BY part_variant_id
    LOOP
        PERFORM collection.add_loose_part(v_owner,r.part_variant_id,r.qty);
        v_added:=v_added+r.qty;
    END LOOP;

    UPDATE collection.instances
    SET assembly_state='PARTED_OUT',completeness_state='UNKNOWN'
    WHERE collection_instance_id=p_collection_instance_id;

    RETURN jsonb_build_object(
        'parted_out',true,
        'instance_id',p_collection_instance_id,
        'loose_quantity_added',v_added
    );
END;
$$;

CREATE OR REPLACE FUNCTION api.assemble_minifig_instance(p_collection_instance_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,collection,definition,app
AS $$
DECLARE
    v_owner uuid;
    v_version uuid;
    v_kind definition.definition_kind;
    r record;
    v_consumed numeric:=0;
BEGIN
    SELECT e.owner_id,i.inventory_version_id
    INTO v_owner,v_version
    FROM collection.instances i
    JOIN collection.entries e USING(collection_entry_id)
    WHERE i.collection_instance_id=p_collection_instance_id
    FOR UPDATE OF i;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'Owned instance not found' USING ERRCODE='P0002';
    END IF;
    PERFORM app.require_resource_owner(v_owner,'COLLECTION');
    IF v_version IS NULL THEN
        RAISE EXCEPTION 'Expected composition version is required' USING ERRCODE='55000';
    END IF;

    SELECT d.definition_kind INTO v_kind
    FROM definition.inventory_versions iv
    JOIN definition.inventory_definitions d USING(inventory_definition_id)
    WHERE iv.inventory_version_id=v_version;
    IF v_kind<>'MINIFIG_COMPOSITION' THEN
        RAISE EXCEPTION 'Minifig Composition version required for assembly' USING ERRCODE='22023';
    END IF;

    -- Check all balances before consuming anything; transaction then preserves atomicity.
    FOR r IN
        SELECT part_variant_id,sum(qty)::numeric AS qty
        FROM (
            SELECT c.part_variant_id,c.quantity::numeric qty
            FROM definition.minifig_compositions mc
            JOIN definition.minifig_structural_components c USING(minifig_composition_id)
            WHERE mc.inventory_version_id=v_version AND c.deleted_at IS NULL
            UNION ALL
            SELECT a.part_variant_id,a.quantity::numeric
            FROM definition.minifig_compositions mc
            JOIN definition.minifig_accessories a USING(minifig_composition_id)
            WHERE mc.inventory_version_id=v_version AND a.deleted_at IS NULL
        ) q
        GROUP BY part_variant_id
    LOOP
        IF COALESCE((SELECT sum(quantity) FROM collection.entries
                     WHERE owner_id=v_owner AND part_variant_id=r.part_variant_id AND status='ACTIVE'),0) < r.qty THEN
            RAISE EXCEPTION 'Insufficient loose inventory for part variant %',r.part_variant_id
                USING ERRCODE='55000';
        END IF;
    END LOOP;

    FOR r IN
        SELECT part_variant_id,sum(qty)::numeric AS qty
        FROM (
            SELECT c.part_variant_id,c.quantity::numeric qty
            FROM definition.minifig_compositions mc
            JOIN definition.minifig_structural_components c USING(minifig_composition_id)
            WHERE mc.inventory_version_id=v_version AND c.deleted_at IS NULL
            UNION ALL
            SELECT a.part_variant_id,a.quantity::numeric
            FROM definition.minifig_compositions mc
            JOIN definition.minifig_accessories a USING(minifig_composition_id)
            WHERE mc.inventory_version_id=v_version AND a.deleted_at IS NULL
        ) q
        GROUP BY part_variant_id
    LOOP
        PERFORM collection.consume_loose_part(v_owner,r.part_variant_id,r.qty);
        v_consumed:=v_consumed+r.qty;
    END LOOP;

    UPDATE collection.instance_adjustments
    SET cleared_at=now()
    WHERE collection_instance_id=p_collection_instance_id
      AND adjustment_type='MISSING'
      AND cleared_at IS NULL;

    UPDATE collection.instances
    SET assembly_state='BUILT',completeness_state='COMPLETE'
    WHERE collection_instance_id=p_collection_instance_id;

    RETURN jsonb_build_object(
        'assembled',true,
        'instance_id',p_collection_instance_id,
        'loose_quantity_consumed',v_consumed
    );
END;
$$;
