/*
===============================================================================
 File:           5000_Procedures/5050_definition_graph_clone.sql
 Project:        BrickTrackr
 PostgreSQL:     16+
 Purpose:        Complete semantic-version graph snapshot and safe default
                 transition for MOC Manifests and Minifig Compositions.
 Depends On:     5010, 5040
===============================================================================
*/
\set ON_ERROR_STOP on

CREATE OR REPLACE FUNCTION definition.compute_inventory_version_hash(p_version_id uuid)
RETURNS app.sha256_digest
LANGUAGE sql
STABLE
SET search_path = pg_catalog, public, definition
AS $$
WITH payload AS (
    SELECT jsonb_build_object(
        'groups', COALESCE((
            SELECT jsonb_agg(jsonb_build_object(
                'key',g.requirement_key,
                'qty',g.required_quantity,
                'rule',g.fulfillment_rule,
                'required',g.is_required,
                'spare',g.is_spare,
                'alternate',g.is_alternate,
                'options',COALESCE((
                    SELECT jsonb_agg(jsonb_build_object(
                        'item',o.catalog_item_id,
                        'variant',o.part_variant_id,
                        'decorated',o.decorated_variant_id,
                        'qty',o.option_quantity,
                        'primary',o.is_primary
                    ) ORDER BY o.requirement_option_id)
                    FROM definition.requirement_options o
                    WHERE o.requirement_group_id=g.requirement_group_id
                      AND o.deleted_at IS NULL
                ),'[]'::jsonb)
            ) ORDER BY g.requirement_key,g.requirement_group_id)
            FROM definition.requirement_groups g
            WHERE g.inventory_version_id=p_version_id
              AND g.deleted_at IS NULL
        ),'[]'::jsonb),
        'subassemblies',COALESCE((
            SELECT jsonb_agg(jsonb_build_object(
                'key',s.subassembly_key,
                'parent',p.subassembly_key,
                'name',s.display_name,
                'position',s.position_index
            ) ORDER BY s.subassembly_key)
            FROM definition.manifest_subassemblies s
            LEFT JOIN definition.manifest_subassemblies p
              ON p.manifest_subassembly_id=s.parent_subassembly_id
            WHERE s.inventory_version_id=p_version_id
        ),'[]'::jsonb),
        'minifig',COALESCE((
            SELECT jsonb_build_object(
                'structural',COALESCE((
                    SELECT jsonb_agg(jsonb_build_object(
                        'role',c.semantic_role,'side',c.side,'position',c.position_index,
                        'variant',c.part_variant_id,'decorated',c.decorated_variant_id,'qty',c.quantity
                    ) ORDER BY c.semantic_role,c.side,c.position_index,c.part_variant_id)
                    FROM definition.minifig_structural_components c
                    WHERE c.minifig_composition_id=mc.minifig_composition_id
                      AND c.deleted_at IS NULL
                ),'[]'::jsonb),
                'accessories',COALESCE((
                    SELECT jsonb_agg(jsonb_build_object(
                        'role',a.accessory_role,'position',a.position_index,
                        'variant',a.part_variant_id,'decorated',a.decorated_variant_id,'qty',a.quantity
                    ) ORDER BY a.accessory_role,a.position_index,a.part_variant_id)
                    FROM definition.minifig_accessories a
                    WHERE a.minifig_composition_id=mc.minifig_composition_id
                      AND a.deleted_at IS NULL
                ),'[]'::jsonb)
            )
            FROM definition.minifig_compositions mc
            WHERE mc.inventory_version_id=p_version_id
        ),'{}'::jsonb)
    ) AS j
)
SELECT public.digest(convert_to(j::text,'UTF8'),'sha256')::app.sha256_digest
FROM payload;
$$;

CREATE OR REPLACE FUNCTION definition.clone_version_graph(p_from uuid,p_to uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, definition
AS $$
DECLARE
    r record;
    v_new_group bigint;
    v_new_comp uuid;
    v_inserted integer;
BEGIN
    IF p_from=p_to THEN
        RAISE EXCEPTION 'Source and destination versions must differ' USING ERRCODE='22023';
    END IF;
    IF NOT EXISTS(SELECT 1 FROM definition.inventory_versions WHERE inventory_version_id=p_from)
       OR NOT EXISTS(SELECT 1 FROM definition.inventory_versions WHERE inventory_version_id=p_to) THEN
        RAISE EXCEPTION 'Source and destination versions must exist' USING ERRCODE='P0002';
    END IF;

    CREATE TEMP TABLE IF NOT EXISTS bt_group_map(old_id bigint PRIMARY KEY,new_id bigint NOT NULL UNIQUE) ON COMMIT DROP;
    CREATE TEMP TABLE IF NOT EXISTS bt_subassembly_map(old_id uuid PRIMARY KEY,new_id uuid NOT NULL UNIQUE) ON COMMIT DROP;
    TRUNCATE bt_group_map;
    TRUNCATE bt_subassembly_map;

    FOR r IN
        SELECT * FROM definition.requirement_groups
        WHERE inventory_version_id=p_from AND deleted_at IS NULL
        ORDER BY requirement_group_id
    LOOP
        INSERT INTO definition.requirement_groups(
            inventory_version_id,required_quantity,fulfillment_rule,minimum_options,
            is_required,is_spare,is_alternate,sort_order,notes,requirement_key,deleted_at
        ) VALUES(
            p_to,r.required_quantity,r.fulfillment_rule,r.minimum_options,
            r.is_required,r.is_spare,r.is_alternate,r.sort_order,r.notes,r.requirement_key,NULL
        ) RETURNING requirement_group_id INTO v_new_group;
        INSERT INTO bt_group_map VALUES(r.requirement_group_id,v_new_group);
    END LOOP;

    INSERT INTO definition.requirement_options(
        requirement_group_id,catalog_item_id,part_variant_id,decorated_variant_id,
        option_quantity,is_primary,minifig_role_id,side,position_index,notes,deleted_at
    )
    SELECT gm.new_id,o.catalog_item_id,o.part_variant_id,o.decorated_variant_id,
           o.option_quantity,o.is_primary,o.minifig_role_id,o.side,o.position_index,o.notes,NULL
    FROM definition.requirement_options o
    JOIN bt_group_map gm ON gm.old_id=o.requirement_group_id
    WHERE o.deleted_at IS NULL;

    -- Manifest subassemblies: roots first, then descendants once parent mapped.
    INSERT INTO definition.manifest_subassemblies(
        inventory_version_id,parent_subassembly_id,subassembly_key,display_name,position_index
    )
    SELECT p_to,NULL,s.subassembly_key,s.display_name,s.position_index
    FROM definition.manifest_subassemblies s
    WHERE s.inventory_version_id=p_from AND s.parent_subassembly_id IS NULL;

    INSERT INTO bt_subassembly_map(old_id,new_id)
    SELECT src.manifest_subassembly_id,dst.manifest_subassembly_id
    FROM definition.manifest_subassemblies src
    JOIN definition.manifest_subassemblies dst
      ON dst.inventory_version_id=p_to AND dst.subassembly_key=src.subassembly_key
    WHERE src.inventory_version_id=p_from AND src.parent_subassembly_id IS NULL;

    LOOP
        WITH candidates AS (
            SELECT src.*,pm.new_id AS new_parent
            FROM definition.manifest_subassemblies src
            JOIN bt_subassembly_map pm ON pm.old_id=src.parent_subassembly_id
            LEFT JOIN bt_subassembly_map own ON own.old_id=src.manifest_subassembly_id
            WHERE src.inventory_version_id=p_from AND own.old_id IS NULL
        ), ins AS (
            INSERT INTO definition.manifest_subassemblies(
                inventory_version_id,parent_subassembly_id,subassembly_key,display_name,position_index
            )
            SELECT p_to,new_parent,subassembly_key,display_name,position_index FROM candidates
            RETURNING manifest_subassembly_id,subassembly_key
        )
        INSERT INTO bt_subassembly_map(old_id,new_id)
        SELECT src.manifest_subassembly_id,ins.manifest_subassembly_id
        FROM ins
        JOIN definition.manifest_subassemblies src
          ON src.inventory_version_id=p_from AND src.subassembly_key=ins.subassembly_key
        ON CONFLICT(old_id) DO NOTHING;
        GET DIAGNOSTICS v_inserted=ROW_COUNT;
        EXIT WHEN v_inserted=0;
    END LOOP;

    IF EXISTS(
        SELECT 1 FROM definition.manifest_subassemblies s
        LEFT JOIN bt_subassembly_map m ON m.old_id=s.manifest_subassembly_id
        WHERE s.inventory_version_id=p_from AND m.old_id IS NULL
    ) THEN
        RAISE EXCEPTION 'Manifest subassembly graph could not be completely cloned' USING ERRCODE='23514';
    END IF;

    INSERT INTO definition.manifest_requirement_placements(
        requirement_group_id,manifest_subassembly_id,inventory_version_id,position_index
    )
    SELECT gm.new_id,sm.new_id,p_to,p.position_index
    FROM definition.manifest_requirement_placements p
    JOIN bt_group_map gm ON gm.old_id=p.requirement_group_id
    JOIN bt_subassembly_map sm ON sm.old_id=p.manifest_subassembly_id
    WHERE p.inventory_version_id=p_from;

    IF EXISTS(SELECT 1 FROM definition.minifig_compositions WHERE inventory_version_id=p_from) THEN
        INSERT INTO definition.minifig_compositions(inventory_version_id)
        VALUES(p_to) RETURNING minifig_composition_id INTO v_new_comp;

        INSERT INTO definition.minifig_structural_components(
            minifig_composition_id,minifig_role_id,semantic_role,side,position_index,
            part_variant_id,decorated_variant_id,quantity,deleted_at
        )
        SELECT v_new_comp,c.minifig_role_id,c.semantic_role,c.side,c.position_index,
               c.part_variant_id,c.decorated_variant_id,c.quantity,NULL
        FROM definition.minifig_structural_components c
        JOIN definition.minifig_compositions mc USING(minifig_composition_id)
        WHERE mc.inventory_version_id=p_from AND c.deleted_at IS NULL;

        INSERT INTO definition.minifig_accessories(
            minifig_composition_id,part_variant_id,quantity,position_index,
            accessory_role,decorated_variant_id,deleted_at
        )
        SELECT v_new_comp,a.part_variant_id,a.quantity,a.position_index,
               a.accessory_role,a.decorated_variant_id,NULL
        FROM definition.minifig_accessories a
        JOIN definition.minifig_compositions mc USING(minifig_composition_id)
        WHERE mc.inventory_version_id=p_from AND a.deleted_at IS NULL;
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION definition.create_semantic_version(
    p_current_version_id uuid,
    p_expected_revision bigint,
    p_description text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, definition, identity, app
AS $$
DECLARE
    cur definition.inventory_versions%ROWTYPE;
    v_new uuid;
    v_num integer;
    v_try integer:=0;
    v_constraint text;
    v_user uuid:=identity.current_user_id();
BEGIN
    SELECT * INTO cur
    FROM definition.inventory_versions
    WHERE inventory_version_id=p_current_version_id
    FOR UPDATE;

    IF NOT FOUND OR NOT cur.is_default OR cur.status='FINALIZED' THEN
        RAISE EXCEPTION 'Editable current/default version required' USING ERRCODE='55000';
    END IF;
    IF cur.edit_revision<>p_expected_revision THEN
        RAISE EXCEPTION 'Edit revision precondition failed' USING ERRCODE='40001';
    END IF;

    LOOP
        v_num:=definition.next_semantic_version(cur.inventory_definition_id);
        BEGIN
            INSERT INTO definition.inventory_versions(
                inventory_definition_id,semantic_version,status,created_by_user_id,
                edit_revision,is_default,description
            ) VALUES(
                cur.inventory_definition_id,v_num,'DRAFT',v_user,1,false,p_description
            ) RETURNING inventory_version_id INTO v_new;
            EXIT;
        EXCEPTION WHEN unique_violation THEN
            GET STACKED DIAGNOSTICS v_constraint=CONSTRAINT_NAME;
            v_try:=v_try+1;
            IF v_constraint<>'uq_inventory_versions_number' OR v_try>1 THEN
                RAISE;
            END IF;
        END;
    END LOOP;

    PERFORM definition.clone_version_graph(cur.inventory_version_id,v_new);

    -- Safe transition: new row remains non-default until old default is demoted.
    UPDATE definition.inventory_versions
    SET is_default=false,
        status='FINALIZED',
        semantic_hash=COALESCE(semantic_hash,definition.compute_inventory_version_hash(inventory_version_id)),
        finalized_at=COALESCE(finalized_at,now())
    WHERE inventory_version_id=cur.inventory_version_id;

    UPDATE definition.inventory_versions
    SET is_default=true
    WHERE inventory_version_id=v_new;

    RETURN v_new;
END;
$$;
