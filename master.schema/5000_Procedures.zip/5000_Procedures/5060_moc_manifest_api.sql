/*
===============================================================================
 File:           5000_Procedures/5060_moc_manifest_api.sql
 Project:        BrickTrackr
 PostgreSQL:     16+
 Purpose:        MOC Manifest lifecycle API: create/read/replace/patch/version/
                 history/fork with owner authorization and optimistic concurrency.
 Depends On:     5010-5050 lifecycle modules
===============================================================================
*/
\set ON_ERROR_STOP on

CREATE OR REPLACE FUNCTION definition.moc_requirement_key(p_requirement jsonb)
RETURNS text
LANGUAGE sql
IMMUTABLE
SET search_path = pg_catalog
AS $$
SELECT md5(concat_ws('|',
    coalesce(p_requirement->>'part_variant_id',''),
    coalesce(p_requirement->>'decorated_variant_id',''),
    coalesce(p_requirement->>'catalog_item_id',''),
    coalesce(p_requirement->>'subassembly_key',''),
    coalesce(p_requirement->>'is_spare','false'),
    coalesce(p_requirement->>'is_alternate','false')
));
$$;

CREATE OR REPLACE FUNCTION app.build_catalog_manifest_json(p_inventory_version_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, definition, catalog, app
AS $$
DECLARE
    v jsonb;
BEGIN
    SELECT jsonb_build_object(
        'version', iv.semantic_version,
        'edit_revision', CASE WHEN iv.is_default THEN iv.edit_revision ELSE NULL END,
        'is_default', iv.is_default,
        'description', iv.description,
        'num_parts', COALESCE((
            SELECT sum(g.required_quantity*o.option_quantity)::bigint
            FROM definition.requirement_groups g
            JOIN definition.requirement_options o ON o.requirement_group_id=g.requirement_group_id
            WHERE g.inventory_version_id=iv.inventory_version_id
              AND g.deleted_at IS NULL AND o.deleted_at IS NULL
              AND g.is_required AND NOT g.is_spare AND NOT g.is_alternate
              AND o.part_variant_id IS NOT NULL AND o.is_primary
        ),0),
        'num_spares', COALESCE((
            SELECT sum(g.required_quantity*o.option_quantity)::bigint
            FROM definition.requirement_groups g
            JOIN definition.requirement_options o ON o.requirement_group_id=g.requirement_group_id
            WHERE g.inventory_version_id=iv.inventory_version_id
              AND g.deleted_at IS NULL AND o.deleted_at IS NULL
              AND g.is_spare AND o.part_variant_id IS NOT NULL AND o.is_primary
        ),0),
        'parts', COALESCE((
            SELECT jsonb_agg(
                jsonb_strip_nulls(jsonb_build_object(
                    'requirement_key', g.requirement_key,
                    'quantity', g.required_quantity,
                    'is_spare', g.is_spare,
                    'is_alternate', g.is_alternate,
                    'part_variant_id', o.part_variant_id,
                    'decorated_variant_id', o.decorated_variant_id,
                    'catalog_item_id', o.catalog_item_id,
                    'subassembly_key', s.subassembly_key
                ))
                ORDER BY g.sort_order NULLS LAST, g.requirement_group_id
            )
            FROM definition.requirement_groups g
            JOIN definition.requirement_options o
              ON o.requirement_group_id = g.requirement_group_id
             AND o.is_primary
             AND o.deleted_at IS NULL
            LEFT JOIN definition.manifest_requirement_placements p
              ON p.requirement_group_id = g.requirement_group_id
            LEFT JOIN definition.manifest_subassemblies s
              ON s.manifest_subassembly_id = p.manifest_subassembly_id
            WHERE g.inventory_version_id = iv.inventory_version_id
              AND g.deleted_at IS NULL
        ), '[]'::jsonb),
        '_links', jsonb_build_object(
            'versions', '/manifest/versions'
        )
    )
    INTO v
    FROM definition.inventory_versions iv
    WHERE iv.inventory_version_id = p_inventory_version_id;

    IF v IS NULL THEN
        RAISE EXCEPTION 'Manifest version not found' USING ERRCODE='P0002';
    END IF;
    RETURN v;
END;
$$;

CREATE OR REPLACE FUNCTION definition.load_moc_manifest_payload(
    p_inventory_version_id uuid,
    p_parts jsonb,
    p_replace boolean DEFAULT false
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, definition, catalog
AS $$
DECLARE
    e jsonb;
    n record;
    v_group_id bigint;
    v_subassembly_id uuid;
BEGIN
    IF jsonb_typeof(p_parts) <> 'array' THEN
        RAISE EXCEPTION 'manifest must be a JSON array' USING ERRCODE='22023';
    END IF;

    IF p_replace THEN
        UPDATE definition.requirement_options o
        SET deleted_at = now()
        FROM definition.requirement_groups g
        WHERE g.inventory_version_id = p_inventory_version_id
          AND o.requirement_group_id = g.requirement_group_id
          AND o.deleted_at IS NULL;

        UPDATE definition.requirement_groups
        SET deleted_at = now()
        WHERE inventory_version_id = p_inventory_version_id
          AND deleted_at IS NULL;
    END IF;

    CREATE TEMP TABLE IF NOT EXISTS bt_moc_norm(
        requirement_key text PRIMARY KEY,
        part_variant_id uuid,
        decorated_variant_id uuid,
        catalog_item_id uuid,
        subassembly_key text,
        is_spare boolean NOT NULL,
        is_alternate boolean NOT NULL,
        quantity bigint NOT NULL
    ) ON COMMIT DROP;
    TRUNCATE bt_moc_norm;

    FOR e IN SELECT value FROM jsonb_array_elements(p_parts)
    LOOP
        IF COALESCE((e->>'quantity')::bigint,0) <= 0 THEN
            RAISE EXCEPTION 'Manifest quantity must be a positive integer'
                USING ERRCODE='22023';
        END IF;
        IF num_nonnulls(NULLIF(e->>'part_variant_id',''), NULLIF(e->>'catalog_item_id','')) <> 1 THEN
            RAISE EXCEPTION 'Each Manifest requirement must target exactly one part_variant_id or catalog_item_id'
                USING ERRCODE='22023';
        END IF;

        INSERT INTO bt_moc_norm(
            requirement_key, part_variant_id, decorated_variant_id,
            catalog_item_id, subassembly_key, is_spare, is_alternate, quantity
        ) VALUES (
            definition.moc_requirement_key(e),
            NULLIF(e->>'part_variant_id','')::uuid,
            NULLIF(e->>'decorated_variant_id','')::uuid,
            NULLIF(e->>'catalog_item_id','')::uuid,
            NULLIF(e->>'subassembly_key',''),
            COALESCE((e->>'is_spare')::boolean,false),
            COALESCE((e->>'is_alternate')::boolean,false),
            (e->>'quantity')::bigint
        )
        ON CONFLICT(requirement_key)
        DO UPDATE SET quantity = bt_moc_norm.quantity + EXCLUDED.quantity;
    END LOOP;

    FOR n IN SELECT * FROM bt_moc_norm ORDER BY requirement_key
    LOOP
        IF n.decorated_variant_id IS NOT NULL AND n.part_variant_id IS NULL THEN
            RAISE EXCEPTION 'decorated_variant_id requires part_variant_id'
                USING ERRCODE='22023';
        END IF;

        INSERT INTO definition.requirement_groups(
            inventory_version_id, required_quantity, fulfillment_rule,
            is_required, is_spare, is_alternate, requirement_key, deleted_at
        ) VALUES (
            p_inventory_version_id, n.quantity, 'ANY',
            true, n.is_spare, n.is_alternate, n.requirement_key, NULL
        ) RETURNING requirement_group_id INTO v_group_id;

        INSERT INTO definition.requirement_options(
            requirement_group_id, catalog_item_id, part_variant_id,
            decorated_variant_id, option_quantity, is_primary, deleted_at
        ) VALUES (
            v_group_id, n.catalog_item_id, n.part_variant_id,
            n.decorated_variant_id, 1, true, NULL
        );

        IF n.subassembly_key IS NOT NULL THEN
            SELECT manifest_subassembly_id
            INTO v_subassembly_id
            FROM definition.manifest_subassemblies
            WHERE inventory_version_id=p_inventory_version_id
              AND subassembly_key=n.subassembly_key;

            IF v_subassembly_id IS NULL THEN
                INSERT INTO definition.manifest_subassemblies(
                    inventory_version_id, parent_subassembly_id,
                    subassembly_key, display_name, position_index
                ) VALUES (
                    p_inventory_version_id, NULL,
                    n.subassembly_key, n.subassembly_key, 0
                ) RETURNING manifest_subassembly_id INTO v_subassembly_id;
            END IF;

            INSERT INTO definition.manifest_requirement_placements(
                requirement_group_id, manifest_subassembly_id,
                inventory_version_id, position_index
            ) VALUES (
                v_group_id, v_subassembly_id,
                p_inventory_version_id, 0
            );
        END IF;
    END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION api.create_moc_manifest(
    p_catalog_item_id uuid,
    p_parts jsonb,
    p_description text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, catalog, definition, identity, app
AS $$
DECLARE
    i catalog.items%ROWTYPE;
    v_def uuid;
    v_ver uuid;
BEGIN
    SELECT * INTO i
    FROM catalog.items
    WHERE catalog_item_id=p_catalog_item_id
    FOR UPDATE;

    IF NOT FOUND OR i.item_kind <> 'MOC' OR i.deleted_at IS NOT NULL THEN
        RAISE EXCEPTION 'MOC not found' USING ERRCODE='P0002';
    END IF;
    PERFORM app.require_resource_owner(i.owner_id,'MOCS');

    v_def := definition.ensure_inventory_definition(p_catalog_item_id,'MOC_MANIFEST');
    v_ver := definition.create_initial_version(v_def,p_description,identity.current_user_id());
    PERFORM definition.load_moc_manifest_payload(v_ver,p_parts,false);
    RETURN app.build_catalog_manifest_json(v_ver);
END;
$$;

CREATE OR REPLACE FUNCTION api.get_catalog_manifest(
    p_catalog_item_id uuid,
    p_version integer DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, definition, catalog, identity, app
AS $$
DECLARE
    v_def uuid;
    v_ver uuid;
    i catalog.items%ROWTYPE;
    v_user uuid := identity.current_user_id_optional();
BEGIN
    SELECT * INTO i FROM catalog.items WHERE catalog_item_id=p_catalog_item_id;
    IF NOT FOUND OR i.item_kind <> 'MOC' OR i.deleted_at IS NOT NULL THEN
        RAISE EXCEPTION 'Manifest not found' USING ERRCODE='P0002';
    END IF;
    IF i.visibility IN ('PRIVATE_DRAFT','FAMILY')
       AND (v_user IS NULL OR i.owner_id IS NULL OR NOT identity.can_view_owner(v_user,i.owner_id,'MOCS')) THEN
        RAISE EXCEPTION 'Manifest not found' USING ERRCODE='P0002';
    END IF;

    SELECT inventory_definition_id INTO v_def
    FROM definition.inventory_definitions
    WHERE catalog_item_id=p_catalog_item_id
      AND definition_kind='MOC_MANIFEST';

    IF v_def IS NULL THEN
        RAISE EXCEPTION 'Manifest not found' USING ERRCODE='P0002';
    END IF;

    SELECT inventory_version_id INTO v_ver
    FROM definition.inventory_versions
    WHERE inventory_definition_id=v_def
      AND ((p_version IS NULL AND is_default) OR semantic_version=p_version)
    ORDER BY is_default DESC
    LIMIT 1;

    IF v_ver IS NULL THEN
        RAISE EXCEPTION 'Manifest version not found' USING ERRCODE='P0002';
    END IF;
    RETURN app.build_catalog_manifest_json(v_ver);
END;
$$;

CREATE OR REPLACE FUNCTION api.replace_moc_manifest(
    p_inventory_version_id uuid,
    p_expected_edit_revision bigint,
    p_parts jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, definition, catalog, app
AS $$
DECLARE
    iv definition.inventory_versions%ROWTYPE;
    i catalog.items%ROWTYPE;
BEGIN
    SELECT * INTO iv
    FROM definition.inventory_versions
    WHERE inventory_version_id=p_inventory_version_id
    FOR UPDATE;

    IF NOT FOUND OR NOT iv.is_default OR iv.status='FINALIZED' THEN
        RAISE EXCEPTION 'Editable current Manifest required' USING ERRCODE='55000';
    END IF;

    SELECT ci.* INTO i
    FROM definition.inventory_definitions d
    JOIN catalog.items ci ON ci.catalog_item_id=d.catalog_item_id
    WHERE d.inventory_definition_id=iv.inventory_definition_id
      AND d.definition_kind='MOC_MANIFEST';

    IF i.item_kind <> 'MOC' OR i.deleted_at IS NOT NULL THEN
        RAISE EXCEPTION 'MOC not found' USING ERRCODE='P0002';
    END IF;
    PERFORM app.require_resource_owner(i.owner_id,'MOCS');

    IF iv.edit_revision <> p_expected_edit_revision THEN
        RAISE EXCEPTION 'Edit revision precondition failed' USING ERRCODE='40001';
    END IF;

    PERFORM definition.load_moc_manifest_payload(p_inventory_version_id,p_parts,true);
    PERFORM definition.bump_edit_revision(p_inventory_version_id);
    RETURN app.build_catalog_manifest_json(p_inventory_version_id);
END;
$$;

CREATE OR REPLACE FUNCTION api.edit_moc_manifest(
    p_inventory_version_id uuid,
    p_expected_edit_revision bigint,
    p_changes jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, definition, catalog, app
AS $$
DECLARE
    iv definition.inventory_versions%ROWTYPE;
    i catalog.items%ROWTYPE;
    c jsonb;
    v_key text;
    v_group bigint;
    v_qty bigint;
    v_op text;
    v_existing_op text;
    v_existing_payload jsonb;
BEGIN
    SELECT * INTO iv
    FROM definition.inventory_versions
    WHERE inventory_version_id=p_inventory_version_id
    FOR UPDATE;

    IF NOT FOUND OR NOT iv.is_default OR iv.status='FINALIZED' THEN
        RAISE EXCEPTION 'Editable current Manifest required' USING ERRCODE='55000';
    END IF;
    SELECT ci.* INTO i
    FROM definition.inventory_definitions d
    JOIN catalog.items ci ON ci.catalog_item_id=d.catalog_item_id
    WHERE d.inventory_definition_id=iv.inventory_definition_id
      AND d.definition_kind='MOC_MANIFEST';
    PERFORM app.require_resource_owner(i.owner_id,'MOCS');
    IF iv.edit_revision <> p_expected_edit_revision THEN
        RAISE EXCEPTION 'Edit revision precondition failed' USING ERRCODE='40001';
    END IF;
    IF jsonb_typeof(p_changes) <> 'array' THEN
        RAISE EXCEPTION 'changes must be a JSON array' USING ERRCODE='22023';
    END IF;

    CREATE TEMP TABLE IF NOT EXISTS bt_moc_patch_keys(k text PRIMARY KEY, op text, payload jsonb) ON COMMIT DROP;
    TRUNCATE bt_moc_patch_keys;
    FOR c IN SELECT value FROM jsonb_array_elements(p_changes)
    LOOP
        v_op := lower(c->>'operation');
        IF v_op NOT IN ('add','set_quantity','remove') THEN
            RAISE EXCEPTION 'Unsupported Manifest PATCH operation %',v_op USING ERRCODE='22023';
        END IF;
        v_key := COALESCE(NULLIF(c->>'requirement_key',''),definition.moc_requirement_key(c));
        SELECT op,payload INTO v_existing_op,v_existing_payload
        FROM bt_moc_patch_keys WHERE k=v_key;
        IF NOT FOUND THEN
            INSERT INTO bt_moc_patch_keys VALUES(v_key,v_op,c);
        ELSIF v_existing_op<>v_op THEN
            RAISE EXCEPTION 'Conflicting operations for one Manifest requirement' USING ERRCODE='23505';
        ELSIF v_op='add' THEN
            UPDATE bt_moc_patch_keys
            SET payload=jsonb_set(payload,'{quantity}',to_jsonb((payload->>'quantity')::bigint+(c->>'quantity')::bigint))
            WHERE k=v_key;
        ELSIF v_op='remove' THEN
            NULL; -- duplicate removes collapse
        ELSIF (v_existing_payload->>'quantity')::bigint=(c->>'quantity')::bigint THEN
            NULL; -- identical set_quantity operations collapse
        ELSE
            RAISE EXCEPTION 'Conflicting set_quantity operations for one Manifest requirement' USING ERRCODE='23505';
        END IF;
    END LOOP;

    FOR c IN SELECT payload FROM bt_moc_patch_keys ORDER BY k
    LOOP
        v_op := lower(c->>'operation');
        v_key := COALESCE(NULLIF(c->>'requirement_key',''),definition.moc_requirement_key(c));
        SELECT requirement_group_id,required_quantity
        INTO v_group,v_qty
        FROM definition.requirement_groups
        WHERE inventory_version_id=p_inventory_version_id
          AND requirement_key=v_key
          AND deleted_at IS NULL
        FOR UPDATE;

        IF v_op='remove' THEN
            IF v_group IS NULL THEN CONTINUE; END IF;
            UPDATE definition.requirement_options SET deleted_at=now()
            WHERE requirement_group_id=v_group AND deleted_at IS NULL;
            UPDATE definition.requirement_groups SET deleted_at=now()
            WHERE requirement_group_id=v_group;
        ELSIF v_op='set_quantity' THEN
            IF v_group IS NULL THEN RAISE EXCEPTION 'Requirement does not exist' USING ERRCODE='55000'; END IF;
            IF COALESCE((c->>'quantity')::bigint,0)<=0 THEN RAISE EXCEPTION 'quantity must be positive' USING ERRCODE='22023'; END IF;
            UPDATE definition.requirement_groups SET required_quantity=(c->>'quantity')::bigint WHERE requirement_group_id=v_group;
        ELSE
            IF COALESCE((c->>'quantity')::bigint,0)<=0 THEN RAISE EXCEPTION 'quantity must be positive' USING ERRCODE='22023'; END IF;
            IF v_group IS NOT NULL THEN
                UPDATE definition.requirement_groups SET required_quantity=required_quantity+(c->>'quantity')::bigint WHERE requirement_group_id=v_group;
            ELSE
                PERFORM definition.load_moc_manifest_payload(p_inventory_version_id,jsonb_build_array(c-'operation'),false);
            END IF;
        END IF;
    END LOOP;

    PERFORM definition.bump_edit_revision(p_inventory_version_id);
    RETURN app.build_catalog_manifest_json(p_inventory_version_id);
END;
$$;

CREATE OR REPLACE FUNCTION api.create_moc_manifest_version(
    p_inventory_version_id uuid,
    p_expected_edit_revision bigint,
    p_description text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, definition, catalog, app
AS $$
DECLARE
    iv definition.inventory_versions%ROWTYPE;
    i catalog.items%ROWTYPE;
    v_new uuid;
BEGIN
    SELECT * INTO iv FROM definition.inventory_versions WHERE inventory_version_id=p_inventory_version_id;
    SELECT ci.* INTO i
    FROM definition.inventory_definitions d
    JOIN catalog.items ci ON ci.catalog_item_id=d.catalog_item_id
    WHERE d.inventory_definition_id=iv.inventory_definition_id
      AND d.definition_kind='MOC_MANIFEST';
    IF i.item_kind <> 'MOC' THEN
        RAISE EXCEPTION 'MOC Manifest required' USING ERRCODE='22023';
    END IF;
    PERFORM app.require_resource_owner(i.owner_id,'MOCS');
    v_new := definition.create_semantic_version(p_inventory_version_id,p_expected_edit_revision,p_description);
    RETURN app.build_catalog_manifest_json(v_new);
END;
$$;

CREATE OR REPLACE FUNCTION api.list_moc_manifest_versions(p_catalog_item_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog,definition,catalog,identity
AS $$
DECLARE
    i catalog.items%ROWTYPE;
    v_user uuid:=identity.current_user_id_optional();
    v_result jsonb;
BEGIN
    SELECT * INTO i FROM catalog.items WHERE catalog_item_id=p_catalog_item_id;
    IF NOT FOUND OR i.item_kind<>'MOC' OR i.deleted_at IS NOT NULL THEN
        RAISE EXCEPTION 'MOC not found' USING ERRCODE='P0002';
    END IF;
    IF i.visibility IN ('PRIVATE_DRAFT','FAMILY')
       AND (v_user IS NULL OR i.owner_id IS NULL OR NOT identity.can_view_owner(v_user,i.owner_id,'MOCS')) THEN
        RAISE EXCEPTION 'MOC not found' USING ERRCODE='P0002';
    END IF;

    SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'version',iv.semantic_version,
        'is_default',iv.is_default,
        'description',iv.description,
        'final_edit_revision',CASE WHEN NOT iv.is_default THEN iv.edit_revision ELSE NULL END,
        'edit_revision',CASE WHEN iv.is_default THEN iv.edit_revision ELSE NULL END
    ) ORDER BY iv.semantic_version),'[]'::jsonb)
    INTO v_result
    FROM definition.inventory_definitions d
    JOIN definition.inventory_versions iv USING(inventory_definition_id)
    WHERE d.catalog_item_id=p_catalog_item_id AND d.definition_kind='MOC_MANIFEST';
    RETURN v_result;
END;
$$;

CREATE OR REPLACE FUNCTION api.fork_moc(
    p_source_item_id uuid,
    p_forked_name text DEFAULT NULL,
    p_source_inventory_version_id uuid DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog,catalog,moc,definition,identity,app
AS $$
DECLARE
    s catalog.items%ROWTYPE;
    sm moc.mocs%ROWTYPE;
    v_user uuid:=app.require_active_user();
    v_owner uuid:=identity.ensure_owner_for_user(v_user);
    v_new_item uuid:=app.uuid_v7();
    v_new_moc uuid;
    v_source_version uuid;
    v_source_def uuid;
    v_new_def uuid;
    v_new_version uuid;
    v_name text;
BEGIN
    SELECT * INTO s
    FROM catalog.items
    WHERE catalog_item_id=p_source_item_id AND item_kind='MOC' AND deleted_at IS NULL;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'MOC not found' USING ERRCODE='P0002';
    END IF;
    IF s.visibility IN ('PRIVATE_DRAFT','FAMILY')
       AND NOT identity.can_view_owner(v_user,s.owner_id,'MOCS') THEN
        RAISE EXCEPTION 'MOC not found' USING ERRCODE='P0002';
    END IF;

    SELECT * INTO sm
    FROM moc.mocs
    WHERE catalog_item_id=p_source_item_id AND archived_at IS NULL;
    IF NOT FOUND OR NOT sm.forks_allowed THEN
        RAISE EXCEPTION 'MOC cannot be forked' USING ERRCODE='42501';
    END IF;

    v_name:=COALESCE(NULLIF(p_forked_name,''),s.canonical_name||' (Fork)');
    INSERT INTO catalog.items(catalog_item_id,item_kind,canonical_name,status,item_num,owner_id,creator_user_id,visibility)
    VALUES(v_new_item,'MOC',v_name,'ACTIVE',app.generate_item_num('MOC',v_new_item),v_owner,v_user,'PRIVATE_DRAFT');
    INSERT INTO catalog.mocs(catalog_item_id) VALUES(v_new_item);
    INSERT INTO moc.mocs(catalog_item_id,owner_id,title,visibility,created_by_user_id)
    VALUES(v_new_item,v_owner,v_name,'PRIVATE',v_user)
    RETURNING moc_id INTO v_new_moc;

    SELECT inventory_definition_id INTO v_source_def
    FROM definition.inventory_definitions
    WHERE catalog_item_id=p_source_item_id AND definition_kind='MOC_MANIFEST';

    IF p_source_inventory_version_id IS NULL THEN
        SELECT inventory_version_id INTO v_source_version
        FROM definition.inventory_versions
        WHERE inventory_definition_id=v_source_def AND is_default;
    ELSE
        SELECT inventory_version_id INTO v_source_version
        FROM definition.inventory_versions
        WHERE inventory_version_id=p_source_inventory_version_id
          AND inventory_definition_id=v_source_def;
        IF v_source_version IS NULL THEN
            RAISE EXCEPTION 'Requested source Manifest version does not belong to source MOC' USING ERRCODE='22023';
        END IF;
    END IF;

    IF v_source_version IS NOT NULL THEN
        v_new_def:=definition.ensure_inventory_definition(v_new_item,'MOC_MANIFEST');
        v_new_version:=definition.create_initial_version(v_new_def,'Forked manifest',v_user);
        PERFORM definition.clone_version_graph(v_source_version,v_new_version);
    END IF;

    -- Preserve the existing MOC revision relationship where one exists. The
    -- fork remains independent after creation even if the source is deleted.
    INSERT INTO moc.forks(source_moc_id,source_revision_id,forked_moc_id,forked_by_user_id)
    SELECT sm.moc_id,r.moc_revision_id,v_new_moc,v_user
    FROM moc.revisions r
    WHERE r.moc_id=sm.moc_id
      AND (v_source_version IS NULL OR r.inventory_version_id=v_source_version)
    ORDER BY r.revision_number DESC
    LIMIT 1;

    RETURN app.build_catalog_item_json(v_new_item);
END;
$$;
