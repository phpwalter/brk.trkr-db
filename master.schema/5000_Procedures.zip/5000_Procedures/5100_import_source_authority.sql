/*
===============================================================================
 File:           5000_Procedures/5100_import_source_authority.sql
 Project:        BrickTrackr
 PostgreSQL:     16+
 Purpose:        Source-controlled Catalog Item mutation and deterministic
                 source-value -> admin-override -> effective-value resolution.
===============================================================================
*/
\set ON_ERROR_STOP on

CREATE OR REPLACE FUNCTION catalog.refresh_effective_catalog_field(
    p_catalog_item_id uuid,
    p_field_name text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,catalog
AS $$
DECLARE
    v jsonb;
BEGIN
    SELECT override_value INTO v
    FROM catalog.admin_overrides
    WHERE catalog_item_id=p_catalog_item_id
      AND field_name=p_field_name
      AND cleared_at IS NULL
    ORDER BY created_at DESC
    LIMIT 1;

    IF v IS NULL THEN
        SELECT source_value INTO v
        FROM catalog.source_values
        WHERE catalog_item_id=p_catalog_item_id
          AND field_name=p_field_name
        ORDER BY last_seen_at DESC,source_id
        LIMIT 1;
    END IF;

    IF p_field_name='canonical_name' THEN
        UPDATE catalog.items SET canonical_name=trim(both '"' from v::text),updated_at=now()
        WHERE catalog_item_id=p_catalog_item_id AND v IS NOT NULL AND v<>'null'::jsonb;
    ELSIF p_field_name='year_released' THEN
        UPDATE catalog.items SET year_released=CASE WHEN v IS NULL OR v='null'::jsonb THEN NULL ELSE (v::text)::smallint END,updated_at=now()
        WHERE catalog_item_id=p_catalog_item_id;
    ELSIF p_field_name='theme_id' THEN
        UPDATE catalog.items SET theme_id=CASE WHEN v IS NULL OR v='null'::jsonb THEN NULL ELSE (v::text)::integer END,updated_at=now()
        WHERE catalog_item_id=p_catalog_item_id;
    ELSIF p_field_name='visibility' THEN
        UPDATE catalog.items SET visibility=CASE trim(both '"' from v::text)
            WHEN 'PRIVATE_DRAFT' THEN 'PRIVATE_DRAFT'::catalog.catalog_visibility
            WHEN 'FAMILY' THEN 'FAMILY'::catalog.catalog_visibility
            WHEN 'UNLISTED' THEN 'UNLISTED'::catalog.catalog_visibility
            ELSE 'PUBLIC'::catalog.catalog_visibility END,updated_at=now()
        WHERE catalog_item_id=p_catalog_item_id AND v IS NOT NULL AND v<>'null'::jsonb;
    ELSE
        RAISE EXCEPTION 'Unsupported effective Catalog Item field %',p_field_name USING ERRCODE='22023';
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION import.apply_source_field(
    p_catalog_item_id uuid,
    p_source_id smallint,
    p_field_name text,
    p_value jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,catalog,app
AS $$
DECLARE
    v_old jsonb;
    v_run uuid:=NULLIF(current_setting('app.source_run_id',true),'')::uuid;
BEGIN
    PERFORM app.require_actor_class(ARRAY['IMPORTER','SYSTEM']);
    IF p_field_name NOT IN ('canonical_name','year_released','theme_id','visibility') THEN
        RAISE EXCEPTION 'Unsupported source-controlled field %',p_field_name USING ERRCODE='22023';
    END IF;

    SELECT source_value INTO v_old
    FROM catalog.source_values
    WHERE catalog_item_id=p_catalog_item_id AND source_id=p_source_id AND field_name=p_field_name
    FOR UPDATE;

    IF FOUND AND v_old IS DISTINCT FROM p_value THEN
        INSERT INTO catalog.source_value_history(
            catalog_item_id,source_id,field_name,old_value,new_value,source_run_id
        ) VALUES(p_catalog_item_id,p_source_id,p_field_name,v_old,p_value,v_run);
    END IF;

    INSERT INTO catalog.source_values(
        catalog_item_id,source_id,field_name,source_value,last_source_run_id
    ) VALUES(p_catalog_item_id,p_source_id,p_field_name,p_value,v_run)
    ON CONFLICT(catalog_item_id,source_id,field_name)
    DO UPDATE SET source_value=EXCLUDED.source_value,last_seen_at=now(),last_source_run_id=EXCLUDED.last_source_run_id;

    PERFORM catalog.refresh_effective_catalog_field(p_catalog_item_id,p_field_name);
END;
$$;

CREATE OR REPLACE FUNCTION import.upsert_catalog_item(
    p_kind catalog.item_kind,
    p_name text,
    p_item_num text,
    p_source_id smallint,
    p_namespace text,
    p_external_id text,
    p_external_version integer DEFAULT NULL,
    p_year_released integer DEFAULT NULL,
    p_theme_id integer DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,catalog,import,app
AS $$
DECLARE
    v_id uuid;
BEGIN
    PERFORM app.require_actor_class(ARRAY['IMPORTER','SYSTEM']);
    IF p_kind NOT IN ('SET','MINIFIGURE') THEN
        RAISE EXCEPTION 'Only source-controlled SET/MINIFIGURE items may use import.upsert_catalog_item'
            USING ERRCODE='42501';
    END IF;

    SELECT catalog_item_id INTO v_id
    FROM catalog.external_identifiers
    WHERE source_id=p_source_id
      AND entity_namespace=p_namespace
      AND external_id=p_external_id
      AND external_version IS NOT DISTINCT FROM p_external_version
    LIMIT 1;

    IF v_id IS NULL THEN
        v_id:=app.uuid_v7();
        INSERT INTO catalog.items(
            catalog_item_id,item_kind,canonical_name,status,item_num,visibility,year_released,theme_id
        ) VALUES(
            v_id,p_kind,p_name,'ACTIVE',p_item_num,'PUBLIC',p_year_released,p_theme_id
        );
        IF p_kind='SET' THEN
            INSERT INTO catalog.sets(catalog_item_id,release_year,theme_id)
            VALUES(v_id,p_year_released,p_theme_id);
        ELSE
            INSERT INTO catalog.minifigures(catalog_item_id,theme_id)
            VALUES(v_id,p_theme_id);
        END IF;
        INSERT INTO catalog.external_identifiers(
            source_id,entity_namespace,external_id,external_version,catalog_item_id
        ) VALUES(p_source_id,p_namespace,p_external_id,p_external_version,v_id);
    ELSE
        UPDATE catalog.external_identifiers
        SET source_present=true,last_seen_at=now()
        WHERE source_id=p_source_id
          AND entity_namespace=p_namespace
          AND external_id=p_external_id
          AND external_version IS NOT DISTINCT FROM p_external_version
          AND catalog_item_id=v_id;
        UPDATE catalog.items SET item_num=COALESCE(item_num,p_item_num),status='ACTIVE',updated_at=now()
        WHERE catalog_item_id=v_id;
    END IF;

    PERFORM import.apply_source_field(v_id,p_source_id,'canonical_name',to_jsonb(p_name));
    PERFORM import.apply_source_field(v_id,p_source_id,'year_released',COALESCE(to_jsonb(p_year_released),'null'::jsonb));
    PERFORM import.apply_source_field(v_id,p_source_id,'theme_id',COALESCE(to_jsonb(p_theme_id),'null'::jsonb));
    PERFORM import.apply_source_field(v_id,p_source_id,'visibility','"PUBLIC"'::jsonb);
    RETURN v_id;
END;
$$;

CREATE OR REPLACE FUNCTION import.mark_source_mapping_missing(
    p_source_id smallint,
    p_namespace text,
    p_external_id text,
    p_external_version integer DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,catalog,app
AS $$
BEGIN
    PERFORM app.require_actor_class(ARRAY['IMPORTER','SYSTEM']);
    UPDATE catalog.external_identifiers
    SET source_present=false,last_seen_at=now()
    WHERE source_id=p_source_id
      AND entity_namespace=p_namespace
      AND external_id=p_external_id
      AND external_version IS NOT DISTINCT FROM p_external_version;
    -- Deliberately no visibility/deleted_at/catalog removal mutation.
END;
$$;

CREATE OR REPLACE FUNCTION import.sync_set_manifest(
    p_catalog_item_id uuid,
    p_source_id smallint,
    p_external_id text,
    p_external_version integer,
    p_parts jsonb,
    p_description text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,definition,catalog,import,app
AS $$
DECLARE
    d uuid;
    v uuid;
    v_prev uuid;
    v_hash app.sha256_digest;
    v_num integer;
    v_run uuid:=NULLIF(current_setting('app.source_run_id',true),'')::uuid;
BEGIN
    PERFORM app.require_actor_class(ARRAY['IMPORTER','SYSTEM']);
    IF NOT EXISTS(SELECT 1 FROM catalog.items WHERE catalog_item_id=p_catalog_item_id AND item_kind='SET') THEN
        RAISE EXCEPTION 'SET Catalog Item required' USING ERRCODE='22023';
    END IF;
    d:=definition.ensure_inventory_definition(p_catalog_item_id,'SET_MANIFEST');
    PERFORM 1 FROM definition.inventory_definitions WHERE inventory_definition_id=d FOR UPDATE;
    SELECT latest_source_version_id INTO v_prev FROM definition.definition_authority WHERE inventory_definition_id=d;
    v_num:=definition.next_semantic_version(d);
    INSERT INTO definition.inventory_versions(
        inventory_definition_id,semantic_version,status,source_id,source_external_id,
        source_external_version,source_run_id,edit_revision,is_default,description
    ) VALUES(d,v_num,'DRAFT',p_source_id,p_external_id,p_external_version,v_run,1,false,p_description)
    RETURNING inventory_version_id INTO v;
    PERFORM definition.load_moc_manifest_payload(v,p_parts,false);
    v_hash:=definition.compute_inventory_version_hash(v);
    IF v_prev IS NOT NULL AND (SELECT semantic_hash FROM definition.inventory_versions WHERE inventory_version_id=v_prev)=v_hash THEN
        UPDATE definition.inventory_versions SET last_seen_at=now(),source_run_id=v_run WHERE inventory_version_id=v_prev;
        DELETE FROM definition.inventory_versions WHERE inventory_version_id=v;
        RETURN v_prev;
    END IF;
    UPDATE definition.inventory_versions SET status='FINALIZED',semantic_hash=v_hash,finalized_at=now() WHERE inventory_version_id=v;
    INSERT INTO definition.definition_authority(inventory_definition_id,latest_source_version_id)
    VALUES(d,v)
    ON CONFLICT(inventory_definition_id) DO UPDATE SET latest_source_version_id=EXCLUDED.latest_source_version_id,updated_at=now();
    RETURN v;
END;
$$;

CREATE OR REPLACE FUNCTION import.sync_minifig_composition(
    p_catalog_item_id uuid,
    p_source_id smallint,
    p_external_id text,
    p_structural jsonb,
    p_accessories jsonb DEFAULT '[]'::jsonb,
    p_description text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,definition,catalog,import,app
AS $$
DECLARE
    d uuid;
    v uuid;
    v_prev uuid;
    v_hash app.sha256_digest;
    v_num integer;
    v_run uuid:=NULLIF(current_setting('app.source_run_id',true),'')::uuid;
BEGIN
    PERFORM app.require_actor_class(ARRAY['IMPORTER','SYSTEM']);
    IF NOT EXISTS(SELECT 1 FROM catalog.items WHERE catalog_item_id=p_catalog_item_id AND item_kind='MINIFIGURE') THEN
        RAISE EXCEPTION 'MINIFIGURE Catalog Item required' USING ERRCODE='22023';
    END IF;
    d:=definition.ensure_inventory_definition(p_catalog_item_id,'MINIFIG_COMPOSITION');
    PERFORM 1 FROM definition.inventory_definitions WHERE inventory_definition_id=d FOR UPDATE;
    SELECT latest_source_version_id INTO v_prev FROM definition.definition_authority WHERE inventory_definition_id=d;
    v_num:=definition.next_semantic_version(d);
    INSERT INTO definition.inventory_versions(
        inventory_definition_id,semantic_version,status,source_id,source_external_id,
        source_run_id,edit_revision,is_default,description
    ) VALUES(d,v_num,'DRAFT',p_source_id,p_external_id,v_run,1,false,p_description)
    RETURNING inventory_version_id INTO v;
    PERFORM definition.load_minifig_composition_payload(v,p_structural,p_accessories,false);
    v_hash:=definition.compute_inventory_version_hash(v);
    IF v_prev IS NOT NULL AND (SELECT semantic_hash FROM definition.inventory_versions WHERE inventory_version_id=v_prev)=v_hash THEN
        UPDATE definition.inventory_versions SET last_seen_at=now(),source_run_id=v_run WHERE inventory_version_id=v_prev;
        DELETE FROM definition.inventory_versions WHERE inventory_version_id=v;
        RETURN v_prev;
    END IF;
    UPDATE definition.inventory_versions SET status='FINALIZED',semantic_hash=v_hash,finalized_at=now() WHERE inventory_version_id=v;
    INSERT INTO definition.definition_authority(inventory_definition_id,latest_source_version_id)
    VALUES(d,v)
    ON CONFLICT(inventory_definition_id) DO UPDATE SET latest_source_version_id=EXCLUDED.latest_source_version_id,updated_at=now();
    RETURN v;
END;
$$;
