/* BrickTrackr 5110 - administrator overrides, remaps, definition corrections */
\set ON_ERROR_STOP on

CREATE OR REPLACE FUNCTION admin.set_catalog_item_override(
    p_catalog_item_id uuid,
    p_field_name text,
    p_value jsonb,
    p_reason text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,catalog,admin,app
AS $$
DECLARE
    v_user uuid:=app.require_active_user();
    v_id uuid;
BEGIN
    PERFORM app.require_actor_class(ARRAY['ADMIN']);
    IF p_field_name NOT IN ('canonical_name','visibility','year_released','theme_id') THEN
        RAISE EXCEPTION 'Field is not overrideable' USING ERRCODE='22023';
    END IF;
    IF btrim(coalesce(p_reason,''))='' THEN
        RAISE EXCEPTION 'Override reason is required' USING ERRCODE='22023';
    END IF;

    -- Strong type/domain validation before JSONB becomes authoritative.
    IF p_field_name='canonical_name' AND jsonb_typeof(p_value)<>'string' THEN
        RAISE EXCEPTION 'canonical_name override must be a JSON string' USING ERRCODE='22023';
    ELSIF p_field_name='visibility' AND trim(both '"' from p_value::text) NOT IN ('PRIVATE_DRAFT','FAMILY','UNLISTED','PUBLIC') THEN
        RAISE EXCEPTION 'Invalid visibility override' USING ERRCODE='22023';
    ELSIF p_field_name='year_released' AND p_value<>'null'::jsonb AND (p_value::text)::integer NOT BETWEEN 1930 AND 2200 THEN
        RAISE EXCEPTION 'Invalid year_released override' USING ERRCODE='22023';
    ELSIF p_field_name='theme_id' AND p_value<>'null'::jsonb
          AND NOT EXISTS(SELECT 1 FROM reference.themes WHERE theme_id=(p_value::text)::integer) THEN
        RAISE EXCEPTION 'Invalid theme_id override' USING ERRCODE='22023';
    END IF;

    UPDATE catalog.admin_overrides
    SET cleared_at=now(),cleared_by_user_id=v_user
    WHERE catalog_item_id=p_catalog_item_id
      AND field_name=p_field_name
      AND cleared_at IS NULL;

    INSERT INTO catalog.admin_overrides(
        catalog_item_id,field_name,override_value,reason,created_by_user_id
    ) VALUES(
        p_catalog_item_id,p_field_name,p_value,p_reason,v_user
    ) RETURNING admin_override_id INTO v_id;
    PERFORM catalog.refresh_effective_catalog_field(p_catalog_item_id,p_field_name);
    RETURN v_id;
END;
$$;

CREATE OR REPLACE FUNCTION admin.clear_catalog_item_override(
    p_catalog_item_id uuid,
    p_field_name text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,catalog,app
AS $$
DECLARE v_user uuid:=app.require_active_user();
BEGIN
    PERFORM app.require_actor_class(ARRAY['ADMIN']);
    UPDATE catalog.admin_overrides
    SET cleared_at=now(),cleared_by_user_id=v_user
    WHERE catalog_item_id=p_catalog_item_id
      AND field_name=p_field_name
      AND cleared_at IS NULL;
    PERFORM catalog.refresh_effective_catalog_field(p_catalog_item_id,p_field_name);
END;
$$;

CREATE OR REPLACE FUNCTION admin.remap_external_identifier(
    p_external_identifier_id uuid,
    p_new_catalog_item_id uuid,
    p_reason text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,catalog,app
AS $$
DECLARE
    v_old_catalog_item_id uuid;
    v_actor uuid:=app.require_active_user();
BEGIN
    PERFORM app.require_actor_class(ARRAY['ADMIN']);
    IF btrim(coalesce(p_reason,''))='' THEN
        RAISE EXCEPTION 'Remap reason is required' USING ERRCODE='22023';
    END IF;
    IF NOT EXISTS(SELECT 1 FROM catalog.items WHERE catalog_item_id=p_new_catalog_item_id) THEN
        RAISE EXCEPTION 'Target Catalog Item not found' USING ERRCODE='P0002';
    END IF;
    SELECT catalog_item_id INTO v_old_catalog_item_id
    FROM catalog.external_identifiers
    WHERE external_identifier_id=p_external_identifier_id
    FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'External identifier not found' USING ERRCODE='P0002';
    END IF;
    UPDATE catalog.external_identifiers
    SET catalog_item_id=p_new_catalog_item_id,last_seen_at=now()
    WHERE external_identifier_id=p_external_identifier_id;

    INSERT INTO audit.events(
        event_type,actor_user_id,entity_schema,entity_table,entity_id,metadata
    ) VALUES(
        'SOURCE_MAPPING_REMAP',v_actor,'catalog','external_identifiers',p_external_identifier_id::text,
        jsonb_build_object('old_catalog_item_id',v_old_catalog_item_id,'new_catalog_item_id',p_new_catalog_item_id,'reason',p_reason)
    );
END;
$$;

CREATE OR REPLACE FUNCTION admin.activate_definition_correction(
    p_inventory_definition_id uuid,
    p_admin_version_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,definition,app
AS $$
BEGIN
    PERFORM app.require_actor_class(ARRAY['ADMIN']);
    IF NOT EXISTS(
        SELECT 1 FROM definition.inventory_versions
        WHERE inventory_version_id=p_admin_version_id
          AND inventory_definition_id=p_inventory_definition_id
          AND is_admin_correction
          AND status='FINALIZED'
    ) THEN
        RAISE EXCEPTION 'Valid admin correction version required' USING ERRCODE='22023';
    END IF;
    INSERT INTO definition.definition_authority(inventory_definition_id,active_admin_version_id)
    VALUES(p_inventory_definition_id,p_admin_version_id)
    ON CONFLICT(inventory_definition_id)
    DO UPDATE SET active_admin_version_id=EXCLUDED.active_admin_version_id,updated_at=now();
END;
$$;

CREATE OR REPLACE FUNCTION admin.clear_definition_correction(p_inventory_definition_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,definition,app
AS $$
BEGIN
    PERFORM app.require_actor_class(ARRAY['ADMIN']);
    UPDATE definition.definition_authority
    SET active_admin_version_id=NULL,updated_at=now()
    WHERE inventory_definition_id=p_inventory_definition_id;
END;
$$;

CREATE OR REPLACE FUNCTION admin.create_definition_correction(
    p_inventory_definition_id uuid,
    p_description text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,definition,catalog,identity,app
AS $$
DECLARE
    v_user uuid:=app.require_active_user();
    v_source uuid;
    v_new uuid;
    v_num integer;
    v_item_kind catalog.item_kind;
    v_constraint text;
    v_attempt integer:=0;
BEGIN
    PERFORM app.require_actor_class(ARRAY['ADMIN']);
    SELECT ci.item_kind INTO v_item_kind
    FROM definition.inventory_definitions d
    JOIN catalog.items ci USING(catalog_item_id)
    WHERE d.inventory_definition_id=p_inventory_definition_id;
    IF v_item_kind NOT IN ('SET','MINIFIGURE') THEN
        RAISE EXCEPTION 'Administrator definition corrections are reserved for source-controlled Catalog Items'
            USING ERRCODE='42501';
    END IF;

    PERFORM 1 FROM definition.inventory_definitions
    WHERE inventory_definition_id=p_inventory_definition_id
    FOR UPDATE;

    v_source:=definition.effective_inventory_version(p_inventory_definition_id);
    IF v_source IS NULL THEN
        RAISE EXCEPTION 'No effective source definition exists to correct' USING ERRCODE='55000';
    END IF;

    LOOP
        v_num:=definition.next_semantic_version(p_inventory_definition_id);
        BEGIN
            INSERT INTO definition.inventory_versions(
                inventory_definition_id,semantic_version,status,is_admin_correction,
                created_by_user_id,edit_revision,is_default,description
            ) VALUES(
                p_inventory_definition_id,v_num,'DRAFT',true,v_user,1,false,p_description
            ) RETURNING inventory_version_id INTO v_new;
            EXIT;
        EXCEPTION WHEN unique_violation THEN
            GET STACKED DIAGNOSTICS v_constraint = CONSTRAINT_NAME;
            IF v_constraint<>'uq_inventory_versions_number' OR v_attempt>=1 THEN
                RAISE;
            END IF;
            v_attempt:=v_attempt+1;
        END;
    END LOOP;

    PERFORM definition.clone_version_graph(v_source,v_new);
    RETURN v_new;
END;
$$;

CREATE OR REPLACE FUNCTION admin.replace_set_manifest_correction(
    p_inventory_version_id uuid,
    p_parts jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,definition,app
AS $$
BEGIN
    PERFORM app.require_actor_class(ARRAY['ADMIN']);
    IF NOT EXISTS(
        SELECT 1
        FROM definition.inventory_versions iv
        JOIN definition.inventory_definitions d USING(inventory_definition_id)
        JOIN catalog.items ci USING(catalog_item_id)
        WHERE iv.inventory_version_id=p_inventory_version_id
          AND iv.is_admin_correction AND iv.status='DRAFT'
          AND d.definition_kind='SET_MANIFEST'
          AND ci.item_kind='SET'
    ) THEN RAISE EXCEPTION 'Editable SET manifest administrator correction required' USING ERRCODE='55000'; END IF;
    PERFORM definition.load_moc_manifest_payload(p_inventory_version_id,p_parts,true);
    PERFORM definition.bump_edit_revision(p_inventory_version_id);
END;
$$;

CREATE OR REPLACE FUNCTION admin.replace_minifig_composition_correction(
    p_inventory_version_id uuid,
    p_structural jsonb,
    p_accessories jsonb DEFAULT '[]'::jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,definition,app
AS $$
BEGIN
    PERFORM app.require_actor_class(ARRAY['ADMIN']);
    IF NOT EXISTS(
        SELECT 1
        FROM definition.inventory_versions iv
        JOIN definition.inventory_definitions d USING(inventory_definition_id)
        JOIN catalog.items ci USING(catalog_item_id)
        WHERE iv.inventory_version_id=p_inventory_version_id
          AND iv.is_admin_correction AND iv.status='DRAFT'
          AND d.definition_kind='MINIFIG_COMPOSITION'
          AND ci.item_kind='MINIFIGURE'
    ) THEN RAISE EXCEPTION 'Editable MINIFIG composition administrator correction required' USING ERRCODE='55000'; END IF;
    PERFORM definition.load_minifig_composition_payload(p_inventory_version_id,p_structural,p_accessories,true);
    PERFORM definition.bump_edit_revision(p_inventory_version_id);
END;
$$;

CREATE OR REPLACE FUNCTION admin.finalize_definition_correction(p_inventory_version_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=pg_catalog,definition,app
AS $$
DECLARE
    v_definition uuid;
BEGIN
    PERFORM app.require_actor_class(ARRAY['ADMIN']);
    SELECT inventory_definition_id INTO v_definition
    FROM definition.inventory_versions
    WHERE inventory_version_id=p_inventory_version_id
      AND is_admin_correction
      AND status='DRAFT'
    FOR UPDATE;
    IF v_definition IS NULL THEN
        RAISE EXCEPTION 'Draft admin correction version required' USING ERRCODE='55000';
    END IF;
    UPDATE definition.inventory_versions
    SET status='FINALIZED',
        semantic_hash=definition.compute_inventory_version_hash(p_inventory_version_id),
        finalized_at=now()
    WHERE inventory_version_id=p_inventory_version_id;
    PERFORM admin.activate_definition_correction(v_definition,p_inventory_version_id);
END;
$$;
