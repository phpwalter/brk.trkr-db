/*
===============================================================================
 File:           5000_Procedures/5070_minifig_composition_api.sql
 Project:        BrickTrackr
 PostgreSQL:     16+
 Purpose:        Official/custom Minifig Composition lifecycle API.
 Depends On:     5010-5050 lifecycle modules
===============================================================================
*/
\set ON_ERROR_STOP on

CREATE OR REPLACE FUNCTION app.build_minifig_composition_json(p_inventory_version_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, definition, reference, app
AS $$
DECLARE
    v jsonb;
BEGIN
    SELECT jsonb_build_object(
        'version',iv.semantic_version,
        'edit_revision',CASE WHEN iv.is_default THEN iv.edit_revision ELSE NULL END,
        'is_default',iv.is_default,
        'description',iv.description,
        'structural_components',COALESCE((
            SELECT jsonb_agg(jsonb_strip_nulls(jsonb_build_object(
                'semantic_role',c.semantic_role,
                'side',lower(c.side),
                'position',c.position_index,
                'part_variant_id',c.part_variant_id,
                'decorated_variant_id',c.decorated_variant_id,
                'quantity',c.quantity
            )) ORDER BY c.semantic_role,c.side,c.position_index,c.part_variant_id)
            FROM definition.minifig_compositions mc
            JOIN definition.minifig_structural_components c USING(minifig_composition_id)
            WHERE mc.inventory_version_id=iv.inventory_version_id
              AND c.deleted_at IS NULL
        ),'[]'::jsonb),
        'accessories',COALESCE((
            SELECT jsonb_agg(jsonb_strip_nulls(jsonb_build_object(
                'role',a.accessory_role,
                'position',a.position_index,
                'part_variant_id',a.part_variant_id,
                'decorated_variant_id',a.decorated_variant_id,
                'quantity',a.quantity
            )) ORDER BY a.accessory_role,a.position_index,a.part_variant_id)
            FROM definition.minifig_compositions mc
            JOIN definition.minifig_accessories a USING(minifig_composition_id)
            WHERE mc.inventory_version_id=iv.inventory_version_id
              AND a.deleted_at IS NULL
        ),'[]'::jsonb)
    ) INTO v
    FROM definition.inventory_versions iv
    WHERE iv.inventory_version_id=p_inventory_version_id;

    IF v IS NULL THEN
        RAISE EXCEPTION 'Composition not found' USING ERRCODE='P0002';
    END IF;
    RETURN v;
END;
$$;

CREATE OR REPLACE FUNCTION definition.validate_minifig_role(
    p_role text,
    p_accessory boolean
)
RETURNS void
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, reference
AS $$
BEGIN
    IF btrim(COALESCE(p_role,''))='' THEN
        RAISE EXCEPTION 'Minifig role is required' USING ERRCODE='22023';
    END IF;
    IF NOT EXISTS(
        SELECT 1 FROM reference.minifig_roles
        WHERE role_code=upper(p_role)
          AND CASE WHEN p_accessory THEN is_accessory ELSE is_structural END
    ) THEN
        RAISE EXCEPTION 'Unsupported Minifig role: %',p_role USING ERRCODE='22023';
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION definition.load_minifig_composition_payload(
    p_inventory_version_id uuid,
    p_structural jsonb,
    p_accessories jsonb,
    p_replace boolean DEFAULT false
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, definition, reference
AS $$
DECLARE
    v_comp uuid;
    e jsonb;
BEGIN
    IF jsonb_typeof(p_structural) <> 'array' OR jsonb_typeof(p_accessories) <> 'array' THEN
        RAISE EXCEPTION 'structural_components and accessories must be JSON arrays' USING ERRCODE='22023';
    END IF;

    SELECT minifig_composition_id INTO v_comp
    FROM definition.minifig_compositions
    WHERE inventory_version_id=p_inventory_version_id;

    IF v_comp IS NULL THEN
        INSERT INTO definition.minifig_compositions(inventory_version_id)
        VALUES(p_inventory_version_id)
        RETURNING minifig_composition_id INTO v_comp;
    END IF;

    IF p_replace THEN
        UPDATE definition.minifig_structural_components SET deleted_at=now()
        WHERE minifig_composition_id=v_comp AND deleted_at IS NULL;
        UPDATE definition.minifig_accessories SET deleted_at=now()
        WHERE minifig_composition_id=v_comp AND deleted_at IS NULL;
    END IF;

    CREATE TEMP TABLE IF NOT EXISTS bt_minifig_structural(
        semantic_role text,
        side text,
        position_index integer,
        part_variant_id uuid,
        decorated_variant_id text NOT NULL,
        quantity bigint,
        PRIMARY KEY(semantic_role,side,position_index,part_variant_id,decorated_variant_id)
    ) ON COMMIT DROP;
    TRUNCATE bt_minifig_structural;

    FOR e IN SELECT value FROM jsonb_array_elements(p_structural)
    LOOP
        PERFORM definition.validate_minifig_role(e->>'semantic_role',false);
        IF COALESCE((e->>'quantity')::bigint,0)<=0 THEN
            RAISE EXCEPTION 'Structural quantity must be positive' USING ERRCODE='22023';
        END IF;
        IF NULLIF(e->>'side','') IS NOT NULL AND upper(e->>'side') NOT IN ('LEFT','RIGHT','CENTER','NONE') THEN
            RAISE EXCEPTION 'Unsupported side %',e->>'side' USING ERRCODE='22023';
        END IF;
        INSERT INTO bt_minifig_structural VALUES(
            upper(e->>'semantic_role'),
            upper(COALESCE(NULLIF(e->>'side',''),'NONE')),
            COALESCE((e->>'position')::integer,0),
            (e->>'part_variant_id')::uuid,
            COALESCE(NULLIF(e->>'decorated_variant_id',''),''),
            (e->>'quantity')::bigint
        )
        ON CONFLICT(semantic_role,side,position_index,part_variant_id,decorated_variant_id)
        DO UPDATE SET quantity=bt_minifig_structural.quantity+EXCLUDED.quantity;
    END LOOP;

    INSERT INTO definition.minifig_structural_components(
        minifig_composition_id,minifig_role_id,semantic_role,side,position_index,
        part_variant_id,decorated_variant_id,quantity,deleted_at
    )
    SELECT v_comp,r.minifig_role_id,n.semantic_role,
           NULLIF(n.side,'NONE'),n.position_index,n.part_variant_id,
           NULLIF(n.decorated_variant_id,'')::uuid,n.quantity,NULL
    FROM bt_minifig_structural n
    JOIN reference.minifig_roles r ON r.role_code=n.semantic_role AND r.is_structural;

    CREATE TEMP TABLE IF NOT EXISTS bt_minifig_accessory(
        accessory_role text,
        position_index integer,
        part_variant_id uuid,
        decorated_variant_id text NOT NULL,
        quantity bigint,
        PRIMARY KEY(accessory_role,position_index,part_variant_id,decorated_variant_id)
    ) ON COMMIT DROP;
    TRUNCATE bt_minifig_accessory;

    FOR e IN SELECT value FROM jsonb_array_elements(p_accessories)
    LOOP
        PERFORM definition.validate_minifig_role(e->>'role',true);
        IF COALESCE((e->>'quantity')::bigint,0)<=0 THEN
            RAISE EXCEPTION 'Accessory quantity must be positive' USING ERRCODE='22023';
        END IF;
        INSERT INTO bt_minifig_accessory VALUES(
            upper(e->>'role'),COALESCE((e->>'position')::integer,0),
            (e->>'part_variant_id')::uuid,
            COALESCE(NULLIF(e->>'decorated_variant_id',''),''),
            (e->>'quantity')::bigint
        )
        ON CONFLICT(accessory_role,position_index,part_variant_id,decorated_variant_id)
        DO UPDATE SET quantity=bt_minifig_accessory.quantity+EXCLUDED.quantity;
    END LOOP;

    INSERT INTO definition.minifig_accessories(
        minifig_composition_id,accessory_role,part_variant_id,
        decorated_variant_id,quantity,position_index,deleted_at
    )
    SELECT v_comp,accessory_role,part_variant_id,NULLIF(decorated_variant_id,'')::uuid,
           quantity,position_index,NULL
    FROM bt_minifig_accessory;
END;
$$;

CREATE OR REPLACE FUNCTION api.create_custom_minifig_composition(
    p_catalog_item_id uuid,
    p_structural jsonb,
    p_accessories jsonb DEFAULT '[]'::jsonb,
    p_description text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog,catalog,definition,identity,app
AS $$
DECLARE
    i catalog.items%ROWTYPE;
    d uuid;
    v uuid;
BEGIN
    SELECT * INTO i FROM catalog.items WHERE catalog_item_id=p_catalog_item_id FOR UPDATE;
    IF NOT FOUND OR i.item_kind<>'CUSTOM_MINIFIGURE' OR i.deleted_at IS NOT NULL THEN
        RAISE EXCEPTION 'Custom Minifig not found' USING ERRCODE='P0002';
    END IF;
    PERFORM app.require_resource_owner(i.owner_id,'COLLECTION');
    d:=definition.ensure_inventory_definition(p_catalog_item_id,'MINIFIG_COMPOSITION');
    v:=definition.create_initial_version(d,p_description,identity.current_user_id());
    PERFORM definition.load_minifig_composition_payload(v,p_structural,p_accessories,false);
    RETURN app.build_minifig_composition_json(v);
END;
$$;

CREATE OR REPLACE FUNCTION api.get_minifig_composition(
    p_catalog_item_id uuid,
    p_version integer DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog,definition,catalog,identity,app
AS $$
DECLARE
    d uuid;
    v uuid;
    i catalog.items%ROWTYPE;
    v_user uuid:=identity.current_user_id_optional();
BEGIN
    SELECT * INTO i FROM catalog.items WHERE catalog_item_id=p_catalog_item_id;
    IF NOT FOUND OR i.item_kind NOT IN ('MINIFIGURE','CUSTOM_MINIFIGURE') OR i.deleted_at IS NOT NULL THEN
        RAISE EXCEPTION 'Minifig not found' USING ERRCODE='P0002';
    END IF;
    IF i.item_kind='CUSTOM_MINIFIGURE' AND i.visibility IN ('PRIVATE_DRAFT','FAMILY')
       AND (v_user IS NULL OR NOT identity.can_view_owner(v_user,i.owner_id,'COLLECTION')) THEN
        RAISE EXCEPTION 'Minifig not found' USING ERRCODE='P0002';
    END IF;

    SELECT inventory_definition_id INTO d
    FROM definition.inventory_definitions
    WHERE catalog_item_id=p_catalog_item_id
      AND definition_kind='MINIFIG_COMPOSITION';
    IF d IS NULL THEN RAISE EXCEPTION 'Composition not found' USING ERRCODE='P0002'; END IF;

    IF p_version IS NULL THEN
        IF i.item_kind='MINIFIGURE' THEN
            v:=definition.effective_inventory_version(d);
        ELSE
            SELECT inventory_version_id INTO v FROM definition.inventory_versions
            WHERE inventory_definition_id=d AND is_default;
        END IF;
    ELSE
        SELECT inventory_version_id INTO v FROM definition.inventory_versions
        WHERE inventory_definition_id=d AND semantic_version=p_version;
    END IF;

    IF v IS NULL THEN RAISE EXCEPTION 'Composition version not found' USING ERRCODE='P0002'; END IF;
    RETURN app.build_minifig_composition_json(v);
END;
$$;

CREATE OR REPLACE FUNCTION api.replace_custom_minifig_composition(
    p_inventory_version_id uuid,
    p_expected_edit_revision bigint,
    p_structural jsonb,
    p_accessories jsonb DEFAULT '[]'::jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog,definition,catalog,app
AS $$
DECLARE
    iv definition.inventory_versions%ROWTYPE;
    i catalog.items%ROWTYPE;
BEGIN
    SELECT * INTO iv FROM definition.inventory_versions
    WHERE inventory_version_id=p_inventory_version_id FOR UPDATE;
    IF NOT FOUND OR NOT iv.is_default OR iv.status='FINALIZED' THEN
        RAISE EXCEPTION 'Editable current Composition required' USING ERRCODE='55000';
    END IF;
    SELECT ci.* INTO i
    FROM definition.inventory_definitions d JOIN catalog.items ci ON ci.catalog_item_id=d.catalog_item_id
    WHERE d.inventory_definition_id=iv.inventory_definition_id
      AND d.definition_kind='MINIFIG_COMPOSITION';
    IF i.item_kind<>'CUSTOM_MINIFIGURE' OR i.deleted_at IS NOT NULL THEN
        RAISE EXCEPTION 'Custom Minifig not found' USING ERRCODE='P0002';
    END IF;
    PERFORM app.require_resource_owner(i.owner_id,'COLLECTION');
    IF iv.edit_revision<>p_expected_edit_revision THEN
        RAISE EXCEPTION 'Edit revision precondition failed' USING ERRCODE='40001';
    END IF;
    PERFORM definition.load_minifig_composition_payload(p_inventory_version_id,p_structural,p_accessories,true);
    PERFORM definition.bump_edit_revision(p_inventory_version_id);
    RETURN app.build_minifig_composition_json(p_inventory_version_id);
END;
$$;

CREATE OR REPLACE FUNCTION api.edit_custom_minifig_composition(
    p_inventory_version_id uuid,
    p_expected_edit_revision bigint,
    p_changes jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog,definition,catalog,app
AS $$
DECLARE
    iv definition.inventory_versions%ROWTYPE;
    i catalog.items%ROWTYPE;
    v_comp uuid;
    c jsonb;
    v_op text;
    v_target text;
BEGIN
    SELECT * INTO iv FROM definition.inventory_versions
    WHERE inventory_version_id=p_inventory_version_id FOR UPDATE;
    IF NOT FOUND OR NOT iv.is_default OR iv.status='FINALIZED' THEN
        RAISE EXCEPTION 'Editable current Composition required' USING ERRCODE='55000';
    END IF;
    SELECT ci.* INTO i
    FROM definition.inventory_definitions d JOIN catalog.items ci ON ci.catalog_item_id=d.catalog_item_id
    WHERE d.inventory_definition_id=iv.inventory_definition_id
      AND d.definition_kind='MINIFIG_COMPOSITION';
    PERFORM app.require_resource_owner(i.owner_id,'COLLECTION');
    IF iv.edit_revision<>p_expected_edit_revision THEN
        RAISE EXCEPTION 'Edit revision precondition failed' USING ERRCODE='40001';
    END IF;
    IF jsonb_typeof(p_changes)<>'array' THEN RAISE EXCEPTION 'changes must be an array' USING ERRCODE='22023'; END IF;
    SELECT minifig_composition_id INTO v_comp FROM definition.minifig_compositions WHERE inventory_version_id=p_inventory_version_id;

    FOR c IN SELECT value FROM jsonb_array_elements(p_changes)
    LOOP
        v_op:=lower(c->>'operation');
        v_target:=lower(c->>'target');
        IF v_op NOT IN ('add','set_quantity','remove') OR v_target NOT IN ('structural','accessory') THEN
            RAISE EXCEPTION 'Unsupported composition PATCH operation' USING ERRCODE='22023';
        END IF;
        IF v_target='structural' THEN
            IF v_op='add' THEN
                PERFORM definition.load_minifig_composition_payload(p_inventory_version_id,jsonb_build_array(c-'operation'-'target'),'[]'::jsonb,false);
            ELSIF v_op='set_quantity' THEN
                IF COALESCE((c->>'quantity')::bigint,0) <= 0 THEN
                    RAISE EXCEPTION 'quantity must be a positive integer' USING ERRCODE='22023';
                END IF;
                UPDATE definition.minifig_structural_components
                SET quantity=(c->>'quantity')::bigint
                WHERE minifig_composition_id=v_comp
                  AND semantic_role=upper(c->>'semantic_role')
                  AND side IS NOT DISTINCT FROM upper(NULLIF(c->>'side',''))
                  AND position_index=coalesce((c->>'position')::integer,0)
                  AND part_variant_id=(c->>'part_variant_id')::uuid
                  AND decorated_variant_id IS NOT DISTINCT FROM NULLIF(c->>'decorated_variant_id','')::uuid
                  AND deleted_at IS NULL;
                IF NOT FOUND THEN RAISE EXCEPTION 'Structural component not found' USING ERRCODE='55000'; END IF;
            ELSE
                UPDATE definition.minifig_structural_components SET deleted_at=now()
                WHERE minifig_composition_id=v_comp
                  AND semantic_role=upper(c->>'semantic_role')
                  AND side IS NOT DISTINCT FROM upper(NULLIF(c->>'side',''))
                  AND position_index=coalesce((c->>'position')::integer,0)
                  AND part_variant_id=(c->>'part_variant_id')::uuid
                  AND decorated_variant_id IS NOT DISTINCT FROM NULLIF(c->>'decorated_variant_id','')::uuid
                  AND deleted_at IS NULL;
            END IF;
        ELSE
            IF v_op='add' THEN
                PERFORM definition.load_minifig_composition_payload(p_inventory_version_id,'[]'::jsonb,jsonb_build_array(c-'operation'-'target'),false);
            ELSIF v_op='set_quantity' THEN
                IF COALESCE((c->>'quantity')::bigint,0) <= 0 THEN
                    RAISE EXCEPTION 'quantity must be a positive integer' USING ERRCODE='22023';
                END IF;
                UPDATE definition.minifig_accessories SET quantity=(c->>'quantity')::bigint
                WHERE minifig_composition_id=v_comp
                  AND accessory_role=upper(c->>'role')
                  AND position_index=coalesce((c->>'position')::integer,0)
                  AND part_variant_id=(c->>'part_variant_id')::uuid
                  AND decorated_variant_id IS NOT DISTINCT FROM NULLIF(c->>'decorated_variant_id','')::uuid
                  AND deleted_at IS NULL;
                IF NOT FOUND THEN RAISE EXCEPTION 'Accessory not found' USING ERRCODE='55000'; END IF;
            ELSE
                UPDATE definition.minifig_accessories SET deleted_at=now()
                WHERE minifig_composition_id=v_comp
                  AND accessory_role=upper(c->>'role')
                  AND position_index=coalesce((c->>'position')::integer,0)
                  AND part_variant_id=(c->>'part_variant_id')::uuid
                  AND decorated_variant_id IS NOT DISTINCT FROM NULLIF(c->>'decorated_variant_id','')::uuid
                  AND deleted_at IS NULL;
            END IF;
        END IF;
    END LOOP;

    PERFORM definition.bump_edit_revision(p_inventory_version_id);
    RETURN app.build_minifig_composition_json(p_inventory_version_id);
END;
$$;

CREATE OR REPLACE FUNCTION api.create_custom_minifig_composition_version(
    p_inventory_version_id uuid,
    p_expected_edit_revision bigint,
    p_description text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog,definition,catalog,app
AS $$
DECLARE
    iv definition.inventory_versions%ROWTYPE;
    i catalog.items%ROWTYPE;
    v_new uuid;
BEGIN
    SELECT * INTO iv FROM definition.inventory_versions WHERE inventory_version_id=p_inventory_version_id;
    SELECT ci.* INTO i
    FROM definition.inventory_definitions d JOIN catalog.items ci ON ci.catalog_item_id=d.catalog_item_id
    WHERE d.inventory_definition_id=iv.inventory_definition_id
      AND d.definition_kind='MINIFIG_COMPOSITION';
    IF i.item_kind<>'CUSTOM_MINIFIGURE' THEN
        RAISE EXCEPTION 'Custom Minifig composition required' USING ERRCODE='22023';
    END IF;
    PERFORM app.require_resource_owner(i.owner_id,'COLLECTION');
    v_new:=definition.create_semantic_version(p_inventory_version_id,p_expected_edit_revision,p_description);
    RETURN app.build_minifig_composition_json(v_new);
END;
$$;

CREATE OR REPLACE FUNCTION api.list_minifig_composition_versions(p_catalog_item_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog,definition,catalog,identity
AS $$
DECLARE
    i catalog.items%ROWTYPE;
    v_user uuid:=identity.current_user_id_optional();
    v_result jsonb;
BEGIN
    SELECT * INTO i FROM catalog.items WHERE catalog_item_id=p_catalog_item_id;
    IF NOT FOUND OR i.item_kind<>'CUSTOM_MINIFIGURE' OR i.deleted_at IS NOT NULL THEN
        RAISE EXCEPTION 'Custom Minifig not found' USING ERRCODE='P0002';
    END IF;
    IF i.visibility IN ('PRIVATE_DRAFT','FAMILY')
       AND (v_user IS NULL OR i.owner_id IS NULL OR NOT identity.can_view_owner(v_user,i.owner_id,'COLLECTION')) THEN
        RAISE EXCEPTION 'Custom Minifig not found' USING ERRCODE='P0002';
    END IF;

    SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'version',iv.semantic_version,
        'is_default',iv.is_default,
        'description',iv.description,
        'final_edit_revision',CASE WHEN NOT iv.is_default THEN iv.edit_revision ELSE NULL END,
        'edit_revision',CASE WHEN iv.is_default THEN iv.edit_revision ELSE NULL END
    ) ORDER BY iv.semantic_version),'[]'::jsonb)
    INTO v_result
    FROM definition.inventory_definitions d
    JOIN definition.inventory_versions iv USING(inventory_definition_id)
    WHERE d.catalog_item_id=p_catalog_item_id AND d.definition_kind='MINIFIG_COMPOSITION';
    RETURN v_result;
END;
$$;
