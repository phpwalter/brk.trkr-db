/*
===============================================================================
 File:           5000_Procedures/5150_lifecycle_integration_validation.sql
 Project:        BrickTrackr
 PostgreSQL:     16+
 Purpose:        Fail-fast validation of the unified ITEM / MOC / MINIFIG
                 lifecycle contract after the 5000_Procedures modules install.
===============================================================================
*/
\set ON_ERROR_STOP on

DO $validate_contract$
DECLARE
    sig text;
    missing text[]:=ARRAY[]::text[];
BEGIN
    -- Required public and internal contract routines.
    FOREACH sig IN ARRAY ARRAY[
        'app.require_active_user()',
        'app.require_actor_class(text[])',
        'app.require_resource_owner(uuid,text)',
        'app.build_catalog_item_json(uuid)',
        'app.build_catalog_manifest_json(uuid)',
        'app.build_minifig_composition_json(uuid)',

        'api.create_catalog_item(text,text,integer,integer,text)',
        'api.get_catalog_item(text,boolean)',
        'api.update_catalog_item(uuid,jsonb)',

        'definition.ensure_inventory_definition(uuid,definition.definition_kind)',
        'definition.lock_current_version(uuid)',
        'definition.create_initial_version(uuid,text,uuid)',
        'definition.create_semantic_version(uuid,bigint,text)',
        'definition.clone_version_graph(uuid,uuid)',
        'definition.compute_inventory_version_hash(uuid)',

        'api.create_moc_manifest(uuid,jsonb,text)',
        'api.get_catalog_manifest(uuid,integer)',
        'api.replace_moc_manifest(uuid,bigint,jsonb)',
        'api.edit_moc_manifest(uuid,bigint,jsonb)',
        'api.create_moc_manifest_version(uuid,bigint,text)',
        'api.list_moc_manifest_versions(uuid)',
        'api.fork_moc(uuid,text,uuid)',

        'api.create_custom_minifig_composition(uuid,jsonb,jsonb,text)',
        'api.get_minifig_composition(uuid,integer)',
        'api.replace_custom_minifig_composition(uuid,bigint,jsonb,jsonb)',
        'api.edit_custom_minifig_composition(uuid,bigint,jsonb)',
        'api.create_custom_minifig_composition_version(uuid,bigint,text)',
        'api.list_minifig_composition_versions(uuid)',

        'api.set_catalog_item_image(uuid,text,text,app.sha256_digest)',
        'api.remove_catalog_item_image(uuid)',
        'api.set_catalog_item_instructions(uuid,text,text,text,bigint,integer)',
        'api.remove_catalog_item_instructions(uuid)',

        'api.delete_moc(uuid,text)',
        'api.restore_moc(uuid)',
        'api.delete_custom_minifig(uuid)',
        'api.restore_custom_minifig(uuid)',

        'import.apply_source_field(uuid,smallint,text,jsonb)',
        'import.upsert_catalog_item(catalog.item_kind,text,text,smallint,text,text,integer,integer,integer)',
        'import.mark_source_mapping_missing(smallint,text,text,integer)',
        'import.sync_set_manifest(uuid,smallint,text,integer,jsonb,text)',
        'import.sync_minifig_composition(uuid,smallint,text,jsonb,jsonb,text)',

        'admin.set_catalog_item_override(uuid,text,jsonb,text)',
        'admin.clear_catalog_item_override(uuid,text)',
        'admin.remap_external_identifier(uuid,uuid,text)',
        'admin.create_definition_correction(uuid,text)',
        'admin.replace_set_manifest_correction(uuid,jsonb)',
        'admin.replace_minifig_composition_correction(uuid,jsonb,jsonb)',
        'admin.finalize_definition_correction(uuid)',
        'admin.activate_definition_correction(uuid,uuid)',
        'admin.clear_definition_correction(uuid)',

        'api.add_owned_instance(uuid,uuid,text)',
        'api.update_owned_instance(uuid,collection.item_condition,collection.package_condition,collection.assembly_state,collection.completeness_state,text)',
        'api.record_instance_adjustment(uuid,collection.adjustment_type,uuid,uuid,app.quantity,bigint,uuid,uuid,text)',
        'api.clear_instance_adjustment(bigint)',
        'api.get_instance_completeness(uuid)',
        'api.part_out_instance(uuid)',
        'api.assemble_minifig_instance(uuid)'
    ] LOOP
        IF to_regprocedure(sig) IS NULL THEN
            missing:=array_append(missing,sig);
        END IF;
    END LOOP;

    IF cardinality(missing)>0 THEN
        RAISE EXCEPTION 'Lifecycle contract routines missing: %',missing;
    END IF;

    -- Catalog Item authority/identity prerequisites.
    IF NOT EXISTS(
        SELECT 1 FROM pg_enum e
        JOIN pg_type t ON t.oid=e.enumtypid
        JOIN pg_namespace n ON n.oid=t.typnamespace
        WHERE n.nspname='catalog' AND t.typname='item_kind'
          AND e.enumlabel='CUSTOM_MINIFIGURE'
    ) THEN
        RAISE EXCEPTION 'CUSTOM_MINIFIGURE item kind missing';
    END IF;

    IF NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='catalog' AND table_name='items' AND column_name='item_num'
    ) OR NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='catalog' AND table_name='items' AND column_name='owner_id'
    ) OR NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='catalog' AND table_name='items' AND column_name='visibility'
    ) OR NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='catalog' AND table_name='items' AND column_name='deleted_at'
    ) THEN
        RAISE EXCEPTION 'Catalog Item lifecycle support columns are incomplete';
    END IF;

    IF NOT EXISTS(SELECT 1 FROM pg_indexes WHERE schemaname='catalog' AND indexname='uq_catalog_items_item_num') THEN
        RAISE EXCEPTION 'Catalog Item public identity uniqueness index missing';
    END IF;

    -- Version/concurrency prerequisites.
    IF NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='definition' AND table_name='inventory_versions' AND column_name='edit_revision'
    ) OR NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='definition' AND table_name='inventory_versions' AND column_name='is_default'
    ) THEN
        RAISE EXCEPTION 'Version edit-revision/current-default support missing';
    END IF;

    IF NOT EXISTS(SELECT 1 FROM pg_indexes WHERE schemaname='definition' AND indexname='uq_inventory_versions_one_default') THEN
        RAISE EXCEPTION 'One-current/default version invariant missing';
    END IF;

    IF NOT EXISTS(
        SELECT 1 FROM pg_constraint
        WHERE conname='uq_inventory_versions_number'
          AND conrelid='definition.inventory_versions'::regclass
    ) THEN
        RAISE EXCEPTION 'Semantic-version uniqueness invariant missing';
    END IF;

    -- Minifig normalized structural/accessory prerequisites.
    IF NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='definition' AND table_name='minifig_accessories'
          AND column_name='accessory_role'
    ) OR NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='definition' AND table_name='minifig_accessories'
          AND column_name='decorated_variant_id'
    ) THEN
        RAISE EXCEPTION 'Minifig accessory lifecycle columns missing';
    END IF;

    IF NOT EXISTS(SELECT 1 FROM pg_indexes WHERE schemaname='definition' AND indexname='uq_minifig_structural_identity')
       OR NOT EXISTS(SELECT 1 FROM pg_indexes WHERE schemaname='definition' AND indexname='uq_minifig_accessory_identity') THEN
        RAISE EXCEPTION 'Minifig normalized identity uniqueness indexes missing';
    END IF;

    -- Soft mutation/history prerequisites.
    IF NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='definition' AND table_name='requirement_groups' AND column_name='deleted_at'
    ) OR NOT EXISTS(
        SELECT 1 FROM information_schema.columns
        WHERE table_schema='collection' AND table_name='instance_adjustments' AND column_name='cleared_at'
    ) THEN
        RAISE EXCEPTION 'Soft mutation/history support is incomplete';
    END IF;

    -- Runtime must use procedures rather than direct mutation of newly introduced lifecycle tables.
    IF has_table_privilege('lego_api','catalog.custom_minifigures','INSERT')
       OR has_table_privilege('lego_api','catalog.item_documents','UPDATE')
       OR has_table_privilege('lego_app','definition.minifig_structural_components','DELETE') THEN
        RAISE EXCEPTION 'Runtime role has forbidden direct lifecycle table mutation privilege';
    END IF;

    -- Public API grants must exist after 5140.
    IF NOT has_function_privilege('lego_api','api.create_catalog_item(text,text,integer,integer,text)','EXECUTE')
       OR NOT has_function_privilege('lego_api','api.create_moc_manifest(uuid,jsonb,text)','EXECUTE')
       OR NOT has_function_privilege('lego_api','api.create_custom_minifig_composition(uuid,jsonb,jsonb,text)','EXECUTE') THEN
        RAISE EXCEPTION 'Lifecycle runtime API grants are incomplete';
    END IF;

    -- Privileged paths must be role-separated.
    IF NOT has_function_privilege('lego_importer','import.sync_set_manifest(uuid,smallint,text,integer,jsonb,text)','EXECUTE')
       OR NOT has_function_privilege('lego_admin','admin.set_catalog_item_override(uuid,text,jsonb,text)','EXECUTE') THEN
        RAISE EXCEPTION 'Import/admin lifecycle grants are incomplete';
    END IF;
END
$validate_contract$;

\echo '[PASS] 5150_lifecycle_integration_validation.sql'
