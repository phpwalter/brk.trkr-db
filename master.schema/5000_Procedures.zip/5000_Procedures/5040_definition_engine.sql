/* BrickTrackr 5040 - generic version-definition engine */
\set ON_ERROR_STOP on
CREATE OR REPLACE FUNCTION definition.ensure_inventory_definition(p_catalog_item_id uuid,p_kind definition.definition_kind)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,definition AS $$
DECLARE v_id uuid;
BEGIN
 INSERT INTO definition.inventory_definitions(catalog_item_id,definition_kind) VALUES(p_catalog_item_id,p_kind)
 ON CONFLICT(catalog_item_id,definition_kind) DO UPDATE SET definition_kind=EXCLUDED.definition_kind
 RETURNING inventory_definition_id INTO v_id; RETURN v_id;
END $$;

CREATE OR REPLACE FUNCTION definition.lock_current_version(p_definition_id uuid)
RETURNS definition.inventory_versions LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,definition AS $$
DECLARE v definition.inventory_versions%ROWTYPE;
BEGIN SELECT * INTO v FROM definition.inventory_versions WHERE inventory_definition_id=p_definition_id AND is_default FOR UPDATE; IF NOT FOUND THEN RAISE EXCEPTION 'Current version not found' USING ERRCODE='P0002'; END IF; RETURN v; END $$;

CREATE OR REPLACE FUNCTION definition.assert_edit_revision(p_version_id uuid,p_expected bigint)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,definition AS $$
DECLARE v bigint; BEGIN SELECT edit_revision INTO v FROM definition.inventory_versions WHERE inventory_version_id=p_version_id; IF v IS DISTINCT FROM p_expected THEN RAISE EXCEPTION 'Edit revision precondition failed' USING ERRCODE='40001'; END IF; END $$;

CREATE OR REPLACE FUNCTION definition.next_semantic_version(p_definition_id uuid)
RETURNS integer LANGUAGE sql STABLE SET search_path=pg_catalog,definition AS $$ SELECT coalesce(max(semantic_version),0)+1 FROM definition.inventory_versions WHERE inventory_definition_id=p_definition_id $$;

CREATE OR REPLACE FUNCTION definition.create_initial_version(p_definition_id uuid,p_description text DEFAULT NULL,p_created_by uuid DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,definition AS $$
DECLARE v uuid;
BEGIN
 IF EXISTS(SELECT 1 FROM definition.inventory_versions WHERE inventory_definition_id=p_definition_id) THEN RAISE EXCEPTION 'Initial version already exists' USING ERRCODE='23505'; END IF;
 INSERT INTO definition.inventory_versions(inventory_definition_id,semantic_version,status,created_by_user_id,edit_revision,is_default,description)
 VALUES(p_definition_id,1,'DRAFT',p_created_by,1,true,p_description) RETURNING inventory_version_id INTO v; RETURN v;
END $$;

CREATE OR REPLACE FUNCTION definition.bump_edit_revision(p_version_id uuid)
RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,definition AS $$
DECLARE v bigint; BEGIN UPDATE definition.inventory_versions SET edit_revision=edit_revision+1,last_seen_at=now() WHERE inventory_version_id=p_version_id AND status='DRAFT' AND (is_default OR is_admin_correction) RETURNING edit_revision INTO v; IF v IS NULL THEN RAISE EXCEPTION 'Only editable working/default or administrator-correction versions may change' USING ERRCODE='55000'; END IF; RETURN v; END $$;

CREATE OR REPLACE FUNCTION definition.prevent_finalized_extended_graph_mutation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, definition
AS $$
DECLARE
    v_version_id uuid;
    v_status definition.inventory_version_status;
    v_comp_id uuid;
BEGIN
    IF TG_TABLE_NAME='manifest_subassemblies' THEN
        v_version_id:=CASE WHEN TG_OP='DELETE' THEN OLD.inventory_version_id ELSE NEW.inventory_version_id END;
    ELSIF TG_TABLE_NAME='manifest_requirement_placements' THEN
        v_version_id:=CASE WHEN TG_OP='DELETE' THEN OLD.inventory_version_id ELSE NEW.inventory_version_id END;
    ELSIF TG_TABLE_NAME='minifig_compositions' THEN
        v_version_id:=CASE WHEN TG_OP='DELETE' THEN OLD.inventory_version_id ELSE NEW.inventory_version_id END;
    ELSIF TG_TABLE_NAME='minifig_structural_components' THEN
        v_comp_id:=CASE WHEN TG_OP='DELETE' THEN OLD.minifig_composition_id ELSE NEW.minifig_composition_id END;
        SELECT inventory_version_id INTO v_version_id
        FROM definition.minifig_compositions WHERE minifig_composition_id=v_comp_id;
    ELSIF TG_TABLE_NAME='minifig_accessories' THEN
        v_comp_id:=CASE WHEN TG_OP='DELETE' THEN OLD.minifig_composition_id ELSE NEW.minifig_composition_id END;
        SELECT inventory_version_id INTO v_version_id
        FROM definition.minifig_compositions WHERE minifig_composition_id=v_comp_id;
    END IF;

    SELECT status INTO v_status FROM definition.inventory_versions WHERE inventory_version_id=v_version_id;
    IF v_status='FINALIZED' THEN
        RAISE EXCEPTION 'Finalized version graph is immutable' USING ERRCODE='55000';
    END IF;
    RETURN CASE WHEN TG_OP='DELETE' THEN OLD ELSE NEW END;
END;
$$;

DO $$
DECLARE t text;
BEGIN
    FOREACH t IN ARRAY ARRAY['manifest_subassemblies','manifest_requirement_placements','minifig_compositions','minifig_structural_components','minifig_accessories']
    LOOP
        IF NOT EXISTS(SELECT 1 FROM pg_trigger WHERE tgname='trg_'||t||'_finalized_immutable') THEN
            EXECUTE format('CREATE TRIGGER %I BEFORE UPDATE OR DELETE ON definition.%I FOR EACH ROW EXECUTE FUNCTION definition.prevent_finalized_extended_graph_mutation()', 'trg_'||t||'_finalized_immutable',t);
        END IF;
    END LOOP;
END $$;
