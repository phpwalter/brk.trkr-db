/*
===============================================================================
 File:           1000_function/1016_rebrickable_catalog_reconcile.sql
 Project:        BrickTrackr
 PostgreSQL:     16+
 Purpose:        Durable, resumable, checkpointed Rebrickable Phase 3B
                 reconciliation.
 Depends On:     1000_function/1007_import_function.sql
                 catalog.items
                 catalog.parts
                 catalog.sets
                 catalog.minifigures
                 catalog.external_identifiers
                 catalog.source_values
                 catalog.source_value_history
                 reference.external_theme_mappings
                 reference.external_category_mappings
                 app.set_import_context(uuid)
                 reference.external_color_mappings
                 catalog.part_variants
                 catalog.lego_elements
 Creates:        checkpointed Rebrickable Phase 3B reconciliation objects
 Security:       SECURITY DEFINER; exact EXECUTE grant to lego_importer.
===============================================================================
*/
\set ON_ERROR_STOP on

SELECT pg_temp.bt_preflight('1000_function/1016_rebrickable_catalog_reconcile.sql', ARRAY['1000_function/1007_import_function.sql', 'catalog.items', 'catalog.parts', 'catalog.sets', 'catalog.minifigures', 'catalog.external_identifiers', 'catalog.source_values', 'catalog.source_value_history', 'reference.external_theme_mappings', 'reference.external_category_mappings', 'app.set_import_context(uuid)', 'reference.external_color_mappings', 'catalog.part_variants', 'catalog.lego_elements']::text[]);





/*
===============================================================================
 BrickTrackr Rebrickable Phase 3B - Durable Checkpointed Reconciliation
 Version: 3.2.2
 PostgreSQL: 16+

 Operational model
 -----------------
 - Phase 3A staging is retained and is NOT repeated.
 - Phase 3B is split into durable phase/substep checkpoints.
 - Batchable substeps commit one batch at a time.
 - Resume starts at the first incomplete checkpoint.
 - Restart clears only Phase 3B checkpoint state and reruns idempotently.
 - Canonical catalog UUIDs are never blindly deleted by Restart.
===============================================================================
*/

CREATE TABLE IF NOT EXISTS import.source_run_steps (
    source_run_id uuid NOT NULL
        REFERENCES import.source_runs(source_run_id)
        ON DELETE CASCADE,
    step_name text NOT NULL,
    step_order integer NOT NULL,
    status text NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'RUNNING', 'COMPLETED', 'FAILED')),
    attempt_count integer NOT NULL DEFAULT 0
        CHECK (attempt_count >= 0),
    started_at timestamptz,
    updated_at timestamptz NOT NULL DEFAULT now(),
    completed_at timestamptz,
    failed_at timestamptz,
    last_error text,
    PRIMARY KEY (source_run_id, step_name),
    UNIQUE (source_run_id, step_order)
);

CREATE TABLE IF NOT EXISTS import.source_run_step_progress (
    source_run_id uuid NOT NULL,
    step_name text NOT NULL,
    substep_name text NOT NULL,
    step_order integer NOT NULL,
    substep_order integer NOT NULL,
    status text NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'RUNNING', 'COMPLETED', 'FAILED')),
    rows_expected bigint,
    rows_processed bigint NOT NULL DEFAULT 0
        CHECK (rows_processed >= 0),
    last_source_row_number bigint,
    batch_count integer NOT NULL DEFAULT 0
        CHECK (batch_count >= 0),
    attempt_count integer NOT NULL DEFAULT 0
        CHECK (attempt_count >= 0),
    started_at timestamptz,
    updated_at timestamptz NOT NULL DEFAULT now(),
    completed_at timestamptz,
    failed_at timestamptz,
    last_error text,
    PRIMARY KEY (source_run_id, step_name, substep_name),
    UNIQUE (source_run_id, step_order, substep_order),
    FOREIGN KEY (source_run_id, step_name)
        REFERENCES import.source_run_steps(source_run_id, step_name)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS ix_source_run_step_progress_status
ON import.source_run_step_progress (
    source_run_id,
    status,
    step_order,
    substep_order
);

REVOKE ALL ON TABLE import.source_run_steps FROM PUBLIC;
REVOKE ALL ON TABLE import.source_run_step_progress FROM PUBLIC;

GRANT SELECT ON TABLE import.source_run_steps TO lego_importer;
GRANT SELECT ON TABLE import.source_run_step_progress TO lego_importer;


/* ---------------------------------------------------------------------------
 * Initialize or restart a Phase 3B checkpoint ledger.
 * --------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION import.phase3b_initialize(
    p_source_run_id uuid,
    p_restart boolean DEFAULT false
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
DECLARE
    v_source_id smallint;
    v_status import.source_run_status;
    v_parts bigint;
    v_sets bigint;
    v_minifigs bigint;
BEGIN
    SELECT r.source_id, r.status
      INTO v_source_id, v_status
    FROM import.source_runs r
    JOIN reference.external_sources es
      ON es.source_id = r.source_id
    WHERE r.source_run_id = p_source_run_id
      AND es.source_code = 'REBRICKABLE'
    FOR UPDATE OF r;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Rebrickable source run % does not exist', p_source_run_id
            USING ERRCODE = '22023';
    END IF;

    IF v_status = 'COMPLETED' AND p_restart THEN
        RAISE EXCEPTION
            'Completed source run % cannot be restarted through normal Phase 3B restart',
            p_source_run_id
            USING ERRCODE = '55000';
    END IF;

    IF v_status NOT IN ('VALIDATING', 'FINALIZING', 'COMPLETED') THEN
        RAISE EXCEPTION
            'Source run % is not eligible for Phase 3B; status=%',
            p_source_run_id, v_status
            USING ERRCODE = '55000';
    END IF;

    SELECT
        count(*) FILTER (WHERE dataset_name = 'parts'),
        count(*) FILTER (WHERE dataset_name = 'sets'),
        count(*) FILTER (WHERE dataset_name = 'minifigs')
    INTO v_parts, v_sets, v_minifigs
    FROM import.source_stage_records
    WHERE source_run_id = p_source_run_id;

    IF v_parts = 0 OR v_sets = 0 OR v_minifigs = 0 THEN
        RAISE EXCEPTION
            'Source run % does not contain complete Phase 3 staging',
            p_source_run_id
            USING ERRCODE = '55000';
    END IF;

    IF p_restart THEN
        DELETE FROM import.source_run_steps
        WHERE source_run_id = p_source_run_id;

        UPDATE import.source_runs
        SET
            status = 'VALIDATING',
            completed_at = NULL,
            failed_at = NULL,
            failure_message = NULL
        WHERE source_run_id = p_source_run_id;
    END IF;

    INSERT INTO import.source_run_steps (
        source_run_id, step_name, step_order
    )
    VALUES
        (p_source_run_id, 'VALIDATE_SOURCE_RUN', 1),
        (p_source_run_id, 'RECONCILE_PARTS', 2),
        (p_source_run_id, 'RECONCILE_SETS', 3),
        (p_source_run_id, 'RECONCILE_MINIFIGURES', 4),
        (p_source_run_id, 'SOURCE_PRESENCE', 5),
        (p_source_run_id, 'FINALIZE_SOURCE_RUN', 6)
    ON CONFLICT (source_run_id, step_name) DO NOTHING;

    INSERT INTO import.source_run_step_progress (
        source_run_id, step_name, substep_name,
        step_order, substep_order, rows_expected
    )
    VALUES
        (p_source_run_id, 'VALIDATE_SOURCE_RUN', 'RUN_CONTRACT',       1, 1, 1),
        (p_source_run_id, 'VALIDATE_SOURCE_RUN', 'STAGED_COUNTS',     1, 2, 1),
        (p_source_run_id, 'VALIDATE_SOURCE_RUN', 'REFERENCE_LINKS',   1, 3, 1),

        (p_source_run_id, 'RECONCILE_PARTS', 'CATALOG_IDENTITIES',    2, 1, v_parts),
        (p_source_run_id, 'RECONCILE_PARTS', 'PART_ROWS',             2, 2, v_parts),
        (p_source_run_id, 'RECONCILE_PARTS', 'SOURCE_VALUES',         2, 3, v_parts),

        (p_source_run_id, 'RECONCILE_SETS', 'CATALOG_IDENTITIES',     3, 1, v_sets),
        (p_source_run_id, 'RECONCILE_SETS', 'SET_ROWS',               3, 2, v_sets),
        (p_source_run_id, 'RECONCILE_SETS', 'SOURCE_VALUES',          3, 3, v_sets),

        (p_source_run_id, 'RECONCILE_MINIFIGURES', 'CATALOG_IDENTITIES', 4, 1, v_minifigs),
        (p_source_run_id, 'RECONCILE_MINIFIGURES', 'MINIFIGURE_ROWS',   4, 2, v_minifigs),
        (p_source_run_id, 'RECONCILE_MINIFIGURES', 'SOURCE_VALUES',      4, 3, v_minifigs),

        (p_source_run_id, 'SOURCE_PRESENCE', 'PARTS',                 5, 1, 1),
        (p_source_run_id, 'SOURCE_PRESENCE', 'SETS',                  5, 2, 1),
        (p_source_run_id, 'SOURCE_PRESENCE', 'MINIFIGURES',           5, 3, 1),

        (p_source_run_id, 'FINALIZE_SOURCE_RUN', 'VERIFY_COUNTS',     6, 1, 1),
        (p_source_run_id, 'FINALIZE_SOURCE_RUN', 'COMPLETE_RUN',      6, 2, 1)
    ON CONFLICT (source_run_id, step_name, substep_name) DO NOTHING;

    RETURN jsonb_build_object(
        'source_run_id', p_source_run_id,
        'restart', p_restart,
        'parts', v_parts,
        'sets', v_sets,
        'minifigures', v_minifigs
    );
END;
$$;


/* ---------------------------------------------------------------------------
 * Execute one durable checkpoint batch.
 * Every call is designed to be committed independently by the client.
 * --------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION import.phase3b_run_checkpoint(
    p_source_run_id uuid,
    p_step_name text,
    p_substep_name text,
    p_batch_size integer DEFAULT 5000
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
DECLARE
    v_source_id smallint;
    v_status text;
    v_rows_expected bigint;
    v_rows_processed bigint;
    v_last bigint;
    v_batch_count integer;
    v_batch_rows bigint := 0;
    v_batch_last bigint;
    v_now timestamptz := clock_timestamp();
    v_namespace text;
    v_dataset text;
    v_kind text;
BEGIN
    IF p_batch_size < 1 OR p_batch_size > 50000 THEN
        RAISE EXCEPTION 'batch_size must be between 1 and 50000'
            USING ERRCODE = '22023';
    END IF;
    PERFORM app.set_import_context(p_source_run_id);

    SELECT r.source_id
      INTO v_source_id
    FROM import.source_runs r
    JOIN reference.external_sources es
      ON es.source_id = r.source_id
    WHERE r.source_run_id = p_source_run_id
      AND es.source_code = 'REBRICKABLE';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Rebrickable source run % does not exist', p_source_run_id;
    END IF;

    SELECT
        status,
        rows_expected,
        rows_processed,
        COALESCE(last_source_row_number, 0),
        batch_count
    INTO
        v_status,
        v_rows_expected,
        v_rows_processed,
        v_last,
        v_batch_count
    FROM import.source_run_step_progress
    WHERE source_run_id = p_source_run_id
      AND step_name = p_step_name
      AND substep_name = p_substep_name
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION
            'Unknown Phase 3B checkpoint %.%',
            p_step_name, p_substep_name
            USING ERRCODE = '22023';
    END IF;

    IF v_status = 'COMPLETED' THEN
        RETURN jsonb_build_object(
            'step', p_step_name,
            'substep', p_substep_name,
            'status', 'COMPLETED',
            'rows_processed', v_rows_processed,
            'rows_expected', v_rows_expected,
            'batch_count', v_batch_count
        );
    END IF;

    /* Enforce strict checkpoint ordering. */
    IF EXISTS (
        SELECT 1
        FROM import.source_run_step_progress prior
        JOIN import.source_run_step_progress cur
          ON cur.source_run_id = prior.source_run_id
         AND cur.step_name = p_step_name
         AND cur.substep_name = p_substep_name
        WHERE prior.source_run_id = p_source_run_id
          AND (prior.step_order, prior.substep_order)
              < (cur.step_order, cur.substep_order)
          AND prior.status <> 'COMPLETED'
    ) THEN
        RAISE EXCEPTION
            'Earlier Phase 3B checkpoint is not complete'
            USING ERRCODE = '55000';
    END IF;

    UPDATE import.source_run_steps
    SET
        status = 'RUNNING',
        attempt_count = attempt_count + CASE WHEN status <> 'RUNNING' THEN 1 ELSE 0 END,
        started_at = COALESCE(started_at, v_now),
        updated_at = v_now,
        failed_at = NULL,
        last_error = NULL
    WHERE source_run_id = p_source_run_id
      AND step_name = p_step_name;

    UPDATE import.source_run_step_progress
    SET
        status = 'RUNNING',
        attempt_count = attempt_count + CASE WHEN status <> 'RUNNING' THEN 1 ELSE 0 END,
        started_at = COALESCE(started_at, v_now),
        updated_at = v_now,
        failed_at = NULL,
        last_error = NULL
    WHERE source_run_id = p_source_run_id
      AND step_name = p_step_name
      AND substep_name = p_substep_name;

    /* ======================================================================
     * Non-batch validation checkpoints.
     * ====================================================================== */

    IF p_step_name = 'VALIDATE_SOURCE_RUN'
       AND p_substep_name = 'RUN_CONTRACT'
    THEN
        IF EXISTS (
            SELECT 1
            FROM (VALUES ('parts'), ('sets'), ('minifigs')) req(dataset_name)
            LEFT JOIN import.source_run_datasets d
              ON d.source_run_id = p_source_run_id
             AND d.dataset_name = req.dataset_name
            WHERE d.source_run_dataset_id IS NULL
               OR d.status <> 'VALIDATED'
               OR d.source_row_count IS NULL
               OR d.staged_row_count IS NULL
               OR d.source_row_count <> d.staged_row_count
               OR d.checksum_sha256 IS NULL
        ) THEN
            RAISE EXCEPTION 'Phase 3 source-run contract validation failed'
                USING ERRCODE = '55000';
        END IF;

        v_batch_rows := 1;

    ELSIF p_step_name = 'VALIDATE_SOURCE_RUN'
       AND p_substep_name = 'STAGED_COUNTS'
    THEN
        IF EXISTS (
            SELECT 1
            FROM import.source_run_datasets d
            WHERE d.source_run_id = p_source_run_id
              AND d.dataset_name IN ('parts', 'sets', 'minifigs')
              AND d.staged_row_count <> (
                  SELECT count(*)
                  FROM import.source_stage_records sr
                  WHERE sr.source_run_id = d.source_run_id
                    AND sr.dataset_name = d.dataset_name
              )
        ) THEN
            RAISE EXCEPTION 'Phase 3 staged row counts changed after validation'
                USING ERRCODE = '55000';
        END IF;

        v_batch_rows := 1;

    ELSIF p_step_name = 'VALIDATE_SOURCE_RUN'
       AND p_substep_name = 'REFERENCE_LINKS'
    THEN
        IF EXISTS (
            SELECT 1
            FROM import.source_stage_records sr
            LEFT JOIN reference.external_category_mappings m
              ON m.source_id = v_source_id
             AND m.external_category_id =
                 NULLIF(sr.normalized_payload->>'part_cat_id', '')
             AND m.source_present
            WHERE sr.source_run_id = p_source_run_id
              AND sr.dataset_name = 'parts'
              AND NULLIF(sr.normalized_payload->>'part_cat_id', '') IS NOT NULL
              AND m.category_id IS NULL
        ) THEN
            RAISE EXCEPTION 'Unknown active Rebrickable part category exists'
                USING ERRCODE = '23503';
        END IF;

        IF EXISTS (
            SELECT 1
            FROM import.source_stage_records sr
            LEFT JOIN reference.external_theme_mappings m
              ON m.source_id = v_source_id
             AND m.external_theme_id =
                 NULLIF(sr.normalized_payload->>'theme_id', '')
             AND m.source_present
            WHERE sr.source_run_id = p_source_run_id
              AND sr.dataset_name = 'sets'
              AND NULLIF(sr.normalized_payload->>'theme_id', '') IS NOT NULL
              AND m.theme_id IS NULL
        ) THEN
            RAISE EXCEPTION 'Unknown active Rebrickable theme exists'
                USING ERRCODE = '23503';
        END IF;

        v_batch_rows := 1;


    /* ======================================================================
     * Batchable entity checkpoints.
     * ====================================================================== */

    ELSIF p_step_name IN (
        'RECONCILE_PARTS',
        'RECONCILE_SETS',
        'RECONCILE_MINIFIGURES'
    ) THEN

        IF p_step_name = 'RECONCILE_PARTS' THEN
            v_dataset := 'parts';
            v_namespace := 'PART';
            v_kind := 'PART';
        ELSIF p_step_name = 'RECONCILE_SETS' THEN
            v_dataset := 'sets';
            v_namespace := 'SET';
            v_kind := 'SET';
        ELSE
            v_dataset := 'minifigs';
            v_namespace := 'MINIFIGURE';
            v_kind := 'MINIFIGURE';
        END IF;

        DROP TABLE IF EXISTS pg_temp.bt_p3_obs;
        DROP TABLE IF EXISTS pg_temp.bt_p3_identity_work;
        DROP TABLE IF EXISTS pg_temp.bt_p3_batch;

        CREATE TEMP TABLE bt_p3_batch
        ON COMMIT DROP
        AS
        SELECT
            sr.source_row_number,
            sr.normalized_payload
        FROM import.source_stage_records sr
        WHERE sr.source_run_id = p_source_run_id
          AND sr.dataset_name = v_dataset
          AND sr.entity_namespace = v_namespace
          AND sr.source_row_number > v_last
        ORDER BY sr.source_row_number
        LIMIT p_batch_size;

        SELECT count(*), max(source_row_number)
          INTO v_batch_rows, v_batch_last
        FROM bt_p3_batch;

        IF v_batch_rows = 0 THEN
            /* Nothing left: checkpoint completion is handled below. */
            v_batch_last := v_last;

        ELSIF p_substep_name = 'CATALOG_IDENTITIES' THEN

            CREATE TEMP TABLE bt_p3_identity_work
            ON COMMIT DROP
            AS
            SELECT
                b.source_row_number,
                CASE
                    WHEN v_namespace = 'PART'
                        THEN b.normalized_payload->>'part_num'
                    WHEN v_namespace = 'SET'
                        THEN b.normalized_payload->>'set_num'
                    ELSE b.normalized_payload->>'fig_num'
                END AS external_id,
                b.normalized_payload->>'name' AS canonical_name,
                ei.catalog_item_id,
                ei.external_identifier_id,
                COALESCE(ei.catalog_item_id, app.uuid_v7())
                    AS resolved_catalog_item_id
            FROM bt_p3_batch b
            LEFT JOIN catalog.external_identifiers ei
              ON ei.source_id = v_source_id
             AND ei.entity_namespace = v_namespace
             AND ei.external_id = CASE
                    WHEN v_namespace = 'PART'
                        THEN b.normalized_payload->>'part_num'
                    WHEN v_namespace = 'SET'
                        THEN b.normalized_payload->>'set_num'
                    ELSE b.normalized_payload->>'fig_num'
                 END
             AND ei.external_version IS NULL;

            INSERT INTO catalog.items (
                catalog_item_id,
                item_kind,
                canonical_name
            )
            SELECT
                resolved_catalog_item_id,
                v_kind::catalog.item_kind,
                canonical_name
            FROM bt_p3_identity_work
            WHERE catalog_item_id IS NULL;

            UPDATE catalog.items i
            SET canonical_name = w.canonical_name
            FROM bt_p3_identity_work w
            WHERE i.catalog_item_id = w.resolved_catalog_item_id
              AND i.canonical_name IS DISTINCT FROM w.canonical_name;

            INSERT INTO catalog.external_identifiers (
                source_id,
                entity_namespace,
                external_id,
                external_version,
                catalog_item_id,
                source_present,
                valid_from,
                valid_to,
                first_seen_at,
                last_seen_at
            )
            SELECT
                v_source_id,
                v_namespace,
                external_id,
                NULL,
                resolved_catalog_item_id,
                true,
                CURRENT_DATE,
                NULL,
                v_now,
                v_now
            FROM bt_p3_identity_work
            WHERE external_identifier_id IS NULL;

            UPDATE catalog.external_identifiers ei
            SET
                source_present = true,
                valid_to = NULL,
                last_seen_at = v_now
            FROM bt_p3_identity_work w
            WHERE ei.external_identifier_id = w.external_identifier_id
              AND w.external_identifier_id IS NOT NULL;

        ELSIF p_step_name = 'RECONCILE_PARTS'
          AND p_substep_name = 'PART_ROWS'
        THEN
            INSERT INTO catalog.parts (
                catalog_item_id,
                lego_design_id,
                category_id,
                design_name
            )
            SELECT
                ei.catalog_item_id,
                CASE
                    WHEN (b.normalized_payload->>'part_num') ~ '^[0-9]+$'
                     AND (b.normalized_payload->>'part_num')::numeric
                         BETWEEN 1 AND 2147483647
                    THEN (b.normalized_payload->>'part_num')::integer
                    ELSE NULL
                END,
                cm.category_id,
                b.normalized_payload->>'name'
            FROM bt_p3_batch b
            JOIN catalog.external_identifiers ei
              ON ei.source_id = v_source_id
             AND ei.entity_namespace = 'PART'
             AND ei.external_id = b.normalized_payload->>'part_num'
             AND ei.external_version IS NULL
            LEFT JOIN reference.external_category_mappings cm
              ON cm.source_id = v_source_id
             AND cm.external_category_id =
                 NULLIF(b.normalized_payload->>'part_cat_id', '')
             AND cm.source_present
            ON CONFLICT (catalog_item_id)
            DO UPDATE SET
                lego_design_id = EXCLUDED.lego_design_id,
                category_id = EXCLUDED.category_id,
                design_name = EXCLUDED.design_name;

        ELSIF p_step_name = 'RECONCILE_SETS'
          AND p_substep_name = 'SET_ROWS'
        THEN
            INSERT INTO catalog.sets (
                catalog_item_id,
                lego_set_id,
                theme_id,
                release_year
            )
            SELECT
                ei.catalog_item_id,
                CASE
                    WHEN regexp_replace(
                        b.normalized_payload->>'set_num',
                        '-[^-]+$',
                        ''
                    ) ~ '^[0-9]+$'
                     AND regexp_replace(
                        b.normalized_payload->>'set_num',
                        '-[^-]+$',
                        ''
                    )::numeric BETWEEN 1 AND 2147483647
                    THEN regexp_replace(
                        b.normalized_payload->>'set_num',
                        '-[^-]+$',
                        ''
                    )::integer
                    ELSE NULL
                END,
                tm.theme_id,
                NULLIF(b.normalized_payload->>'year', '')::smallint
            FROM bt_p3_batch b
            JOIN catalog.external_identifiers ei
              ON ei.source_id = v_source_id
             AND ei.entity_namespace = 'SET'
             AND ei.external_id = b.normalized_payload->>'set_num'
             AND ei.external_version IS NULL
            LEFT JOIN reference.external_theme_mappings tm
              ON tm.source_id = v_source_id
             AND tm.external_theme_id =
                 NULLIF(b.normalized_payload->>'theme_id', '')
             AND tm.source_present
            ON CONFLICT (catalog_item_id)
            DO UPDATE SET
                lego_set_id = EXCLUDED.lego_set_id,
                theme_id = EXCLUDED.theme_id,
                release_year = EXCLUDED.release_year;

        ELSIF p_step_name = 'RECONCILE_MINIFIGURES'
          AND p_substep_name = 'MINIFIGURE_ROWS'
        THEN
            INSERT INTO catalog.minifigures (
                catalog_item_id,
                lego_minifig_id,
                theme_id
            )
            SELECT
                ei.catalog_item_id,
                CASE
                    WHEN (b.normalized_payload->>'fig_num') ~ '^[0-9]+$'
                     AND (b.normalized_payload->>'fig_num')::numeric
                         BETWEEN 1 AND 2147483647
                    THEN (b.normalized_payload->>'fig_num')::integer
                    ELSE NULL
                END,
                NULL
            FROM bt_p3_batch b
            JOIN catalog.external_identifiers ei
              ON ei.source_id = v_source_id
             AND ei.entity_namespace = 'MINIFIGURE'
             AND ei.external_id = b.normalized_payload->>'fig_num'
             AND ei.external_version IS NULL
            ON CONFLICT (catalog_item_id)
            DO UPDATE SET
                lego_minifig_id = EXCLUDED.lego_minifig_id;

        ELSIF p_substep_name = 'SOURCE_VALUES' THEN

            CREATE TEMP TABLE bt_p3_obs (
                catalog_item_id uuid NOT NULL,
                field_name text NOT NULL,
                source_value jsonb NOT NULL,
                PRIMARY KEY (catalog_item_id, field_name)
            ) ON COMMIT DROP;

            IF p_step_name = 'RECONCILE_PARTS' THEN
                INSERT INTO bt_p3_obs
                SELECT ei.catalog_item_id, 'rebrickable.part_num',
                       to_jsonb(b.normalized_payload->>'part_num')
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'PART'
                 AND ei.external_id = b.normalized_payload->>'part_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'name',
                       to_jsonb(b.normalized_payload->>'name')
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'PART'
                 AND ei.external_id = b.normalized_payload->>'part_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'rebrickable.part_cat_id',
                       COALESCE(
                           to_jsonb(NULLIF(b.normalized_payload->>'part_cat_id','')),
                           'null'::jsonb
                       )
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'PART'
                 AND ei.external_id = b.normalized_payload->>'part_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'rebrickable.part_material',
                       COALESCE(
                           to_jsonb(NULLIF(b.normalized_payload->>'part_material','')),
                           'null'::jsonb
                       )
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'PART'
                 AND ei.external_id = b.normalized_payload->>'part_num'
                 AND ei.external_version IS NULL;

            ELSIF p_step_name = 'RECONCILE_SETS' THEN
                INSERT INTO bt_p3_obs
                SELECT ei.catalog_item_id, 'rebrickable.set_num',
                       to_jsonb(b.normalized_payload->>'set_num')
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'SET'
                 AND ei.external_id = b.normalized_payload->>'set_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'name',
                       to_jsonb(b.normalized_payload->>'name')
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'SET'
                 AND ei.external_id = b.normalized_payload->>'set_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'release_year',
                       COALESCE(
                           to_jsonb(NULLIF(b.normalized_payload->>'year','')::smallint),
                           'null'::jsonb
                       )
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'SET'
                 AND ei.external_id = b.normalized_payload->>'set_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'rebrickable.theme_id',
                       COALESCE(
                           to_jsonb(NULLIF(b.normalized_payload->>'theme_id','')),
                           'null'::jsonb
                       )
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'SET'
                 AND ei.external_id = b.normalized_payload->>'set_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'rebrickable.num_parts',
                       COALESCE(
                           to_jsonb(NULLIF(b.normalized_payload->>'num_parts','')::bigint),
                           'null'::jsonb
                       )
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'SET'
                 AND ei.external_id = b.normalized_payload->>'set_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'rebrickable.img_url',
                       COALESCE(
                           to_jsonb(NULLIF(b.normalized_payload->>'img_url','')),
                           'null'::jsonb
                       )
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'SET'
                 AND ei.external_id = b.normalized_payload->>'set_num'
                 AND ei.external_version IS NULL;

            ELSE
                INSERT INTO bt_p3_obs
                SELECT ei.catalog_item_id, 'rebrickable.fig_num',
                       to_jsonb(b.normalized_payload->>'fig_num')
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'MINIFIGURE'
                 AND ei.external_id = b.normalized_payload->>'fig_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'name',
                       to_jsonb(b.normalized_payload->>'name')
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'MINIFIGURE'
                 AND ei.external_id = b.normalized_payload->>'fig_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'rebrickable.num_parts',
                       COALESCE(
                           to_jsonb(NULLIF(b.normalized_payload->>'num_parts','')::bigint),
                           'null'::jsonb
                       )
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'MINIFIGURE'
                 AND ei.external_id = b.normalized_payload->>'fig_num'
                 AND ei.external_version IS NULL
                UNION ALL
                SELECT ei.catalog_item_id, 'rebrickable.img_url',
                       COALESCE(
                           to_jsonb(NULLIF(b.normalized_payload->>'img_url','')),
                           'null'::jsonb
                       )
                FROM bt_p3_batch b
                JOIN catalog.external_identifiers ei
                  ON ei.source_id = v_source_id
                 AND ei.entity_namespace = 'MINIFIGURE'
                 AND ei.external_id = b.normalized_payload->>'fig_num'
                 AND ei.external_version IS NULL;
            END IF;

            INSERT INTO catalog.source_value_history (
                catalog_item_id,
                source_id,
                field_name,
                old_value,
                new_value,
                source_run_id,
                changed_at
            )
            SELECT
                o.catalog_item_id,
                v_source_id,
                o.field_name,
                sv.source_value,
                o.source_value,
                p_source_run_id,
                v_now
            FROM bt_p3_obs o
            JOIN catalog.source_values sv
              ON sv.catalog_item_id = o.catalog_item_id
             AND sv.source_id = v_source_id
             AND sv.field_name = o.field_name
            WHERE sv.source_value IS DISTINCT FROM o.source_value;

            INSERT INTO catalog.source_values (
                catalog_item_id,
                source_id,
                field_name,
                source_value,
                first_seen_at,
                last_seen_at,
                last_source_run_id
            )
            SELECT
                o.catalog_item_id,
                v_source_id,
                o.field_name,
                o.source_value,
                v_now,
                v_now,
                p_source_run_id
            FROM bt_p3_obs o
            ON CONFLICT (catalog_item_id, source_id, field_name)
            DO UPDATE SET
                source_value = EXCLUDED.source_value,
                last_seen_at = EXCLUDED.last_seen_at,
                last_source_run_id = EXCLUDED.last_source_run_id;

        ELSE
            RAISE EXCEPTION 'Unsupported batch checkpoint %.%',
                p_step_name, p_substep_name
                USING ERRCODE = '22023';
        END IF;


    /* ======================================================================
     * Source-presence cleanup.
     * ====================================================================== */

    ELSIF p_step_name = 'SOURCE_PRESENCE' THEN

        IF p_substep_name = 'PARTS' THEN
            v_namespace := 'PART';
            v_dataset := 'parts';
        ELSIF p_substep_name = 'SETS' THEN
            v_namespace := 'SET';
            v_dataset := 'sets';
        ELSIF p_substep_name = 'MINIFIGURES' THEN
            v_namespace := 'MINIFIGURE';
            v_dataset := 'minifigs';
        ELSE
            RAISE EXCEPTION 'Unknown source-presence checkpoint';
        END IF;

        UPDATE catalog.external_identifiers ei
        SET
            source_present = false,
            valid_to = CURRENT_DATE
        WHERE ei.source_id = v_source_id
          AND ei.entity_namespace = v_namespace
          AND ei.source_present
          AND NOT EXISTS (
              SELECT 1
              FROM import.source_stage_records sr
              WHERE sr.source_run_id = p_source_run_id
                AND sr.dataset_name = v_dataset
                AND sr.entity_namespace = v_namespace
                AND CASE
                    WHEN v_namespace = 'PART'
                        THEN sr.normalized_payload->>'part_num'
                    WHEN v_namespace = 'SET'
                        THEN sr.normalized_payload->>'set_num'
                    ELSE sr.normalized_payload->>'fig_num'
                END = ei.external_id
          );

        v_batch_rows := 1;


    /* ======================================================================
     * Final verification and completion.
     * ====================================================================== */

    ELSIF p_step_name = 'FINALIZE_SOURCE_RUN'
      AND p_substep_name = 'VERIFY_COUNTS'
    THEN
        IF EXISTS (
            SELECT 1
            FROM (
                VALUES
                    ('parts', 'PART'),
                    ('sets', 'SET'),
                    ('minifigs', 'MINIFIGURE')
            ) x(dataset_name, entity_namespace)
            WHERE (
                SELECT count(*)
                FROM import.source_stage_records sr
                WHERE sr.source_run_id = p_source_run_id
                  AND sr.dataset_name = x.dataset_name
                  AND sr.entity_namespace = x.entity_namespace
            ) <> (
                SELECT count(*)
                FROM catalog.external_identifiers ei
                WHERE ei.source_id = v_source_id
                  AND ei.entity_namespace = x.entity_namespace
                  AND ei.source_present
            )
        ) THEN
            RAISE EXCEPTION 'Phase 3B active external-identifier count verification failed'
                USING ERRCODE = '23514';
        END IF;

        v_batch_rows := 1;

    ELSIF p_step_name = 'FINALIZE_SOURCE_RUN'
      AND p_substep_name = 'COMPLETE_RUN'
    THEN
        UPDATE import.source_run_datasets
        SET
            status = 'COMPLETED',
            completed_at = COALESCE(completed_at, v_now)
        WHERE source_run_id = p_source_run_id
          AND dataset_name IN ('parts', 'sets', 'minifigs');

        PERFORM import.complete_source_run(
            p_source_run_id,
            jsonb_build_object(
                'catalog_reconciliation',
                jsonb_build_object(
                    'phase', 3,
                    'strategy', 'checkpointed-v3.2.2',
                    'completed_at', v_now
                )
            )
        );

        v_batch_rows := 1;

    ELSE
        RAISE EXCEPTION 'Unsupported Phase 3B checkpoint %.%',
            p_step_name, p_substep_name
            USING ERRCODE = '22023';
    END IF;


    /* ----------------------------------------------------------------------
     * Durable checkpoint accounting.
     * ---------------------------------------------------------------------- */

    IF p_step_name IN (
        'RECONCILE_PARTS',
        'RECONCILE_SETS',
        'RECONCILE_MINIFIGURES'
    ) THEN
        UPDATE import.source_run_step_progress
        SET
            rows_processed = LEAST(
                COALESCE(rows_expected, rows_processed + v_batch_rows),
                rows_processed + v_batch_rows
            ),
            last_source_row_number = CASE
                WHEN v_batch_rows > 0 THEN v_batch_last
                ELSE last_source_row_number
            END,
            batch_count = batch_count + CASE WHEN v_batch_rows > 0 THEN 1 ELSE 0 END,
            updated_at = clock_timestamp()
        WHERE source_run_id = p_source_run_id
          AND step_name = p_step_name
          AND substep_name = p_substep_name;
    ELSE
        UPDATE import.source_run_step_progress
        SET
            rows_processed = COALESCE(rows_expected, 1),
            batch_count = batch_count + 1,
            updated_at = clock_timestamp()
        WHERE source_run_id = p_source_run_id
          AND step_name = p_step_name
          AND substep_name = p_substep_name;
    END IF;

    UPDATE import.source_run_step_progress
    SET
        status = CASE
            WHEN rows_expected IS NULL OR rows_processed >= rows_expected
                THEN 'COMPLETED'
            ELSE 'RUNNING'
        END,
        completed_at = CASE
            WHEN rows_expected IS NULL OR rows_processed >= rows_expected
                THEN clock_timestamp()
            ELSE NULL
        END,
        updated_at = clock_timestamp()
    WHERE source_run_id = p_source_run_id
      AND step_name = p_step_name
      AND substep_name = p_substep_name;

    UPDATE import.source_run_steps s
    SET
        status = CASE
            WHEN NOT EXISTS (
                SELECT 1
                FROM import.source_run_step_progress p
                WHERE p.source_run_id = s.source_run_id
                  AND p.step_name = s.step_name
                  AND p.status <> 'COMPLETED'
            ) THEN 'COMPLETED'
            ELSE 'RUNNING'
        END,
        completed_at = CASE
            WHEN NOT EXISTS (
                SELECT 1
                FROM import.source_run_step_progress p
                WHERE p.source_run_id = s.source_run_id
                  AND p.step_name = s.step_name
                  AND p.status <> 'COMPLETED'
            ) THEN clock_timestamp()
            ELSE NULL
        END,
        updated_at = clock_timestamp()
    WHERE s.source_run_id = p_source_run_id
      AND s.step_name = p_step_name;

    RETURN (
        SELECT jsonb_build_object(
            'step', step_name,
            'substep', substep_name,
            'status', status,
            'rows_processed', rows_processed,
            'rows_expected', rows_expected,
            'batch_count', batch_count,
            'last_source_row_number', last_source_row_number,
            'percent_complete',
                CASE
                    WHEN rows_expected > 0
                    THEN round(100.0 * rows_processed / rows_expected, 1)
                    ELSE NULL
                END
        )
        FROM import.source_run_step_progress
        WHERE source_run_id = p_source_run_id
          AND step_name = p_step_name
          AND substep_name = p_substep_name
    );
END;
$$;


CREATE OR REPLACE FUNCTION import.phase3b_progress(
    p_source_run_id uuid
)
RETURNS TABLE (
    step_order integer,
    substep_order integer,
    step_name text,
    substep_name text,
    status text,
    rows_processed bigint,
    rows_expected bigint,
    percent_complete numeric,
    batch_count integer,
    last_source_row_number bigint,
    updated_at timestamptz,
    last_error text
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
    SELECT
        p.step_order,
        p.substep_order,
        p.step_name,
        p.substep_name,
        p.status,
        p.rows_processed,
        p.rows_expected,
        CASE
            WHEN p.rows_expected > 0
            THEN round(100.0 * p.rows_processed / p.rows_expected, 1)
            ELSE NULL
        END,
        p.batch_count,
        p.last_source_row_number,
        p.updated_at,
        p.last_error
    FROM import.source_run_step_progress p
    WHERE p.source_run_id = p_source_run_id
    ORDER BY p.step_order, p.substep_order;
$$;


REVOKE ALL ON FUNCTION import.phase3b_initialize(uuid,boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION import.phase3b_run_checkpoint(uuid,text,text,integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION import.phase3b_progress(uuid) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION import.phase3b_initialize(uuid,boolean) TO lego_importer;
GRANT EXECUTE ON FUNCTION import.phase3b_run_checkpoint(uuid,text,text,integer) TO lego_importer;
GRANT EXECUTE ON FUNCTION import.phase3b_progress(uuid) TO lego_importer;

COMMENT ON FUNCTION import.phase3b_run_checkpoint(uuid,text,text,integer) IS
    'Executes one resumable Rebrickable Phase 3B checkpoint batch and commits progress when the caller commits.';

CREATE OR REPLACE FUNCTION import.phase4b_initialize(
    p_source_run_id uuid,
    p_restart boolean DEFAULT false
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
DECLARE
    v_source_id smallint;
    v_run_status text;
    v_rows bigint;
BEGIN
    SELECT r.source_id, r.status::text
      INTO v_source_id, v_run_status
    FROM import.source_runs r
    JOIN reference.external_sources es
      ON es.source_id = r.source_id
    WHERE r.source_run_id = p_source_run_id
      AND es.source_code = 'REBRICKABLE'
    FOR UPDATE OF r;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Rebrickable source run % does not exist', p_source_run_id
            USING ERRCODE = '22023';
    END IF;

    IF v_run_status NOT IN ('VALIDATING', 'FINALIZING') THEN
        RAISE EXCEPTION
            'Phase 4B source run % must be VALIDATING or FINALIZING; status=%',
            p_source_run_id, v_run_status
            USING ERRCODE = '55000';
    END IF;

    SELECT count(*)
      INTO v_rows
    FROM import.source_stage_records
    WHERE source_run_id = p_source_run_id
      AND dataset_name = 'elements'
      AND entity_namespace = 'ELEMENT';

    IF v_rows = 0 THEN
        RAISE EXCEPTION 'Phase 4B source run % has no staged elements', p_source_run_id
            USING ERRCODE = '55000';
    END IF;

    IF p_restart THEN
        DELETE FROM import.source_run_steps
        WHERE source_run_id = p_source_run_id
          AND step_name LIKE 'P4B_%';

        UPDATE import.source_runs
        SET
            status = 'VALIDATING',
            completed_at = NULL,
            failed_at = NULL,
            failure_message = NULL
        WHERE source_run_id = p_source_run_id;
    END IF;

    INSERT INTO import.source_run_steps (
        source_run_id, step_name, step_order
    )
    VALUES
        (p_source_run_id, 'P4B_VALIDATE', 101),
        (p_source_run_id, 'P4B_VARIANTS', 102),
        (p_source_run_id, 'P4B_ELEMENTS', 103),
        (p_source_run_id, 'P4B_SOURCE_PRESENCE', 104),
        (p_source_run_id, 'P4B_FINALIZE', 105)
    ON CONFLICT (source_run_id, step_name) DO NOTHING;

    INSERT INTO import.source_run_step_progress (
        source_run_id, step_name, substep_name,
        step_order, substep_order, rows_expected
    )
    VALUES
        (p_source_run_id, 'P4B_VALIDATE', 'SOURCE_CONTRACT', 101, 1, 1),
        (p_source_run_id, 'P4B_VALIDATE', 'PART_REFERENCES', 101, 2, 1),
        (p_source_run_id, 'P4B_VALIDATE', 'COLOR_REFERENCES', 101, 3, 1),
        (p_source_run_id, 'P4B_VALIDATE', 'ELEMENT_IDENTIFIERS', 101, 4, 1),

        (p_source_run_id, 'P4B_VARIANTS', 'PART_COLOR_VARIANTS', 102, 1, v_rows),

        (p_source_run_id, 'P4B_ELEMENTS', 'LEGO_ELEMENTS', 103, 1, v_rows),
        (p_source_run_id, 'P4B_ELEMENTS', 'EXTERNAL_IDENTIFIERS', 103, 2, v_rows),

        (p_source_run_id, 'P4B_SOURCE_PRESENCE', 'ELEMENTS', 104, 1, 1),

        (p_source_run_id, 'P4B_FINALIZE', 'VERIFY_COUNTS', 105, 1, 1),
        (p_source_run_id, 'P4B_FINALIZE', 'COMPLETE_RUN', 105, 2, 1)
    ON CONFLICT (source_run_id, step_name, substep_name) DO NOTHING;

    RETURN jsonb_build_object(
        'source_run_id', p_source_run_id,
        'restart', p_restart,
        'rows', v_rows
    );
END;
$$;


/* --------------------------------------------------------------------------
 * Execute one checkpoint batch.
 * The client commits each call independently.
 * -------------------------------------------------------------------------- */
CREATE OR REPLACE FUNCTION import.phase4b_run_checkpoint(
    p_source_run_id uuid,
    p_step_name text,
    p_substep_name text,
    p_batch_size integer DEFAULT 5000
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
DECLARE
    v_source_id smallint;
    v_status text;
    v_rows_expected bigint;
    v_rows_processed bigint;
    v_last bigint;
    v_batch_count integer;
    v_batch_rows bigint := 0;
    v_batch_last bigint;
    v_now timestamptz := clock_timestamp();
BEGIN
    IF p_batch_size < 1 OR p_batch_size > 50000 THEN
        RAISE EXCEPTION 'batch_size must be between 1 and 50000'
            USING ERRCODE = '22023';
    END IF;

    PERFORM app.set_import_context(p_source_run_id);

    SELECT r.source_id
      INTO v_source_id
    FROM import.source_runs r
    JOIN reference.external_sources es
      ON es.source_id = r.source_id
    WHERE r.source_run_id = p_source_run_id
      AND es.source_code = 'REBRICKABLE';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Rebrickable source run % does not exist', p_source_run_id;
    END IF;

    SELECT
        status,
        rows_expected,
        rows_processed,
        COALESCE(last_source_row_number, 0),
        batch_count
    INTO
        v_status,
        v_rows_expected,
        v_rows_processed,
        v_last,
        v_batch_count
    FROM import.source_run_step_progress
    WHERE source_run_id = p_source_run_id
      AND step_name = p_step_name
      AND substep_name = p_substep_name
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Unknown Phase 4B checkpoint %.%', p_step_name, p_substep_name
            USING ERRCODE = '22023';
    END IF;

    IF v_status = 'COMPLETED' THEN
        RETURN jsonb_build_object(
            'step', p_step_name,
            'substep', p_substep_name,
            'status', v_status,
            'rows_processed', v_rows_processed,
            'rows_expected', v_rows_expected,
            'batch_count', v_batch_count
        );
    END IF;

    IF EXISTS (
        SELECT 1
        FROM import.source_run_step_progress prior
        JOIN import.source_run_step_progress cur
          ON cur.source_run_id = prior.source_run_id
         AND cur.step_name = p_step_name
         AND cur.substep_name = p_substep_name
        WHERE prior.source_run_id = p_source_run_id
          AND (prior.step_order, prior.substep_order)
              < (cur.step_order, cur.substep_order)
          AND prior.step_order >= 101
          AND prior.status <> 'COMPLETED'
    ) THEN
        RAISE EXCEPTION 'Earlier Phase 4B checkpoint is not complete'
            USING ERRCODE = '55000';
    END IF;

    UPDATE import.source_run_steps
    SET
        status = 'RUNNING',
        attempt_count = attempt_count + CASE WHEN status <> 'RUNNING' THEN 1 ELSE 0 END,
        started_at = COALESCE(started_at, v_now),
        updated_at = v_now,
        failed_at = NULL,
        last_error = NULL
    WHERE source_run_id = p_source_run_id
      AND step_name = p_step_name;

    UPDATE import.source_run_step_progress
    SET
        status = 'RUNNING',
        attempt_count = attempt_count + CASE WHEN status <> 'RUNNING' THEN 1 ELSE 0 END,
        started_at = COALESCE(started_at, v_now),
        updated_at = v_now,
        failed_at = NULL,
        last_error = NULL
    WHERE source_run_id = p_source_run_id
      AND step_name = p_step_name
      AND substep_name = p_substep_name;

    /* ----- validation ---------------------------------------------------- */
    IF p_step_name = 'P4B_VALIDATE'
       AND p_substep_name = 'SOURCE_CONTRACT'
    THEN
        IF NOT EXISTS (
            SELECT 1
            FROM import.source_run_datasets d
            WHERE d.source_run_id = p_source_run_id
              AND d.dataset_name = 'elements'
              AND d.status = 'VALIDATED'
              AND d.source_row_count = d.staged_row_count
              AND d.checksum_sha256 IS NOT NULL
        ) THEN
            RAISE EXCEPTION 'Phase 4 elements dataset contract is not validated'
                USING ERRCODE = '55000';
        END IF;
        v_batch_rows := 1;

    ELSIF p_step_name = 'P4B_VALIDATE'
      AND p_substep_name = 'PART_REFERENCES'
    THEN
        IF EXISTS (
            SELECT 1
            FROM import.source_stage_records sr
            LEFT JOIN catalog.external_identifiers ei
              ON ei.source_id = v_source_id
             AND ei.entity_namespace = 'PART'
             AND ei.external_id = sr.normalized_payload->>'part_num'
             AND ei.external_version IS NULL
             AND ei.source_present
            WHERE sr.source_run_id = p_source_run_id
              AND sr.dataset_name = 'elements'
              AND sr.entity_namespace = 'ELEMENT'
              AND ei.catalog_item_id IS NULL
        ) THEN
            RAISE EXCEPTION
                'One or more Phase 4 elements reference a PART not reconciled in Phase 3'
                USING ERRCODE = '23503';
        END IF;
        v_batch_rows := 1;

    ELSIF p_step_name = 'P4B_VALIDATE'
      AND p_substep_name = 'COLOR_REFERENCES'
    THEN
        IF EXISTS (
            SELECT 1
            FROM import.source_stage_records sr
            LEFT JOIN reference.external_color_mappings cm
              ON cm.source_id = v_source_id
             AND cm.external_color_id = sr.normalized_payload->>'color_id'
             AND cm.valid_to IS NULL
            WHERE sr.source_run_id = p_source_run_id
              AND sr.dataset_name = 'elements'
              AND sr.entity_namespace = 'ELEMENT'
              AND cm.color_id IS NULL
        ) THEN
            RAISE EXCEPTION
                'One or more Phase 4 elements reference an unmapped Rebrickable color'
                USING ERRCODE = '23503';
        END IF;
        v_batch_rows := 1;

    ELSIF p_step_name = 'P4B_VALIDATE'
      AND p_substep_name = 'ELEMENT_IDENTIFIERS'
    THEN
        IF EXISTS (
            SELECT 1
            FROM import.source_stage_records sr
            WHERE sr.source_run_id = p_source_run_id
              AND sr.dataset_name = 'elements'
              AND sr.entity_namespace = 'ELEMENT'
              AND (
                    (sr.normalized_payload->>'element_id') !~ '^[0-9]+$'
                 OR (sr.normalized_payload->>'element_id')::numeric
                    NOT BETWEEN 1 AND 9223372036854775807
              )
        ) THEN
            RAISE EXCEPTION
                'One or more Rebrickable element_id values are not positive int8-compatible identifiers'
                USING ERRCODE = '22003';
        END IF;

        IF EXISTS (
            SELECT 1
            FROM (
                SELECT
                    sr.normalized_payload->>'element_id' AS element_id,
                    count(DISTINCT (
                        sr.normalized_payload->>'part_num',
                        sr.normalized_payload->>'color_id'
                    )) AS mappings
                FROM import.source_stage_records sr
                WHERE sr.source_run_id = p_source_run_id
                  AND sr.dataset_name = 'elements'
                  AND sr.entity_namespace = 'ELEMENT'
                GROUP BY sr.normalized_payload->>'element_id'
                HAVING count(DISTINCT (
                    sr.normalized_payload->>'part_num',
                    sr.normalized_payload->>'color_id'
                )) > 1
            ) conflicts
        ) THEN
            RAISE EXCEPTION
                'Current Rebrickable elements snapshot maps at least one element_id to multiple part/color pairs'
                USING ERRCODE = '23514';
        END IF;
        v_batch_rows := 1;

    /* ----- batched reconciliation -------------------------------------- */
    ELSIF p_step_name IN ('P4B_VARIANTS', 'P4B_ELEMENTS') THEN
        DROP TABLE IF EXISTS pg_temp.bt_p4b_batch;

        CREATE TEMP TABLE bt_p4b_batch
        ON COMMIT DROP
        AS
        SELECT
            sr.source_row_number,
            sr.normalized_payload,
            pei.catalog_item_id AS part_catalog_item_id,
            cm.color_id,
            pv.part_variant_id
        FROM import.source_stage_records sr
        JOIN catalog.external_identifiers pei
          ON pei.source_id = v_source_id
         AND pei.entity_namespace = 'PART'
         AND pei.external_id = sr.normalized_payload->>'part_num'
         AND pei.external_version IS NULL
         AND pei.source_present
        JOIN reference.external_color_mappings cm
          ON cm.source_id = v_source_id
         AND cm.external_color_id = sr.normalized_payload->>'color_id'
         AND cm.valid_to IS NULL
        LEFT JOIN catalog.part_variants pv
          ON pv.part_catalog_item_id = pei.catalog_item_id
         AND pv.color_id = cm.color_id
         AND pv.decoration_code IS NULL
         AND pv.mold_code IS NULL
         AND pv.is_printed = false
         AND pv.is_stickered = false
        WHERE sr.source_run_id = p_source_run_id
          AND sr.dataset_name = 'elements'
          AND sr.entity_namespace = 'ELEMENT'
          AND sr.source_row_number > v_last
        ORDER BY sr.source_row_number
        LIMIT p_batch_size;

        SELECT count(*), max(source_row_number)
          INTO v_batch_rows, v_batch_last
        FROM bt_p4b_batch;

        IF v_batch_rows = 0 THEN
            v_batch_last := v_last;

        ELSIF p_step_name = 'P4B_VARIANTS'
          AND p_substep_name = 'PART_COLOR_VARIANTS'
        THEN
            INSERT INTO catalog.part_variants (
                part_catalog_item_id,
                color_id,
                decoration_code,
                mold_code,
                is_printed,
                is_stickered
            )
            SELECT DISTINCT
                b.part_catalog_item_id,
                b.color_id,
                NULL,
                NULL,
                false,
                false
            FROM bt_p4b_batch b
            WHERE b.part_variant_id IS NULL
            ON CONFLICT DO NOTHING;

        ELSIF p_step_name = 'P4B_ELEMENTS'
          AND p_substep_name = 'LEGO_ELEMENTS'
        THEN
            INSERT INTO catalog.lego_elements (
                lego_element_id,
                part_variant_id,
                valid_from,
                valid_to,
                notes
            )
            SELECT DISTINCT
                (b.normalized_payload->>'element_id')::bigint,
                pv.part_variant_id,
                CURRENT_DATE,
                NULL::date,
                'Rebrickable authoritative elements snapshot'
            FROM bt_p4b_batch b
            JOIN catalog.part_variants pv
              ON pv.part_catalog_item_id = b.part_catalog_item_id
             AND pv.color_id = b.color_id
             AND pv.decoration_code IS NULL
             AND pv.mold_code IS NULL
             AND pv.is_printed = false
             AND pv.is_stickered = false
            ON CONFLICT (lego_element_id, part_variant_id)
            DO UPDATE SET
                valid_to = NULL;

        ELSIF p_step_name = 'P4B_ELEMENTS'
          AND p_substep_name = 'EXTERNAL_IDENTIFIERS'
        THEN
            INSERT INTO catalog.external_identifiers (
                source_id,
                entity_namespace,
                external_id,
                external_version,
                catalog_item_id,
                part_variant_id,
                source_present,
                valid_from,
                valid_to,
                first_seen_at,
                last_seen_at
            )
            SELECT DISTINCT
                v_source_id,
                'ELEMENT',
                b.normalized_payload->>'element_id',
                NULL::integer,
                NULL::uuid,
                pv.part_variant_id,
                true,
                CURRENT_DATE,
                NULL::date,
                v_now,
                v_now
            FROM bt_p4b_batch b
            JOIN catalog.part_variants pv
              ON pv.part_catalog_item_id = b.part_catalog_item_id
             AND pv.color_id = b.color_id
             AND pv.decoration_code IS NULL
             AND pv.mold_code IS NULL
             AND pv.is_printed = false
             AND pv.is_stickered = false
            ON CONFLICT (
                source_id,
                entity_namespace,
                external_id,
                external_version
            )
            WHERE source_present
            DO UPDATE SET
                part_variant_id = EXCLUDED.part_variant_id,
                catalog_item_id = NULL,
                source_present = true,
                valid_to = NULL,
                last_seen_at = EXCLUDED.last_seen_at;

        ELSE
            RAISE EXCEPTION 'Unsupported Phase 4B batch checkpoint %.%',
                p_step_name, p_substep_name;
        END IF;

    /* ----- authoritative source presence ------------------------------- */
    ELSIF p_step_name = 'P4B_SOURCE_PRESENCE'
      AND p_substep_name = 'ELEMENTS'
    THEN
        UPDATE catalog.external_identifiers ei
        SET
            source_present = false,
            valid_to = CURRENT_DATE
        WHERE ei.source_id = v_source_id
          AND ei.entity_namespace = 'ELEMENT'
          AND ei.source_present
          AND NOT EXISTS (
              SELECT 1
              FROM import.source_stage_records sr
              WHERE sr.source_run_id = p_source_run_id
                AND sr.dataset_name = 'elements'
                AND sr.entity_namespace = 'ELEMENT'
                AND sr.normalized_payload->>'element_id' = ei.external_id
          );

        v_batch_rows := 1;

    /* ----- final verification / completion ----------------------------- */
    ELSIF p_step_name = 'P4B_FINALIZE'
      AND p_substep_name = 'VERIFY_COUNTS'
    THEN
        IF EXISTS (
            SELECT 1
            FROM import.source_stage_records sr
            LEFT JOIN catalog.external_identifiers ei
              ON ei.source_id = v_source_id
             AND ei.entity_namespace = 'ELEMENT'
             AND ei.external_id = sr.normalized_payload->>'element_id'
             AND ei.external_version IS NULL
             AND ei.source_present
             AND ei.part_variant_id IS NOT NULL
            WHERE sr.source_run_id = p_source_run_id
              AND sr.dataset_name = 'elements'
              AND sr.entity_namespace = 'ELEMENT'
              AND ei.external_identifier_id IS NULL
            LIMIT 1
        ) THEN
            RAISE EXCEPTION 'Phase 4B final verification found unmapped staged elements'
                USING ERRCODE = '23514';
        END IF;
        v_batch_rows := 1;

    ELSIF p_step_name = 'P4B_FINALIZE'
      AND p_substep_name = 'COMPLETE_RUN'
    THEN
        UPDATE import.source_run_datasets
        SET
            status = 'COMPLETED',
            completed_at = COALESCE(completed_at, v_now)
        WHERE source_run_id = p_source_run_id
          AND dataset_name = 'elements';

        PERFORM import.complete_source_run(
            p_source_run_id,
            jsonb_build_object(
                'phase4b_elements',
                jsonb_build_object(
                    'strategy', 'checkpointed-v4.1.0',
                    'completed_at', v_now
                )
            )
        );

        v_batch_rows := 1;

    ELSE
        RAISE EXCEPTION 'Unsupported Phase 4B checkpoint %.%',
            p_step_name, p_substep_name
            USING ERRCODE = '22023';
    END IF;

    /* ----- durable checkpoint accounting ------------------------------- */
    IF p_step_name IN ('P4B_VARIANTS', 'P4B_ELEMENTS') THEN
        UPDATE import.source_run_step_progress
        SET
            rows_processed = LEAST(
                COALESCE(rows_expected, rows_processed + v_batch_rows),
                rows_processed + v_batch_rows
            ),
            last_source_row_number = CASE
                WHEN v_batch_rows > 0 THEN v_batch_last
                ELSE last_source_row_number
            END,
            batch_count = batch_count + CASE WHEN v_batch_rows > 0 THEN 1 ELSE 0 END,
            updated_at = clock_timestamp()
        WHERE source_run_id = p_source_run_id
          AND step_name = p_step_name
          AND substep_name = p_substep_name;
    ELSE
        UPDATE import.source_run_step_progress
        SET
            rows_processed = COALESCE(rows_expected, 1),
            batch_count = batch_count + 1,
            updated_at = clock_timestamp()
        WHERE source_run_id = p_source_run_id
          AND step_name = p_step_name
          AND substep_name = p_substep_name;
    END IF;

    UPDATE import.source_run_step_progress
    SET
        status = CASE
            WHEN rows_expected IS NULL OR rows_processed >= rows_expected
                THEN 'COMPLETED'
            ELSE 'RUNNING'
        END,
        completed_at = CASE
            WHEN rows_expected IS NULL OR rows_processed >= rows_expected
                THEN clock_timestamp()
            ELSE NULL
        END,
        updated_at = clock_timestamp()
    WHERE source_run_id = p_source_run_id
      AND step_name = p_step_name
      AND substep_name = p_substep_name;

    UPDATE import.source_run_steps s
    SET
        status = CASE
            WHEN NOT EXISTS (
                SELECT 1
                FROM import.source_run_step_progress p
                WHERE p.source_run_id = s.source_run_id
                  AND p.step_name = s.step_name
                  AND p.status <> 'COMPLETED'
            ) THEN 'COMPLETED'
            ELSE 'RUNNING'
        END,
        completed_at = CASE
            WHEN NOT EXISTS (
                SELECT 1
                FROM import.source_run_step_progress p
                WHERE p.source_run_id = s.source_run_id
                  AND p.step_name = s.step_name
                  AND p.status <> 'COMPLETED'
            ) THEN clock_timestamp()
            ELSE NULL
        END,
        updated_at = clock_timestamp()
    WHERE s.source_run_id = p_source_run_id
      AND s.step_name = p_step_name;

    RETURN (
        SELECT jsonb_build_object(
            'step', step_name,
            'substep', substep_name,
            'status', status,
            'rows_processed', rows_processed,
            'rows_expected', rows_expected,
            'batch_count', batch_count,
            'last_source_row_number', last_source_row_number,
            'percent_complete',
                CASE
                    WHEN rows_expected > 0
                    THEN round(100.0 * rows_processed / rows_expected, 1)
                    ELSE NULL
                END
        )
        FROM import.source_run_step_progress
        WHERE source_run_id = p_source_run_id
          AND step_name = p_step_name
          AND substep_name = p_substep_name
    );
END;
$$;


CREATE OR REPLACE FUNCTION import.phase4b_progress(
    p_source_run_id uuid
)
RETURNS TABLE (
    step_order integer,
    substep_order integer,
    step_name text,
    substep_name text,
    status text,
    rows_processed bigint,
    rows_expected bigint,
    percent_complete numeric,
    batch_count integer,
    last_source_row_number bigint,
    updated_at timestamptz,
    last_error text
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
    SELECT
        p.step_order,
        p.substep_order,
        p.step_name,
        p.substep_name,
        p.status,
        p.rows_processed,
        p.rows_expected,
        CASE
            WHEN p.rows_expected > 0
            THEN round(100.0 * p.rows_processed / p.rows_expected, 1)
            ELSE NULL
        END,
        p.batch_count,
        p.last_source_row_number,
        p.updated_at,
        p.last_error
    FROM import.source_run_step_progress p
    WHERE p.source_run_id = p_source_run_id
      AND p.step_order BETWEEN 101 AND 105
    ORDER BY p.step_order, p.substep_order;
$$;

SELECT pg_temp.bt_mark_completed('1000_function/1016_rebrickable_catalog_reconcile.sql');
