/*
===============================================================================
 File:           0800_imports/0802_raw_staging.sql
 Project:        LEGO Collection Platform
 Schema Version: 0.1.0
 PostgreSQL:     16+
 Purpose:        Preserve raw user-import records and run-scoped authoritative
                 staging records.
 Depends On:     import.jobs
                 import.source_runs
 Creates:        import.raw_records
                 import.source_stage_records
 Key Rules:      Raw/staged data never mutates canonical catalog or ownership
                 directly.
                 Authoritative staging is scoped to one source run/dataset.
                 Rebrickable MOC staging is rejected by runtime import policy.
 Validation:     Enforces positive optional source row numbers, valid dataset/
                 entity namespace names and required JSON payloads.
===============================================================================
*/

\set ON_ERROR_STOP on
SELECT pg_temp.bt_preflight('0800_imports/0802_raw_staging.sql', ARRAY['import.jobs', 'import.source_runs']::text[]);



CREATE TABLE import.raw_records (
    raw_record_id bigint GENERATED ALWAYS AS IDENTITY,

    import_job_id uuid NOT NULL,

    source_row_number bigint,
    raw_payload jsonb NOT NULL,

    created_at timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT pk_raw_records
        PRIMARY KEY (raw_record_id),

    CONSTRAINT fk_raw_records_job
        FOREIGN KEY (import_job_id)
        REFERENCES import.jobs(import_job_id)
        ON DELETE CASCADE,

    CONSTRAINT ck_raw_records_row
        CHECK (
            source_row_number IS NULL
            OR source_row_number > 0
        )
);

CREATE INDEX ix_raw_records_job
    ON import.raw_records(import_job_id);


CREATE TABLE import.source_stage_records (
    source_stage_record_id bigint GENERATED ALWAYS AS IDENTITY,

    source_run_id uuid NOT NULL,

    dataset_name text NOT NULL,
    entity_namespace text NOT NULL,

    source_row_number bigint,

    normalized_payload jsonb NOT NULL,

    created_at timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT pk_source_stage_records
        PRIMARY KEY (source_stage_record_id),

    CONSTRAINT fk_source_stage_records_run
        FOREIGN KEY (source_run_id)
        REFERENCES import.source_runs(source_run_id)
        ON DELETE CASCADE,

    CONSTRAINT ck_source_stage_records_dataset
        CHECK (btrim(dataset_name) <> ''),

    CONSTRAINT ck_source_stage_records_namespace
        CHECK (
            entity_namespace ~ '^[A-Z0-9_]+$'
        ),

    CONSTRAINT ck_source_stage_records_row
        CHECK (
            source_row_number IS NULL
            OR source_row_number > 0
        )
);

CREATE INDEX ix_source_stage_records_scope
    ON import.source_stage_records(
        source_run_id,
        dataset_name,
        entity_namespace
    );

SELECT app.assert_table_exists(
    'import',
    'raw_records'
);

SELECT app.assert_table_exists(
    'import',
    'source_stage_records'
);

\echo '[PASS] 0802_raw_staging.sql'

/* Rebrickable element reconciliation lookup support. */
CREATE INDEX IF NOT EXISTS ix_source_stage_records_external_element
    ON import.source_stage_records (
        source_run_id,
        dataset_name,
        entity_namespace,
        ((normalized_payload ->> 'element_id'))
    );

SELECT pg_temp.bt_mark_completed('0800_imports/0802_raw_staging.sql');
